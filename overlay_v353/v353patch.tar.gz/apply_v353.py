from pathlib import Path
import sys
root=Path(sys.argv[1])
html=root/'app/src/main/assets/index.html'
s=html.read_text(encoding='utf-8')
start='/* ===== v3.5.3 audit + merge integrity ===== */'
end='/* ===== end v3.5.3 ===== */'
if start in s:
    a=s.index(start); b=s.index(end,a)+len(end); s=s[:a]+s[b:]
block=Path(__file__).with_name('v353_block.js').read_text(encoding='utf-8')
marker='/* ===== end v3.5.2 ===== */'
if marker not in s: raise SystemExit('v3.5.2 marker missing')
s=s.replace(marker,block+'\n'+marker,1)
html.write_text(s,encoding='utf-8')
build=root/'app/build.gradle.kts'
t=build.read_text(encoding='utf-8')
for old in ['versionCode = 352','versionCode = 351','versionCode = 350']:
    t=t.replace(old,'versionCode = 353')
for old in ['versionName = "3.5.2-stable"','versionName = "3.5.1-stable"','versionName = "3.5.0-stable"']:
    t=t.replace(old,'versionName = "3.5.3-stable"')
build.write_text(t,encoding='utf-8')
print('applied v3.5.3')
