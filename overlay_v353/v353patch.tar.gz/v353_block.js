/* ===== v3.5.3 audit + merge integrity ===== */
const V353_VERSION='3.5.3';
state.externalContributors=state.externalContributors||[];

function v353AuditKey(a){return a?.auditId||['AUD',a?.timestamp||'',a?.userId||a?.user||'',a?.operation||'',a?.recordId||'',a?.field||'',String(a?.oldValue??''),String(a?.newValue??''),a?.deviceId||''].join('|')}
function v353ExchangeKey(x){return x?.id||['EX',x?.timestamp||'',x?.userId||x?.user||'',x?.type||'',x?.sourceExportId||'',x?.deviceId||'',x?.peerDeviceId||''].join('|')}
function v353ContributorList(){
 const m=new Map();
 const add=(id,name,role)=>{id=String(id||'').trim();name=String(name||'').trim();if(!id)return;const old=m.get(id)||{};m.set(id,{id,name:name||old.name||id,role:role||old.role||'مستخدم خارجي'})};
 for(const u of state.users||[])add(u.id,u.name,u.role);
 for(const u of state.externalContributors||[])add(u.id,u.name,u.role);
 for(const a of state.audit||[])add(a.userId,a.user,a.userRole);
 for(const x of state.exchangeLog||[])add(x.userId,x.user,x.userRole);
 return [...m.values()];
}
const v353BuildSyncBase=v2BuildSyncPackage;
v2BuildSyncPackage=function(){
 const pkg=v353BuildSyncBase();
 pkg.schemaVersion='3.5.3';
 pkg.contributors=v353ContributorList();
 pkg.auditTrail=clone((state.audit||[]).slice(0,10000));
 pkg.exchangeTrail=clone((state.exchangeLog||[]).slice(0,5000));
 pkg.deletedRecords=clone((state.deletedRecords||[]).slice(0,5000));
 return pkg;
};

const v353StageBase=v2StageImport;
v2StageImport=function(pkg){
 const preview=v353StageBase(pkg);
 preview.incomingAudit=clone(pkg.auditTrail||[]);
 preview.incomingExchange=clone(pkg.exchangeTrail||[]);
 preview.incomingContributors=clone(pkg.contributors||[]);
 preview.incomingDeletedFull=clone(pkg.deletedRecords||[]);
 // Same work number is only auto-merge eligible when the subject also matches.
 for(const it of preview.items||[]){
  if(it.kind!=='duplicate')continue;
  const sameSubject=v330NormSubject(it.local?.subject)===v330NormSubject(it.incoming?.subject);
  const lu=it.local?.creatorUserId||it.local?.createdByUserId||'';
  const iu=it.incoming?.creatorUserId||it.incoming?.createdByUserId||preview.exportedBy?.userId||'';
  it.sameContributor=!!(lu&&iu&&lu===iu);
  if(!sameSubject){
   it.kind='conflict';it.workNoConflict=true;it.decision='keep';
   it.duplicateReason='رقم العمل متطابق لكن الموضوع مختلف — يمنع الدمج التلقائي';
  }else{
   it.duplicateReason=it.sameContributor?'رقم العمل والموضوع من نفس المستخدم':'رقم العمل والموضوع من مستخدم مختلف';
   it.decision='merge';
  }
 }
 // Import remote deletion history even when the record never existed on this phone.
 const known=new Set((state.deletedRecords||[]).map(d=>d.tombstoneId||`${d.uid}|${d.deletedAt||''}`));
 const itemDeleted=new Set((preview.items||[]).filter(i=>i.kind==='deletion').map(i=>i.incoming?.tombstoneId||`${i.uid}|${i.incoming?.deletedAt||''}`));
 for(const d of pkg.deletedRecords||[]){
  const key=d.tombstoneId||`${d.uid}|${d.deletedAt||''}`;
  if(known.has(key)||itemDeleted.has(key))continue;
  preview.items.push({kind:'deletion_history',uid:d.uid||'',incoming:clone(d),decision:'history'});
 }
 preview.fieldCounts=v330FieldCounts(preview.items||[]);
 render();
 return preview;
};

const v353ImportVisibleBase=v330ImportItemVisible;
v330ImportItemVisible=function(it){
 const f=state.v330ImportFilter;
 if(f==='deleted')return it.kind==='deletion'||it.kind==='deletion_history';
 return v353ImportVisibleBase(it);
};
const v353ImportHtmlBase=v330ImportItemHtml;
v330ImportItemHtml=function(it,p){
 if(it.kind==='deletion_history'){
  const d=it.incoming||{},r=d.record||{};
  return `<article class="v330-import-item"><div class="v330-import-item-head"><div><strong>سجل حذف سابق من جهاز الزميل · ${esc(r.recordNo||r.id||d.uid||'—')}</strong><div>${esc(r.subject||'')}</div><div class="v330-import-source">${esc(d.deletedBy||p.exportedBy?.name||'—')} · ${esc(d.deletedByUserId||p.exportedBy?.userId||'—')} · ${esc(String(d.deletedAt||'').replace('T',' ').slice(0,16))}</div></div><span class="badge st-cancel">حذف سابق</span></div><div class="v2-delete-warning">سيتم حفظ النسخة الواردة في سجل الحذف والتدقيق، ولن تحذف أي سجل حالي.</div></article>`;
 }
 let html=v353ImportHtmlBase(it,p);
 if(it.workNoConflict){
  html=html.replace('تغيير وارد', 'تعارض رقم العمل — الموضوع مختلف')
           .replace(/<button class="btn [^"]*" data-action="v2-import-decision" data-index="(\d+)" data-decision="merge">[^<]*<\/button>/,'')
           .replace('<span class="badge st-late">مراجعة</span>','<span class="badge st-late">لا يدمج تلقائيًا</span>');
  html=html.replace('</div><div class="v330-decisions">',`<div class="v330-import-source">${esc(it.duplicateReason||'')}</div></div><div class="v330-decisions">`);
 }
 return html;
};
const v353RenderImportReviewBase=v2RenderImportReview;
v2RenderImportReview=function(){
 const p=state.importPreview;if(!p)return'';
 const html=v353RenderImportReviewBase();
 const hist=(p.items||[]).filter(x=>x.kind==='deletion_history').length;
 const trail=(p.incomingAudit||[]).length;
 const ex=(p.incomingExchange||[]).length;
 return html.replace('<div class="modal-body">',`<div class="modal-body"><div class="v353-import-meta"><span><strong>${hist}</strong>سجلات حذف تاريخية</span><span><strong>${trail}</strong>عمليات تدقيق واردة</span><span><strong>${ex}</strong>عمليات استيراد/تصدير واردة</span></div>`);
};

function v353MergeRemoteHistory(preview){
 if(!preview)return {audit:0,exchange:0,deletions:0,contributors:0};
 let ca=0,ce=0,cd=0,cc=0;
 const ak=new Set((state.audit||[]).map(v353AuditKey));
 for(const a0 of preview.incomingAudit||[]){const a=clone(a0);const k=v353AuditKey(a);if(ak.has(k))continue;a.auditId=a.auditId||v2Uid('AUDR');a.source=a.source||'سجل وارد';a.originDeviceId=a.originDeviceId||a.deviceId||preview.sourceDevice?.deviceId||'';state.audit.push(a);ak.add(k);ca++}
 state.audit.sort((a,b)=>String(b.timestamp||'').localeCompare(String(a.timestamp||'')));state.audit=state.audit.slice(0,10000);
 const ek=new Set((state.exchangeLog||[]).map(v353ExchangeKey));
 for(const x0 of preview.incomingExchange||[]){const x=clone(x0);const k=v353ExchangeKey(x);if(ek.has(k))continue;x.id=x.id||v2Uid('EXR');x.originDeviceId=x.originDeviceId||x.deviceId||preview.sourceDevice?.deviceId||'';state.exchangeLog.push(x);ek.add(k);ce++}
 state.exchangeLog.sort((a,b)=>String(b.timestamp||'').localeCompare(String(a.timestamp||'')));state.exchangeLog=state.exchangeLog.slice(0,5000);
 const dk=new Set((state.deletedRecords||[]).map(d=>d.tombstoneId||`${d.uid}|${d.deletedAt||''}`));
 for(const d0 of preview.incomingDeletedFull||[]){const d=clone(d0),k=d.tombstoneId||`${d.uid}|${d.deletedAt||''}`;if(dk.has(k))continue;d.tombstoneId=d.tombstoneId||v2Uid('DELR');d.sourceDeviceId=d.sourceDeviceId||preview.sourceDevice?.deviceId||'';state.deletedRecords.push(d);dk.add(k);cd++}
 state.deletedRecords.sort((a,b)=>String(b.deletedAt||'').localeCompare(String(a.deletedAt||'')));state.deletedRecords=state.deletedRecords.slice(0,5000);
 const cm=new Map((state.externalContributors||[]).map(u=>[u.id,u]));
 for(const u0 of preview.incomingContributors||[]){if(!u0?.id)continue;if(!cm.has(u0.id)){const u={id:u0.id,name:u0.name||u0.id,role:u0.role||'مستخدم خارجي',external:true};state.externalContributors.push(u);cm.set(u.id,u);cc++}}
 return {audit:ca,exchange:ce,deletions:cd,contributors:cc};
}
const v353ApplyImportBase=v2ApplyImport;
v2ApplyImport=async function(){
 const preview=state.importPreview?clone(state.importPreview):null;
 await v353ApplyImportBase();
 if(preview){const m=v353MergeRemoteHistory(preview);if(state.lastImportReport)state.lastImportReport.remoteHistory=m;await saveExcel('تم حفظ سجل التدقيق والنشاط الوارد كاملًا');render()}
};

// Accurate user activity: record edits from audit; import/export only from exchange log to avoid double counting.
v330ActivityStats=function(){
 const actors=v353ContributorList(),out=new Map();
 for(const u of actors)out.set(u.id,{u,adds:0,edits:0,deletes:0,exports:0,imports:0,progress:0,records:0,tasks:0});
 for(const r of state.records||[]){v330EnsureRecord(r);let x=out.get(r.creatorUserId);if(!x&&r.creatorUserId){x={u:{id:r.creatorUserId,name:r.createdBy||r.user||r.creatorUserId,role:'مستخدم خارجي'},adds:0,edits:0,deletes:0,exports:0,imports:0,progress:0,records:0,tasks:0};out.set(r.creatorUserId,x)}if(x){x.records++;if(r.type==='مهمة')x.tasks++}}
 for(const a of state.audit||[]){const uid=a.userId||v330UserIdByName(a.user);let x=out.get(uid);if(!x&&uid){x={u:{id:uid,name:a.user||uid,role:a.userRole||'مستخدم خارجي'},adds:0,edits:0,deletes:0,exports:0,imports:0,progress:0,records:0,tasks:0};out.set(uid,x)}if(!x)continue;const op=String(a.operation||'');if(op.includes('إضافة')&&op.includes('مجرى'))x.progress++;else if(op.includes('إضافة')||op.includes('سجل جديد'))x.adds++;if(op.includes('تعديل')||op.includes('تغيير حقل')||op.includes('اعتماد تعديل')||op.includes('دمج سجل'))x.edits++;if(op.includes('حذف'))x.deletes++}
 for(const l of state.exchangeLog||[]){if(l.undone)continue;const uid=l.userId||v330UserIdByName(l.user);let x=out.get(uid);if(!x&&uid){x={u:{id:uid,name:l.user||uid,role:l.userRole||'مستخدم خارجي'},adds:0,edits:0,deletes:0,exports:0,imports:0,progress:0,records:0,tasks:0};out.set(uid,x)}if(!x)continue;if(l.type==='تصدير')x.exports++;if(l.type==='استيراد')x.imports++}
 return [...out.values()];
};

// Ensure every export mode is represented once in exchangeLog with actor identity.
const v353RunExportBase=v340RunExport;
v340RunExport=async function(mode){
 const before=(state.exchangeLog||[]).length;const rows=v340ExportRows();await v353RunExportBase(mode);
 if(rows.length){const u=v330Actor();state.exchangeLog=state.exchangeLog||[];state.exchangeLog.unshift({id:v2Uid('EXP'),type:'تصدير',timestamp:nowISO(),user:u.name,userId:u.id,userRole:u.role,deviceId:v2DeviceId(),peerDeviceName:mode==='package'?'حزمة مع المرفقات':mode==='attachments'?'مرفقات فقط':'كشف بدون مرفقات',records:rows.length,mode});state.exchangeLog=state.exchangeLog.slice(0,5000);await saveExcel('تم توثيق عملية التصدير في سجل التبادل')}
};

const v353ExchangeBase=v2RenderExchange;
v2RenderExchange=function(){let html=v353ExchangeBase();const r=state.lastImportReport,m=r?.remoteHistory;if(m){const card=`<section class="settings-card span2 v353-history-import"><h3>سجل النشاط الوارد من الزميل</h3><p>تم دمج سجل التدقيق والنشاط دون تكرار: ${Number(m.audit)||0} عملية تدقيق · ${Number(m.exchange)||0} عملية استيراد/تصدير · ${Number(m.deletions)||0} سجل حذف تاريخي · ${Number(m.contributors)||0} مستخدم خارجي.</p></section>`;html=card+html}return html};

const v353Style=document.createElement('style');v353Style.textContent=`.v353-import-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:10px}.v353-import-meta span{padding:9px;border:1px solid var(--line);border-radius:10px;background:var(--soft);display:grid;text-align:center;font-size:9px}.v353-import-meta strong{font-size:18px;color:var(--brand)}@media(max-width:700px){.v353-import-meta{grid-template-columns:1fr}}`;document.head.appendChild(v353Style);
/* ===== end v3.5.3 ===== */