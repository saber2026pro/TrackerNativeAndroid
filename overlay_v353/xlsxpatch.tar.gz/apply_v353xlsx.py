from pathlib import Path
import sys
root=Path(sys.argv[1]); here=Path(__file__).parent
j=root/'app/src/main/java/com/mersad/trackerclassic/MainActivity.java'
s=j.read_text(encoding='utf-8')
if 'private String xlsxEsc(' not in s:
    marker='        @JavascriptInterface public void exportAttachments(String json,String title){'
    if marker not in s: raise SystemExit('java marker missing')
    s=s.replace(marker,(here/'java_block.txt').read_text(encoding='utf-8')+marker,1)
    j.write_text(s,encoding='utf-8')
h=root/'app/src/main/assets/index.html'
x=h.read_text(encoding='utf-8')
if 'function v353WorkbookRows(' not in x:
    marker='/* ===== end v3.5.3 ===== */'
    if marker not in x: raise SystemExit('js marker missing')
    x=x.replace(marker,(here/'js_block.txt').read_text(encoding='utf-8')+marker,1)
    h.write_text(x,encoding='utf-8')
print('applied real XLSX export patch')
