# The application is intentionally not minified in the current release.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
