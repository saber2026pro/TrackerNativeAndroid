package com.mersad.trackerclassic;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.*;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.OpenableColumns;
import android.view.View;
import android.webkit.*;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends Activity {
    private static final int REQ_PICK_ATTACHMENTS = 1001;
    private static final int REQ_IMPORT_JSON = 1002;
    private static final int REQ_CREATE_EXPORT = 1003;
    private static final String CHANNEL_ID = "tracker_alerts";

    private WebView webView;
    private File pendingExportFile;
    private String pendingExportName = "export.dat";
    private String pendingExportMime = "application/octet-stream";
    private android.os.CancellationSignal biometricCancel;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(23,52,56));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(23,52,56));
        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 404);
        }

        webView = new WebView(this);
        webView.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equalsIgnoreCase(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });

        StoreBridge store = new StoreBridge();
        NotifyBridge notify = new NotifyBridge();
        AuthBridge auth = new AuthBridge();
        webView.addJavascriptInterface(store, "AndroidStore");
        webView.addJavascriptInterface(store, "AndroidExport");
        webView.addJavascriptInterface(notify, "AndroidNotify");
        webView.addJavascriptInterface(auth, "AndroidAuth");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("(function(){try{return !!(window.handleNativeBack&&window.handleNativeBack())}catch(e){return false}})()", value -> {
            boolean handled = "true".equalsIgnoreCase(String.valueOf(value));
            if (!handled) MainActivity.super.onBackPressed();
        });
    }

    private void jsCallback(String code) {
        runOnUiThread(() -> webView.evaluateJavascript(code, null));
    }

    private String jsQuote(String value) {
        if (value == null) value = "";
        return JSONObject.quote(value);
    }

    private File stateFile() { return new File(getFilesDir(), "tracker_state.json"); }
    private File attachmentsDir() {
        File f = new File(getFilesDir(), "attachments"); if (!f.exists()) f.mkdirs(); return f;
    }

    private void writeAtomically(File target, String data) throws IOException {
        File tmp = new File(target.getParentFile(), target.getName()+".tmp");
        try(FileOutputStream out=new FileOutputStream(tmp)){ out.write(data.getBytes(StandardCharsets.UTF_8)); out.getFD().sync(); }
        if (target.exists() && !target.delete()) throw new IOException("تعذر استبدال الملف القديم");
        if (!tmp.renameTo(target)) throw new IOException("تعذر حفظ الملف");
    }

    private String readText(File f) throws IOException {
        if (!f.exists()) return "";
        try(FileInputStream in=new FileInputStream(f); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
            return out.toString("UTF-8");
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        try(Cursor c=getContentResolver().query(uri,null,null,null,null)){
            if(c!=null && c.moveToFirst()) { int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(idx>=0) name=c.getString(idx); }
        } catch(Exception ignored) {}
        if(name==null||name.trim().isEmpty()) name="file_"+System.currentTimeMillis();
        return name.replaceAll("[\\\\/:*?\"<>|]","_");
    }

    private String mime(Uri uri) { String m=getContentResolver().getType(uri); return m==null?"application/octet-stream":m; }

    private File copyToInternal(Uri uri) throws IOException {
        String name=displayName(uri);
        File dst=new File(attachmentsDir(), UUID.randomUUID().toString()+"_"+name);
        try(InputStream in=getContentResolver().openInputStream(uri); FileOutputStream out=new FileOutputStream(dst)){
            if(in==null) throw new IOException("تعذر فتح الملف");
            byte[] b=new byte[65536]; int n; while((n=in.read(b))>0) out.write(b,0,n);
        }
        return dst;
    }

    private void startCreateDocument(File source, String suggestedName, String mime) {
        pendingExportFile=source; pendingExportName=suggestedName; pendingExportMime=mime;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(mime); i.putExtra(Intent.EXTRA_TITLE,suggestedName);
        startActivityForResult(i,REQ_CREATE_EXPORT);
    }

    private File makeTempText(String prefix, String content) throws IOException {
        File f=File.createTempFile(prefix,".tmp",getCacheDir());
        try(FileOutputStream out=new FileOutputStream(f)){ out.write(content.getBytes(StandardCharsets.UTF_8)); }
        return f;
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null) return;
        try{
            if(requestCode==REQ_PICK_ATTACHMENTS){
                ArrayList<Uri> uris=new ArrayList<>();
                if(data.getClipData()!=null){ for(int i=0;i<data.getClipData().getItemCount();i++) uris.add(data.getClipData().getItemAt(i).getUri()); }
                else if(data.getData()!=null) uris.add(data.getData());
                JSONArray arr=new JSONArray();
                for(Uri u:uris){
                    File f=copyToInternal(u); JSONObject o=new JSONObject();
                    o.put("id","ATT-"+UUID.randomUUID()); o.put("name",displayName(u)); o.put("path",f.getAbsolutePath()); o.put("mime",mime(u)); o.put("size",f.length()); o.put("addedAt",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date())); o.put("source","android");
                    arr.put(o);
                }
                jsCallback("window.onNativeAttachmentsSelected&&window.onNativeAttachmentsSelected("+jsQuote(arr.toString())+")");
            } else if(requestCode==REQ_IMPORT_JSON){
                Uri u=data.getData(); if(u==null)return;
                String text; try(InputStream in=getContentResolver().openInputStream(u); ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] b=new byte[65536];int n;while((n=in.read(b))>0)out.write(b,0,n);text=out.toString("UTF-8");
                }
                jsCallback("window.onNativeBackupImported&&window.onNativeBackupImported("+jsQuote(text)+")");
            } else if(requestCode==REQ_CREATE_EXPORT){
                Uri u=data.getData(); if(u==null||pendingExportFile==null)return;
                try(InputStream in=new FileInputStream(pendingExportFile); OutputStream out=getContentResolver().openOutputStream(u,"w")){
                    if(out==null)throw new IOException("تعذر الكتابة"); byte[] b=new byte[65536];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();
                }
                Toast.makeText(this,"تم حفظ الملف",Toast.LENGTH_SHORT).show();
                if(pendingExportFile.getParentFile()!=null && pendingExportFile.getParentFile().equals(getCacheDir())) pendingExportFile.delete();
                pendingExportFile=null;
            }
        }catch(Exception e){ Toast.makeText(this,"خطأ: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"تنبيهات المتابعة",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيهات السجلات والمواعيد"); ch.enableVibration(true); ch.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    public final class StoreBridge {
        @JavascriptInterface public String loadState(){ try{return readText(stateFile());}catch(Exception e){return "";} }
        @JavascriptInterface public boolean saveState(String json){ try{writeAtomically(stateFile(),json==null?"":json);return true;}catch(Exception e){return false;} }
        @JavascriptInterface public String storageInfo(){
            try{JSONObject o=new JSONObject();File[] fs=attachmentsDir().listFiles();long bytes=stateFile().exists()?stateFile().length():0;if(fs!=null)for(File f:fs)bytes+=f.length();o.put("database","database");o.put("attachmentCount",fs==null?0:fs.length);o.put("bytes",bytes);return o.toString();}catch(Exception e){return "{}";}
        }
        @JavascriptInterface public void pickAttachments(){ runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,REQ_PICK_ATTACHMENTS);}); }
        @JavascriptInterface public void openAttachment(String path,String mime){ runOnUiThread(()->{
            try{File f=new File(path);if(!f.exists()){Toast.makeText(MainActivity.this,"المرفق غير موجود",Toast.LENGTH_SHORT).show();return;}Uri u= FileProvider.getUriForFile(MainActivity.this,getPackageName()+".files",f);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(u,mime==null||mime.isEmpty()?"*/*":mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){Toast.makeText(MainActivity.this,"لا يوجد تطبيق مناسب لفتح المرفق",Toast.LENGTH_SHORT).show();}
        }); }
        @JavascriptInterface public void pickDate(String field, String current){ runOnUiThread(()->{
            java.util.Calendar cal=java.util.Calendar.getInstance();
            try{
                if(current!=null && current.matches("\\d{4}-\\d{2}-\\d{2}")){
                    String[] x=current.split("-");
                    cal.set(java.util.Calendar.YEAR,Integer.parseInt(x[0]));
                    cal.set(java.util.Calendar.MONTH,Integer.parseInt(x[1])-1);
                    cal.set(java.util.Calendar.DAY_OF_MONTH,Integer.parseInt(x[2]));
                }
            }catch(Exception ignored){}
            DatePickerDialog dlg=new DatePickerDialog(MainActivity.this,(view,y,m,d)->{
                String value=String.format(java.util.Locale.US,"%04d-%02d-%02d",y,m+1,d);
                jsCallback("window.onNativeDatePicked&&window.onNativeDatePicked("+jsQuote(field)+","+jsQuote(value)+")");
            },cal.get(java.util.Calendar.YEAR),cal.get(java.util.Calendar.MONTH),cal.get(java.util.Calendar.DAY_OF_MONTH));
            dlg.show();
        }); }

        @JavascriptInterface public void printPage(){ runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("سجل المتابعة",webView.createPrintDocumentAdapter("سجل المتابعة"),new PrintAttributes.Builder().build());}); }
        @JavascriptInterface public void exportBackup(String json){ try{File f=makeTempText("tracker_backup_",json);runOnUiThread(()->startCreateDocument(f,"نسخة_احتياطية_المتابعة_"+System.currentTimeMillis()+".json","application/json"));}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();} }
        @JavascriptInterface public void importBackup(){ runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,REQ_IMPORT_JSON);}); }
        @JavascriptInterface public void exportText(String name,String mime,String content){ try{File f=makeTempText("tracker_export_",content);runOnUiThread(()->startCreateDocument(f,name,mime));}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();} }
        @JavascriptInterface public void exportAttachments(String json,String title){
            try{
                JSONArray items=new JSONArray(json);File zip=File.createTempFile("attachments_",".zip",getCacheDir());
                try(ZipOutputStream zos=new ZipOutputStream(new FileOutputStream(zip))){
                    HashSet<String> used=new HashSet<>();
                    for(int i=0;i<items.length();i++){JSONObject o=items.getJSONObject(i);String p=o.optString("path");File f=new File(p);if(!f.exists()||!f.isFile())continue;String n=o.optString("name",f.getName()).replaceAll("[\\\\/:*?\"<>|]","_");String base=n;int x=1;while(used.contains(n))n=(x++)+"_"+base;used.add(n);zos.putNextEntry(new ZipEntry(n));try(FileInputStream in=new FileInputStream(f)){byte[] b=new byte[65536];int r;while((r=in.read(b))>0)zos.write(b,0,r);}zos.closeEntry();}
                }
                String safe=(title==null||title.isEmpty()?"مرفقات":title).replaceAll("[\\\\/:*?\"<>|]","_");runOnUiThread(()->startCreateDocument(zip,safe+".zip","application/zip"));
            }catch(Exception e){Toast.makeText(MainActivity.this,"تعذر تصدير المرفقات: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }

    public final class AuthBridge {
        private String b64(byte[] b){ return android.util.Base64.encodeToString(b,android.util.Base64.NO_WRAP); }
        private byte[] unb64(String v){ return android.util.Base64.decode(v,android.util.Base64.NO_WRAP); }
        private byte[] derive(String password,byte[] salt,int iterations,int bits,String algorithm) throws Exception {
            PBEKeySpec spec=new PBEKeySpec((password==null?"":password).toCharArray(),salt,iterations,bits);
            try{return SecretKeyFactory.getInstance(algorithm).generateSecret(spec).getEncoded();}
            finally{spec.clearPassword();}
        }
        @JavascriptInterface public String hashPassword(String password){
            try{
                byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);int it=150000;String alg="PBKDF2WithHmacSHA1";
                byte[] hash=derive(password,salt,it,256,alg);
                return alg+"$"+it+"$"+b64(salt)+"$"+b64(hash);
            }catch(Exception e){return "";}
        }
        @JavascriptInterface public boolean verifyPassword(String password,String encoded){
            try{
                if(encoded==null||encoded.trim().isEmpty())return false;String[] p=encoded.split("\\$");
                String alg;int it;byte[] salt,expected;
                if(p.length==4){alg=p[0];it=Integer.parseInt(p[1]);salt=unb64(p[2]);expected=unb64(p[3]);}
                else if(p.length==3){alg="PBKDF2WithHmacSHA256";it=Integer.parseInt(p[0]);salt=unb64(p[1]);expected=unb64(p[2]);}
                else return false;
                byte[] actual;
                try{actual=derive(password,salt,it,expected.length*8,alg);}catch(Exception primary){actual=derive(password,salt,it,expected.length*8,"PBKDF2WithHmacSHA1");}
                return java.security.MessageDigest.isEqual(expected,actual);
            }catch(Exception e){return false;}
        }
    }

    public final class NotifyBridge {
        @JavascriptInterface public void post(String title,String message,int id){
            NotificationCompat.Builder b=new NotificationCompat.Builder(MainActivity.this,CHANNEL_ID).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message).setStyle(new NotificationCompat.BigTextStyle().bigText(message)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(false).setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.notify(id,b.build());
        }
        @JavascriptInterface public void cancel(int id){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(id);}
        @JavascriptInterface public String biometricStatus(){
            if(Build.VERSION.SDK_INT<23)return "unsupported";
            try{FingerprintManager fm=(FingerprintManager)getSystemService(FINGERPRINT_SERVICE);if(fm==null||!fm.isHardwareDetected())return "no_hardware";if(!fm.hasEnrolledFingerprints())return "not_enrolled";return "ready";}catch(Exception e){return "unsupported";}
        }
        @JavascriptInterface public void cancelBiometric(){if(biometricCancel!=null){biometricCancel.cancel();biometricCancel=null;}}
        @JavascriptInterface public void authenticate(String userId){runOnUiThread(()->startBiometric());}
        private void startBiometric(){
            cancelBiometric();
            if(Build.VERSION.SDK_INT<23){jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(false,'البصمة غير مدعومة')");return;}
            FingerprintManager fm=(FingerprintManager)getSystemService(FINGERPRINT_SERVICE);
            if(fm==null||!fm.isHardwareDetected()){jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(false,'لا يوجد مستشعر بصمة')");return;}
            if(!fm.hasEnrolledFingerprints()){jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(false,'لا توجد بصمة مسجلة في الهاتف')");return;}
            biometricCancel=new android.os.CancellationSignal();
            if(Build.VERSION.SDK_INT>=28){
                Executor ex=ContextCompat.getMainExecutor(MainActivity.this);
                BiometricPrompt prompt=new BiometricPrompt.Builder(MainActivity.this).setTitle("فتح نظام متابعة التقارير والخطط").setSubtitle("استخدم بصمة الهاتف").setNegativeButton("إلغاء",ex,(d,w)->{if(biometricCancel!=null)biometricCancel.cancel();}).build();
                prompt.authenticate(biometricCancel,ex,new BiometricPrompt.AuthenticationCallback(){
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){super.onAuthenticationSucceeded(result);biometricCancel=null;jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(true,'تم التحقق بالبصمة')");}
                    @Override public void onAuthenticationError(int errorCode,CharSequence errString){super.onAuthenticationError(errorCode,errString);biometricCancel=null;jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(false,"+jsQuote(errString.toString())+")");}
                    @Override public void onAuthenticationFailed(){super.onAuthenticationFailed();jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(false,'البصمة غير مطابقة')");}
                });
            }else{
                fm.authenticate(null,biometricCancel,0,new FingerprintManager.AuthenticationCallback(){
                    @Override public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result){biometricCancel=null;jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(true,'تم التحقق بالبصمة')");}
                    @Override public void onAuthenticationError(int errorCode,CharSequence errString){biometricCancel=null;jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(false,"+jsQuote(errString.toString())+")");}
                    @Override public void onAuthenticationFailed(){jsCallback("window.onNativeBiometricResult&&window.onNativeBiometricResult(false,'البصمة غير مطابقة')");}
                },null);
            }
        }
    }
}
