plugins { id("com.android.application") }

dependencies {
    implementation("androidx.core:core:1.16.0")
}

android {
    namespace = "com.mersad.trackerclassic"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.mersad.trackerclassic"
        minSdk = 23
        targetSdk = 35
        versionCode = 320
        versionName = "3.2.0-classic"
    }
}
