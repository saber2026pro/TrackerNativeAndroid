from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
html = root / 'app/src/main/assets/index.html'
gradle = root / 'app/build.gradle.kts'

s = html.read_text(encoding='utf-8')
# Normalize visible/source version strings from the 3.5.0 baseline.
s = s.replace('3.5.0', '3.5.1')

snippet = r'''

/* ===== v3.5.1 visible controls + editable default reminder + import drilldown ===== */
const V351_VERSION='3.5.1';
state.v351LastImportFilter='';

const v351EnsureSettingsBase=v340EnsureSettings;
function v351BuiltinPattern(preset,time){
 const t=time||'09:00';
 if(preset==='due')return {offsetsDays:[0],times:[t],repeatCount:1,repeatIntervalMinutes:30,repeatAfterOpen:'نعم',persistentSound:'لا'};
 if(preset==='three_days_due')return {offsetsDays:[-3,0],times:[t],repeatCount:1,repeatIntervalMinutes:30,repeatAfterOpen:'نعم',persistentSound:'لا'};
 if(preset==='week_due')return {offsetsDays:[-7,0],times:[t],repeatCount:1,repeatIntervalMinutes:30,repeatAfterOpen:'نعم',persistentSound:'لا'};
 return {offsetsDays:[-1,0],times:[t],repeatCount:1,repeatIntervalMinutes:30,repeatAfterOpen:'نعم',persistentSound:'لا'};
}
function v351EnsureDefaultPattern(){
 v351EnsureSettingsBase();
 let p=(state.settings.reminderPatterns||[]).find(x=>x.id==='PAT-DEFAULT');
 if(!p){
  const selected=state.settings.defaultReminderPreset||'day_before_due';
  let seed=v351BuiltinPattern(selected,state.settings.defaultReminderTime||'09:00');
  if(String(selected).startsWith('pattern:')){
   const src=(state.settings.reminderPatterns||[]).find(x=>`pattern:${x.id}`===selected);
   if(src)seed={offsetsDays:clone(src.offsetsDays||[-1,0]),times:clone(src.times||['09:00']),repeatCount:Number(src.repeatCount)||1,repeatIntervalMinutes:Number(src.repeatIntervalMinutes)||30,repeatAfterOpen:src.repeatAfterOpen||'نعم',persistentSound:src.persistentSound||'لا'};
  }
  p={id:'PAT-DEFAULT',name:'النمط الافتراضي',...seed};
  state.settings.reminderPatterns.unshift(p);
 }
 state.settings.defaultReminderPreset='pattern:PAT-DEFAULT';
 return p;
}
v340EnsureSettings=function(){v351EnsureDefaultPattern()};

const v351PatternEditorBase=v340PatternEditor;
v340PatternEditor=function(p){
 p=p||{id:'',name:'',offsetsDays:[-1],times:['09:00'],repeatCount:1,repeatIntervalMinutes:30,repeatAfterOpen:'نعم',persistentSound:'لا'};
 const isDefault=p.id==='PAT-DEFAULT';
 const days=(p.offsetsDays||[]).map(x=>Math.abs(Number(x))).join(',');
 return `<div class="v340-pattern-editor v351-pattern-editor"><h4>${isDefault?'تعديل النمط الافتراضي':p.id?'تعديل نمط التنبيه':'إضافة نمط تنبيه جديد'}</h4><div class="fields"><div class="field span2"><label>اسم النمط</label><input class="input" id="v340-p-name" value="${esc(isDefault?'النمط الافتراضي':p.name||'')}" ${isDefault?'readonly':''}></div><div class="field"><label>الأيام قبل الموعد</label><input class="input" id="v340-p-days" value="${esc(days)}" placeholder="مثال: 3,2,1 أو 2,1 أو 0"></div><div class="field"><label>ساعات التنبيه</label><input class="input" id="v340-p-times" value="${esc((p.times||[]).join(','))}" placeholder="09:00,14:00"></div><div class="field"><label>عدد مرات التنبيه في كل موعد</label><input class="input" type="number" min="1" max="20" id="v340-p-count" value="${Number(p.repeatCount)||1}"></div><div class="field"><label>الفاصل بين التكرارات بالدقائق</label><input class="input" type="number" min="1" max="1440" id="v340-p-gap" value="${Number(p.repeatIntervalMinutes)||30}"></div><div class="field"><label>بعد فتح الإشعار</label><select class="select" id="v340-p-after"><option value="نعم" ${p.repeatAfterOpen!=='لا'?'selected':''}>يستمر بالتكرار</option><option value="لا" ${p.repeatAfterOpen==='لا'?'selected':''}>يتوقف التكرار</option></select></div><div class="field"><label>نوع صوت التنبيه</label><select class="select" id="v340-p-sound"><option value="لا" ${p.persistentSound!=='نعم'?'selected':''}>عادي</option><option value="نعم" ${p.persistentSound==='نعم'?'selected':''}>دائم حتى أضغط «إيقاف التنبيه»</option></select></div><div class="field span2"><p class="v340-pattern-help">مثال 3,2,1 = ثلاثة أيام متتالية قبل الموعد. مثال 2,1 = يومان متتاليان. يمكنك وضع أكثر من ساعة، وتحديد عدد مرات التكرار والفاصل بينها. الصوت الدائم يستمر حتى إيقافه من الإشعار.</p><div class="v340-pattern-actions"><button class="btn" data-action="v340-pattern-save" data-id="${esc(p.id||'')}">حفظ النمط</button><button class="btn secondary" data-action="v340-pattern-cancel">إلغاء</button></div></div></div></div>`;
};

renderNotificationSettings=function(){
 const def=v351EnsureDefaultPattern(),s=state.settings,d=derived();
 const custom=(s.reminderPatterns||[]).filter(p=>p.id!=='PAT-DEFAULT');
 const edit=(s.reminderPatterns||[]).find(p=>p.id===state.v340PatternEditId);
 return `<div class="settings-grid"><section class="settings-card span2 v351-default-reminder"><div class="section-title"><div><h3>النمط الافتراضي للتنبيه</h3><p>هذا النمط يطبق على أي عمل يختار «استخدام النمط الافتراضي»، ويمكنك تعديله بالكامل.</p></div><button class="btn secondary small" data-action="v340-pattern-edit" data-id="PAT-DEFAULT">تعديل النمط الافتراضي</button></div><div class="v351-default-summary"><strong>${esc(def.name)}</strong><small>${esc(v340PatternSummary(def))}</small></div><div class="fields"><div class="field"><label>تشغيل التنبيهات</label><select class="select" data-setting="alertsEnabled"><option ${s.alertsEnabled!=='لا'?'selected':''}>نعم</option><option ${s.alertsEnabled==='لا'?'selected':''}>لا</option></select></div><div class="field"><label>تنبيه الأعمال المتأخرة</label><select class="select" data-setting="alertOverdue"><option ${s.alertOverdue!=='لا'?'selected':''}>نعم</option><option ${s.alertOverdue==='لا'?'selected':''}>لا</option></select></div><div class="field span2"><div class="data-card"><div class="grow"><h4>الحالة الحالية</h4><p>تنبيهات داخل التطبيق: ${state.notifications.length} · أعمال متأخرة: ${d.overdue.length}.</p></div><button class="btn secondary" data-action="native-test-notification">اختبار إشعار Android</button></div></div><div class="field span2"><button class="btn" data-action="save-settings">حفظ إعدادات التنبيهات</button></div></div>${state.v340PatternEditId==='PAT-DEFAULT'?v340PatternEditor(def):''}</section><section class="settings-card span2"><div class="section-title"><div><h3>أنماط التنبيه الإضافية</h3><p>أنشئ أي عدد من الأنماط، ثم اختر النمط المناسب لكل عمل من صفحة الإدخال.</p></div><button class="btn small" data-action="v340-pattern-new">${icon('plus')}إضافة نمط جديد</button></div><div class="v340-pattern-list">${custom.length?custom.map(p=>`<div class="v340-pattern"><div class="grow"><strong>${esc(p.name)}</strong><small>${esc(v340PatternSummary(p))}</small></div><div class="v340-pattern-actions"><button class="btn secondary small" data-action="v340-pattern-edit" data-id="${esc(p.id)}">تعديل</button><button class="btn danger small" data-action="v340-pattern-delete" data-id="${esc(p.id)}">حذف</button></div></div>`).join(''):`<div class="empty"><strong>لا توجد أنماط إضافية</strong><span>اضغط «إضافة نمط جديد» لإنشاء أول نمط.</span></div>`}</div>${state.v340PatternEditId==='__new__'?v340PatternEditor(null):(edit&&edit.id!=='PAT-DEFAULT'?v340PatternEditor(edit):'')}</section></div>`;
};

const v351DataBase=renderData;
renderData=function(){
 const base=v351DataBase();
 const sec=`<section class="settings-card span2 v351-export-card"><div class="section-title"><div><h3>تصدير البيانات والمرفقات</h3><p>اختر بوضوح ما تريد تصديره. الكشف يبين أسماء المرفقات الموجودة فعليًا لكل سجل.</p></div></div><div class="v351-export-buttons"><button class="btn secondary" data-action="v340-export-data">تصدير بدون المرفقات</button><button class="btn" data-action="v340-export-package">تصدير مع المرفقات</button><button class="btn secondary" data-action="v340-export-attachments-only">تصدير المرفقات فقط</button></div></section>`;
 return `<div class="settings-grid">${sec}</div>`+base;
};

const v351RenderBase=render;
render=function(){
 v351EnsureDefaultPattern();
 v351RenderBase();
 const actions=document.querySelector('.topbar .actions');
 if(actions){
  const bell=actions.querySelector('[data-action="notifications"]');
  if(!actions.querySelector('[data-action="v340-export-menu"].v351-top-export')){
   const h=`<button class="btn secondary v351-top-export" data-action="v340-export-menu" title="تصدير البيانات والمرفقات">${icon('download')}<span>تصدير</span></button>`;
   if(bell)bell.insertAdjacentHTML('beforebegin',h);else actions.insertAdjacentHTML('afterbegin',h);
  }
  if(classicAuthConfigured()&&!v203LoggedOut&&!actions.querySelector('[data-action="v203-logout"].v351-top-logout'))actions.insertAdjacentHTML('beforeend',`<button class="btn danger v351-top-logout" data-action="v203-logout" title="تسجيل الخروج">${icon('close')}<span>خروج</span></button>`);
 }
 const profile=document.querySelector('.profile');
 if(profile){profile.dataset.action='v340-profile';profile.title='اضغط لخيارات المستخدم وتسجيل الخروج';if(!profile.querySelector('.v351-profile-hint'))profile.insertAdjacentHTML('beforeend','<span class="v351-profile-hint">⋮</span>');}
};

const v351ApplyImportBase=v2ApplyImport;
v2ApplyImport=async function(){
 const preview=state.importPreview?clone(state.importPreview):null;
 await v351ApplyImportBase();
 if(preview&&state.lastImportReport){
  state.lastImportReport.items=clone(preview.items||[]);
  state.lastImportReport.unchanged=preview.unchanged||0;
  state.lastImportReport.sourceExportId=preview.sourceExportId||'';
  await saveExcel('تم حفظ تفاصيل تقرير الاستيراد');
  render();
 }
};
function v351LastImportVisible(it){const f=state.v351LastImportFilter;if(!f)return true;if(f==='new')return it.kind==='new';if(f==='duplicate')return it.kind==='duplicate';if(f==='deleted')return it.kind==='deletion';if(f==='progress')return !!it.diff?.newProgress?.length;return (it.diff?.fields||[]).some(d=>d.field===f)}
function v351LastImportItem(it,r){const incoming=it.incoming||{},local=it.local||{};if(it.kind==='new')return `<article class="v330-import-item"><div class="v330-import-item-head"><div><strong>إضافة جديدة · ${esc(incoming.recordNo||incoming.id||'')}</strong><div>${esc(incoming.subject||'')}</div></div><span class="badge st-done">جديد</span></div></article>`;return `<article class="v330-import-item"><div class="v330-import-item-head"><div><strong>${it.kind==='duplicate'?'مكرر':'تغيير'} · ${esc(local.recordNo||incoming.recordNo||'—')}</strong><div>${esc(local.subject||incoming.subject||'')}</div><div class="v330-import-source">الحالي: ${esc(local.createdBy||local.user||'—')} (${esc(local.creatorUserId||'—')}) · الوارد: ${esc(incoming.createdBy||r.exportedBy?.name||'—')} (${esc(incoming.creatorUserId||r.exportedBy?.userId||'—')})</div></div><span class="badge ${it.kind==='deletion'?'st-cancel':it.kind==='duplicate'?'st-follow':'st-late'}">${it.kind==='deletion'?'حذف':it.kind==='duplicate'?'مكرر':'تغيير'}</span></div>${it.kind==='deletion'?'<div class="v2-delete-warning">كان الوارد يطلب حذف السجل.</div>':v2RenderDiff(it.diff||{fields:[],newProgress:[]})}</article>`}
const v351ExchangeBase=v2RenderExchange;
v2RenderExchange=function(){let html=v351ExchangeBase();const r=state.lastImportReport,items=r?.items||[];if(!items.length)return html;const counts={new:items.filter(x=>x.kind==='new').length,duplicate:items.filter(x=>x.kind==='duplicate').length,deleted:items.filter(x=>x.kind==='deletion').length,changed:items.filter(x=>!['new','duplicate','deletion'].includes(x.kind)).length};const fields=r.fieldCounts||{},visible=items.filter(v351LastImportVisible);const sec=`<section class="settings-card span2 v351-last-import"><h3>تفاصيل آخر استيراد — اضغط على المؤشر للاستعراض</h3><div class="v330-import-kpis"><button class="v330-import-kpi" data-action="v351-import-history-filter" data-filter="new"><strong>${counts.new}</strong>إضافات جديدة</button><button class="v330-import-kpi" data-action="v351-import-history-filter" data-filter="duplicate"><strong>${counts.duplicate}</strong>مكرر</button><button class="v330-import-kpi" data-action="v351-import-history-filter" data-filter=""><strong>${counts.changed}</strong>سجلات معدلة</button><button class="v330-import-kpi" data-action="v351-import-history-filter" data-filter="deleted"><strong>${counts.deleted}</strong>حذف</button><div class="v330-import-kpi"><strong>${r.unchanged||r.unchangedCount||0}</strong>بدون تغيير</div></div><div class="v330-field-chips"><button class="v330-field-chip ${!state.v351LastImportFilter?'active':''}" data-action="v351-import-history-filter" data-filter="">كل التغييرات</button>${Object.entries(fields).filter(([,n])=>n).map(([f,n])=>`<button class="v330-field-chip ${state.v351LastImportFilter===f?'active':''}" data-action="v351-import-history-filter" data-filter="${esc(f)}">${esc(f==='progress'?'مجريات المتابعة':V2_FIELD_LABELS[f]||f)} (${n})</button>`).join('')}</div><div class="v351-import-history-list">${visible.length?visible.map(it=>v351LastImportItem(it,r)).join(''):'<div class="empty"><strong>لا توجد عناصر ضمن هذا المؤشر</strong></div>'}</div></section>`;return sec+html};

document.addEventListener('click',e=>{const b=e.target.closest?.('[data-action="v351-import-history-filter"]');if(!b)return;e.preventDefault();e.stopImmediatePropagation();state.v351LastImportFilter=b.dataset.filter||'';render()},true);

const v351Style=document.createElement('style');v351Style.textContent=`
:root{--v351-safe-top:env(safe-area-inset-top,0px)}
.workspace{padding-top:calc(82px + var(--v351-safe-top))!important}.topbar{top:0!important;min-height:calc(82px + var(--v351-safe-top))!important;height:auto!important;padding-top:var(--v351-safe-top)!important}.topbar .actions{flex-wrap:nowrap!important;overflow-x:auto!important;max-width:68vw!important;scrollbar-width:none}.topbar .actions::-webkit-scrollbar{display:none}.v351-top-export,.v351-top-logout{flex:0 0 auto!important}.v351-top-logout{background:var(--danger)!important;color:#fff!important}
.sidebar{z-index:300000!important;padding-top:max(20px,var(--v351-safe-top))!important}.app.mobile-open .sidebar{z-index:300000!important}.app.mobile-open .topbar{z-index:70!important}.app.mobile-open .brand-copy,.app.mobile-open .nav span,.app.mobile-open .nav em,.app.mobile-open .profile-copy{display:grid!important}.app.mobile-open .nav span,.app.mobile-open .nav em{display:inline!important}.app.mobile-open .brand{position:relative;z-index:2;min-height:76px!important}.app.mobile-open .brand-copy{overflow:visible!important}.app.mobile-open .brand-copy strong{white-space:normal!important;display:block!important}.v351-profile-hint{margin-right:auto;font-size:20px;color:#c7d8d6}.v340-profile-menu{z-index:300100!important}
.v351-default-summary{display:grid;gap:4px;padding:11px 12px;margin:8px 0 14px;border:1px solid var(--line);border-radius:11px;background:var(--soft)}.v351-default-summary small{color:var(--muted);line-height:1.7}.v351-export-buttons{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.v351-export-buttons .btn{min-height:46px}.v351-last-import{margin-bottom:12px}.v351-import-history-list{max-height:520px;overflow:auto;padding-inline-end:2px}
@media(max-width:760px){.workspace{padding-top:calc(76px + var(--v351-safe-top))!important}.topbar{min-height:calc(76px + var(--v351-safe-top))!important;padding-inline:10px!important}.title-copy small{display:none!important}.title-copy h1{font-size:14px!important;max-width:27vw}.topbar .actions{gap:5px!important;max-width:70vw!important}.v351-top-export,.v351-top-logout{min-height:35px!important;padding:0 8px!important;font-size:9px!important}.v351-export-buttons{grid-template-columns:1fr}.app.mobile-open .sidebar{width:min(88vw,310px)!important}.app.mobile-open .topbar{pointer-events:none}.v340-profile-menu{bottom:62px!important}}
`;
document.head.appendChild(v351Style);
/* ===== end v3.5.1 ===== */
'''

marker = '\n\ntry{const stored=readStoredState();'
if '/* ===== v3.5.1 visible controls' not in s:
    if marker not in s:
        raise SystemExit('initialization marker not found')
    s = s.replace(marker, snippet + marker, 1)
html.write_text(s, encoding='utf-8')

g = gradle.read_text(encoding='utf-8')
g = g.replace('versionCode = 350', 'versionCode = 351')
g = g.replace('versionName = "3.5.0-stable"', 'versionName = "3.5.1-stable"')
# support source built directly from previous 3.4 baseline if needed
g = g.replace('versionCode = 340', 'versionCode = 351')
g = g.replace('versionName = "3.4.0-stable"', 'versionName = "3.5.1-stable"')
gradle.write_text(g, encoding='utf-8')
print('Applied v3.5.1 UI/visibility/stability update to', root)
