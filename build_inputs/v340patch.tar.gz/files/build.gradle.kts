plugins { id("com.android.application") }

dependencies {
    implementation("androidx.core:core:1.16.0")
}

android {
    namespace = "com.mersad.trackerclassic"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.mersad.trackerclassic.stable"
        minSdk = 23
        targetSdk = 35
        versionCode = 340
        versionName = "3.4.0-stable"
    }
}
