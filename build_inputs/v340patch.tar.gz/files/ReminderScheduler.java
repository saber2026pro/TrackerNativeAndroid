package com.mersad.trackerclassic;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class ReminderScheduler {
    private static final String PREFS = "tracker_reminder_scheduler";
    private static final String IDS = "alarm_ids";
    private ReminderScheduler() {}

    public static void rescheduleFromDisk(Context context) {
        File f = new File(context.getFilesDir(), "tracker_state.json");
        if (!f.exists()) return;
        try (FileInputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            reschedule(context, out.toString("UTF-8"));
        } catch (Exception ignored) {}
    }

    public static synchronized void reschedule(Context context, String json) {
        cancelAll(context);
        if (json == null || json.trim().isEmpty()) return;
        try {
            JSONObject root = new JSONObject(json);
            JSONObject settings = root.optJSONObject("settings");
            if (settings != null && "لا".equals(settings.optString("alertsEnabled", "نعم"))) return;
            String defaultPreset = settings == null ? "day_before_due" : settings.optString("defaultReminderPreset", "day_before_due");
            String defaultTime = settings == null ? "09:00" : settings.optString("defaultReminderTime", "09:00");
            JSONArray patterns = settings == null ? null : settings.optJSONArray("reminderPatterns");
            JSONArray records = root.optJSONArray("records");
            if (records == null) return;
            Set<Integer> ids = new HashSet<>();
            long now = System.currentTimeMillis();
            for (int i = 0; i < records.length(); i++) {
                JSONObject r = records.optJSONObject(i); if (r == null) continue;
                String status = r.optString("status", "");
                if ("منجزة".equals(status) || "ملغية".equals(status)) continue;
                String recordId = r.optString("id", "");
                String uid = r.optString("uid", recordId);
                String subject = r.optString("subject", "عمل متابعة");
                String type = r.optString("type", "متابعة");
                String expected = r.optString("expectedDate", "");
                String preset = r.optString("reminderPreset", "default");
                if ("default".equals(preset)) preset = defaultPreset;

                if (preset.startsWith("pattern:")) {
                    JSONObject p = findPattern(patterns, preset.substring("pattern:".length()));
                    if (p != null) schedulePattern(context, ids, now, uid, recordId, subject, type, expected, p);
                } else {
                    List<When> whens = presetTimes(preset, expected, defaultTime);
                    int base = 0;
                    for (When w : whens) {
                        if (w.at < now - 60000L) continue;
                        String group = uid + "|builtin|" + preset + "|" + w.at + "|" + (base++);
                        scheduleOccurrence(context, ids, group, 0, w.at, type + " · " + recordId, subject + " — " + w.label, recordId, false, false);
                    }
                }

                JSONArray custom = r.optJSONArray("customReminders");
                if (custom != null) for (int j = 0; j < custom.length(); j++) {
                    JSONObject c = custom.optJSONObject(j); if (c == null || "لا".equals(c.optString("enabled", "نعم"))) continue;
                    String date = c.optString("date", ""), time = c.optString("time", defaultTime);
                    long at = parseMillis(date, time); if (at < now - 60000L) continue;
                    String group = uid + "|custom|" + c.optString("rid", String.valueOf(j)) + "|" + at;
                    scheduleOccurrence(context, ids, group, 0, at, type + " · " + recordId, subject + " — تنبيه مخصص", recordId, false, false);
                }
            }
            saveIds(context, ids);
        } catch (Exception ignored) {}
    }

    private static JSONObject findPattern(JSONArray patterns, String id) {
        if (patterns == null || id == null) return null;
        for (int i = 0; i < patterns.length(); i++) {
            JSONObject p = patterns.optJSONObject(i);
            if (p != null && id.equals(p.optString("id", ""))) return p;
        }
        return null;
    }

    private static void schedulePattern(Context context, Set<Integer> ids, long now, String uid, String recordId, String subject, String type, String expected, JSONObject p) {
        if (expected == null || expected.isEmpty()) return;
        JSONArray offsets = p.optJSONArray("offsetsDays");
        JSONArray times = p.optJSONArray("times");
        if (offsets == null || offsets.length() == 0 || times == null || times.length() == 0) return;
        int repeatCount = Math.max(1, Math.min(20, p.optInt("repeatCount", 1)));
        int gap = Math.max(1, Math.min(1440, p.optInt("repeatIntervalMinutes", 30)));
        boolean repeatAfterOpen = !"لا".equals(p.optString("repeatAfterOpen", "نعم"));
        boolean persistentSound = "نعم".equals(p.optString("persistentSound", "لا"));
        String name = p.optString("name", "نمط تنبيه");
        int baseIndex = 0;
        for (int oi = 0; oi < offsets.length(); oi++) {
            int days = offsets.optInt(oi, -1);
            for (int ti = 0; ti < times.length(); ti++) {
                String time = times.optString(ti, "09:00");
                long baseAt = parseOffsetMillis(expected, time, days);
                if (baseAt <= 0) continue;
                String group = uid + "|pattern|" + p.optString("id", "PAT") + "|" + baseAt + "|" + (baseIndex++);
                for (int repeat = 0; repeat < repeatCount; repeat++) {
                    long at = baseAt + (long) repeat * gap * 60000L;
                    if (at < now - 60000L) continue;
                    String suffix = repeatCount > 1 ? " · تكرار " + (repeat + 1) + "/" + repeatCount : "";
                    String msg = subject + " — " + name + suffix;
                    scheduleOccurrence(context, ids, group, repeat, at, type + " · " + recordId, msg, recordId, persistentSound, repeatAfterOpen);
                }
            }
        }
    }

    private static List<When> presetTimes(String preset, String expected, String time) {
        List<When> out = new ArrayList<>();
        if (expected == null || expected.isEmpty() || "none".equals(preset)) return out;
        if ("due".equals(preset)) addOffset(out, expected, time, 0, "موعدها اليوم");
        else if ("three_days_due".equals(preset)) { addOffset(out, expected, time, -3, "متبقي 3 أيام"); addOffset(out, expected, time, 0, "موعدها اليوم"); }
        else if ("week_due".equals(preset)) { addOffset(out, expected, time, -7, "متبقي أسبوع"); addOffset(out, expected, time, 0, "موعدها اليوم"); }
        else { addOffset(out, expected, time, -1, "متبقي يوم واحد"); addOffset(out, expected, time, 0, "موعدها اليوم"); }
        return out;
    }

    private static void addOffset(List<When> out, String date, String time, int days, String label) {
        long at = parseOffsetMillis(date, time, days); if (at > 0) out.add(new When(at, label));
    }

    private static long parseOffsetMillis(String date, String time, int days) {
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US); df.setLenient(false);
            Date d = df.parse(date); if (d == null) return -1;
            Calendar c = Calendar.getInstance(); c.setTime(d); c.add(Calendar.DAY_OF_MONTH, days);
            String[] tt = (time == null ? "09:00" : time).split(":");
            c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(tt[0])); c.set(Calendar.MINUTE, tt.length > 1 ? Integer.parseInt(tt[1]) : 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
            return c.getTimeInMillis();
        } catch (Exception ignored) { return -1; }
    }

    private static long parseMillis(String date, String time) { return parseOffsetMillis(date, time, 0); }

    private static void scheduleOccurrence(Context context, Set<Integer> ids, String group, int occurrence, long at, String title, String message, String recordId, boolean persistentSound, boolean repeatAfterOpen) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE); if (am == null) return;
        int id = stableId(group + "|" + occurrence);
        Intent i = new Intent(context, ReminderReceiver.class)
                .putExtra("id", id).putExtra("title", title).putExtra("message", message).putExtra("record_id", recordId)
                .putExtra("reminder_group", group).putExtra("persistent_sound", persistentSound).putExtra("repeat_after_open", repeatAfterOpen);
        PendingIntent pi = PendingIntent.getBroadcast(context, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        ids.add(id);
    }

    public static void cancelGroup(Context context, String group) {
        if (group == null || group.isEmpty()) return;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < 100; i++) {
            int id = stableId(group + "|" + i);
            Intent in = new Intent(context, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, id, in, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { if (am != null) am.cancel(pi); pi.cancel(); }
        }
    }

    private static void cancelAll(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE); if (am == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = sp.getString(IDS, ""); if (raw == null || raw.isEmpty()) return;
        for (String s : raw.split(",")) try {
            int id = Integer.parseInt(s);
            Intent i = new Intent(context, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, id, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        } catch (Exception ignored) {}
        sp.edit().remove(IDS).apply();
    }

    private static void saveIds(Context context, Set<Integer> ids) {
        StringBuilder b = new StringBuilder(); for (Integer id : ids) { if (b.length() > 0) b.append(','); b.append(id); }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(IDS, b.toString()).apply();
    }

    private static int stableId(String s) { int h = s == null ? 1 : s.hashCode(); h &= 0x7fffffff; return h == 0 ? 1 : h; }
    private static final class When { final long at; final String label; When(long at, String label) { this.at = at; this.label = label; } }
}
