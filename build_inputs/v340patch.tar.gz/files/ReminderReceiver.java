package com.mersad.trackerclassic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "tracker_alerts";
    private static final String ACTION_STOP = "com.mersad.trackerclassic.STOP_REMINDER";

    @Override public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", 1);
        String group = intent.getStringExtra("reminder_group");
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (ACTION_STOP.equals(intent.getAction())) {
            ReminderScheduler.cancelGroup(context, group);
            nm.cancel(id);
            return;
        }

        String title = intent.getStringExtra("title"), msg = intent.getStringExtra("message"), recordId = intent.getStringExtra("record_id");
        boolean persistent = intent.getBooleanExtra("persistent_sound", false);
        boolean repeatAfterOpen = intent.getBooleanExtra("repeat_after_open", false);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "تنبيهات المتابعة", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيهات السجلات والمواعيد"); ch.enableVibration(true); ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC); nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("record_id", recordId).putExtra("reminder_group", group).putExtra("repeat_after_open", repeatAfterOpen);
        PendingIntent content = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title == null ? "نظام المتابعة" : title)
                .setContentText(msg == null ? "لديك تنبيه مستحق" : msg)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(msg == null ? "لديك تنبيه مستحق" : msg))
                .setContentIntent(content).setPriority(NotificationCompat.PRIORITY_HIGH).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setAutoCancel(false);

        if (persistent) {
            Intent stop = new Intent(context, ReminderReceiver.class).setAction(ACTION_STOP).putExtra("id", id).putExtra("reminder_group", group);
            PendingIntent stopPi = PendingIntent.getBroadcast(context, id ^ 0x45A51, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.setOngoing(true).addAction(android.R.drawable.ic_media_pause, "إيقاف التنبيه", stopPi);
        }
        Notification n = b.build();
        if (persistent) n.flags |= Notification.FLAG_INSISTENT | Notification.FLAG_ONGOING_EVENT;
        nm.notify(id, n);
    }
}
