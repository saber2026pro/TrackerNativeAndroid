package ye.tracker.nativeapp;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.util.Calendar;
import java.util.Date;

public final class NotificationScheduler {
    public static final String CHANNEL="tracker_due";
    public static final String ACTION_DAILY="ye.tracker.nativeapp.DAILY_ALERT_CHECK";
    public static final String ACTION_RECORD_ALERT="ye.tracker.nativeapp.RECORD_ALERT";
    public static final String EXTRA_ALERT_UID="alert_uid";
    private NotificationScheduler(){}

    public static void ensureChannel(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager n=c.getSystemService(NotificationManager.class);
            if(n!=null){
                NotificationChannel ch=new NotificationChannel(CHANNEL,"تنبيهات المتابعة",NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("التنبيهات الافتراضية والمخصصة للأعمال");ch.enableVibration(true);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);n.createNotificationChannel(ch);
            }
        }
    }

    public static void scheduleDaily(Context c){
        AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(a==null)return;
        Intent i=new Intent(c,NotificationReceiver.class).setAction(ACTION_DAILY);
        PendingIntent p=PendingIntent.getBroadcast(c,9101,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar x=Calendar.getInstance();x.set(Calendar.HOUR_OF_DAY,9);x.set(Calendar.MINUTE,0);x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);if(x.getTimeInMillis()<=System.currentTimeMillis())x.add(Calendar.DAY_OF_YEAR,1);
        a.setInexactRepeating(AlarmManager.RTC_WAKEUP,x.getTimeInMillis(),AlarmManager.INTERVAL_DAY,p);
    }

    public static void scheduleAlert(Context c,String uid,String targetAt){
        if(uid==null||targetAt==null)return;try{
            Date d=TimeUtil.parseLocalDateTime(targetAt);long when=d.getTime();if(when<=System.currentTimeMillis())return;
            AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(a==null)return;
            Intent i=new Intent(c,NotificationReceiver.class).setAction(ACTION_RECORD_ALERT).putExtra(EXTRA_ALERT_UID,uid);
            PendingIntent p=PendingIntent.getBroadcast(c,requestCode(uid),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=31){if(a.canScheduleExactAlarms())a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);}else if(Build.VERSION.SDK_INT>=23)a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);else a.setExact(AlarmManager.RTC_WAKEUP,when,p);
        }catch(Exception ignored){}
    }

    public static void cancelAlert(Context c,String uid){
        if(uid==null)return;AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(a==null)return;Intent i=new Intent(c,NotificationReceiver.class).setAction(ACTION_RECORD_ALERT);PendingIntent p=PendingIntent.getBroadcast(c,requestCode(uid),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(p!=null){a.cancel(p);p.cancel();}
    }

    static int requestCode(String uid){int x=uid.hashCode();return 20000+(x==Integer.MIN_VALUE?0:Math.abs(x%100000000));}
}
