package ye.tracker.nativeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Device-to-device exchange package with record/follow-up lineage detection.
 * New entities are merged automatically. Existing changed entities are staged
 * for explicit review instead of being overwritten silently.
 */
public final class SyncPackageManager {
    private SyncPackageManager() {}

    private static final String[] RECORD_FIELDS={"record_no","subject","type","start_date","expected_date","assignee","agency","status","completion_date","notes"};
    private static final String[] FOLLOWUP_FIELDS={"event_at","text"};

    public static void exportPackage(Context context, DatabaseHelper helper, OutputStream output) throws Exception {
        if(!AccessPolicy.canExport(helper)) throw new SecurityException("لا توجد صلاحية للتصدير");
        checkpoint(helper);
        String packageId=UUID.randomUUID().toString();
        JSONObject manifest=new JSONObject();
        manifest.put("format","TRACKER_SYNC_V1");
        manifest.put("package_id",packageId);
        manifest.put("created_at",TimeUtil.nowIso());
        manifest.put("source_device_id",helper.deviceId());
        manifest.put("source_device_name",helper.deviceName());
        manifest.put("source_user_name",helper.phoneUserName());
        manifest.put("source_user_role",helper.phoneUserRole());
        manifest.put("app_version","3.0.0-native");

        SQLiteDatabase db=helper.getReadableDatabase();
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(output))){
            putText(zip,"manifest.json",manifest.toString());
            writeQueryNdjson(zip,"record_revisions.ndjson",db,"SELECT revision_uid,record_uid,parent_revision_uid,snapshot_json,device_id,actor_name,actor_role,source,operation,created_at FROM record_revisions ORDER BY _id",null);
            writeQueryNdjson(zip,"followup_revisions.ndjson",db,"SELECT revision_uid,followup_uid,record_uid,parent_revision_uid,event_at,text,deleted,device_id,actor_name,actor_role,source,operation,created_at FROM followup_revisions ORDER BY _id",null);
            writeQueryNdjson(zip,"records.ndjson",db,"SELECT uid,record_no,subject,type,start_date,expected_date,assignee,agency,status,completion_date,notes,origin_device_id,updated_device_id,created_at,updated_at,current_revision_uid,deleted FROM records ORDER BY _id",null);
            writeQueryNdjson(zip,"followups.ndjson",db,"SELECT uid,record_uid,event_at,text,origin_device_id,updated_device_id,created_at,updated_at,current_revision_uid,deleted FROM followups ORDER BY _id",null);
            writeAttachments(zip,context,db);
            writeQueryNdjson(zip,"deletion_tombstones.ndjson",db,"SELECT uid,entity_type,entity_uid,record_uid,deleted_at,deleted_by_device,revision_uid FROM deletion_tombstones ORDER BY _id",null);
        }
        logExchange(helper,"EXPORT",packageId,null,null,0,0,0,0);
    }

    /** Extracts and classifies a sync package. Returns the import id used by review UI. */
    public static String stageImport(Context context, DatabaseHelper helper, InputStream input) throws Exception {
        if(!AccessPolicy.canImport(helper)) throw new SecurityException("الاستيراد متاح لمسؤول النظام فقط");
        String tempId=UUID.randomUUID().toString();
        File dir=new File(context.getFilesDir(),"sync_imports/"+tempId);
        if(!dir.mkdirs()&&!dir.isDirectory()) throw new IOException("تعذر إنشاء مجلد الاستيراد");
        extractSafe(input,dir);
        JSONObject manifest=readJson(new File(dir,"manifest.json"));
        if(!"TRACKER_SYNC_V1".equals(manifest.optString("format"))) throw new IOException("صيغة حزمة المزامنة غير مدعومة");
        String packageId=manifest.optString("package_id","");
        if(packageId.isEmpty()) throw new IOException("معرف الحزمة مفقود");
        String prior=findExistingImport(helper,packageId);
        if(prior!=null){deleteTree(dir);return prior;}

        String importId=UUID.randomUUID().toString();
        File finalDir=new File(context.getFilesDir(),"sync_imports/"+importId);
        if(!dir.renameTo(finalDir)){copyTree(dir,finalDir);deleteTree(dir);}
        helper.setSetting("import_path_"+importId,finalDir.getAbsolutePath());

        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        int newCount=0, changed=0, conflicts=0, unchanged=0;
        try{
            cacheRevisions(db,importId,"RECORD",new File(finalDir,"record_revisions.ndjson"));
            cacheRevisions(db,importId,"FOLLOWUP",new File(finalDir,"followup_revisions.ndjson"));

            StageStats rs=stageRecords(helper,db,importId,new File(finalDir,"records.ndjson"));
            newCount+=rs.added;changed+=rs.changed;conflicts+=rs.conflicts;unchanged+=rs.unchanged;
            StageStats fs=stageFollowups(helper,db,importId,new File(finalDir,"followups.ndjson"));
            newCount+=fs.added;changed+=fs.changed;conflicts+=fs.conflicts;unchanged+=fs.unchanged;
            StageStats ds=stageDeletes(helper,db,importId,new File(finalDir,"deletion_tombstones.ndjson"));
            changed+=ds.changed;conflicts+=ds.conflicts;unchanged+=ds.unchanged;

            importAttachments(context,helper,db,importId,finalDir,new File(finalDir,"attachments.ndjson"));
            db.execSQL("INSERT INTO exchange_log(uid,kind,package_id,peer_device_id,peer_name,created_at,new_count,changed_count,conflict_count,unchanged_count) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    new Object[]{importId,"IMPORT",packageId,manifest.optString("source_device_id",null),manifest.optString("source_user_name",manifest.optString("source_device_name",null)),TimeUtil.nowIso(),newCount,changed,conflicts,unchanged});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return importId;
    }

    public static Cursor pendingCursor(DatabaseHelper helper,String importId){
        return helper.getReadableDatabase().rawQuery(
                "SELECT i._id,i.entity_type,i.entity_uid,i.record_uid,i.kind,i.local_json,i.incoming_json,i.diff_json,i.decision,"+
                "COALESCE(r.display_id,'') AS display_id,COALESCE(r.subject,'') AS subject,"+
                "COALESCE(x.peer_name,'') AS peer_name,COALESCE(x.peer_device_id,'') AS peer_device_id,"+
                "COALESCE((SELECT ir.payload_json FROM import_revisions ir WHERE ir.import_id=i.import_id AND ir.entity_type=i.entity_type AND ir.revision_uid=i.incoming_revision_uid LIMIT 1),'') AS revision_payload "+
                "FROM import_items i "+
                "LEFT JOIN records r ON r.uid=i.record_uid "+
                "LEFT JOIN exchange_log x ON x.uid=i.import_id "+
                "WHERE i.import_id=? AND i.decision='PENDING' ORDER BY i._id",
                new String[]{importId});
    }

    public static int pendingCount(DatabaseHelper helper,String importId){
        try(Cursor c=helper.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM import_items WHERE import_id=? AND decision='PENDING'",new String[]{importId})){c.moveToFirst();return c.getInt(0);}
    }

    public static void keepLocal(DatabaseHelper helper,long itemId){
        if(!AccessPolicy.canImport(helper))throw new SecurityException("يلزم مسؤول النظام");
        helper.getWritableDatabase().execSQL("UPDATE import_items SET decision='KEEP_LOCAL',resolved_at=? WHERE _id=? AND decision='PENDING'",new Object[]{TimeUtil.nowIso(),itemId});
    }

    public static void acceptIncoming(DatabaseHelper helper,long itemId) throws Exception {
        if(!AccessPolicy.canImport(helper))throw new SecurityException("يلزم مسؤول النظام");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try(Cursor c=db.rawQuery("SELECT import_id,entity_type,entity_uid,record_uid,kind,local_json,incoming_json FROM import_items WHERE _id=? AND decision='PENDING'",new String[]{String.valueOf(itemId)})){
            if(!c.moveToFirst())return;
            String importId=c.getString(0), entity=c.getString(1), entityUid=c.getString(2), recordUid=c.getString(3), kind=c.getString(4);
            JSONObject incoming=c.isNull(6)?new JSONObject():new JSONObject(c.getString(6));
            if("DELETE".equals(kind)){
                applyDelete(helper,db,importId,entity,entityUid,recordUid,incoming);
            }else if("EXCEL_UPDATE".equals(kind)&&"RECORD".equals(entity)){
                applyExcelRecord(helper,db,importId,entityUid,incoming);
            }else if("RECORD".equals(entity)){
                applyIncomingRecord(helper,db,importId,incoming,false,null);
            }else if("FOLLOWUP".equals(entity)){
                applyIncomingFollowup(helper,db,importId,incoming,false);
            }
            db.execSQL("UPDATE import_items SET decision='ACCEPT_INCOMING',resolved_at=? WHERE _id=?",new Object[]{TimeUtil.nowIso(),itemId});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    /** Merge only selected changed record fields from incoming; local fields remain otherwise. */
    public static void mergeRecordFields(DatabaseHelper helper,long itemId,Set<String> incomingFields) throws Exception {
        if(!AccessPolicy.canImport(helper))throw new SecurityException("يلزم مسؤول النظام");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try(Cursor c=db.rawQuery("SELECT import_id,entity_type,record_uid,local_json,incoming_json FROM import_items WHERE _id=? AND decision='PENDING'",new String[]{String.valueOf(itemId)})){
            if(!c.moveToFirst())return;
            String importId=c.getString(0),entity=c.getString(1),recordUid=c.getString(2);
            if(!"RECORD".equals(entity))throw new IllegalArgumentException("الدمج على مستوى الحقول متاح للسجل الرئيسي فقط");
            JSONObject local=new JSONObject(c.getString(3)), incoming=new JSONObject(c.getString(4));
            JSONObject merged=new JSONObject(local.toString());
            for(String f:incomingFields) if(incoming.has(f)) merged.put(f,incoming.isNull(f)?JSONObject.NULL:incoming.opt(f));
            String parent=localCurrentRevision(db,recordUid,"RECORD"), newRev=UUID.randomUUID().toString();
            updateRecordCore(db,recordUid,merged,newRev,helper.deviceId());
            JSONObject snap=recordSnapshotCore(db,recordUid);
            db.execSQL("INSERT INTO record_revisions(revision_uid,record_uid,parent_revision_uid,snapshot_json,device_id,actor_name,actor_role,source,operation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    new Object[]{newRev,recordUid,parent,snap.toString(),helper.deviceId(),helper.actorName(),helper.deviceRole(),"استيراد","دمج حقول",TimeUtil.nowIso()});
            auditDiff(helper,db,"RECORD",recordUid,recordUid,"MERGE","استيراد",local,merged,importId);
            copyCachedRevisionsToLive(db,importId,"RECORD",recordUid);
            db.execSQL("UPDATE import_items SET decision='MERGED',resolved_at=? WHERE _id=?",new Object[]{TimeUtil.nowIso(),itemId});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    public static void cleanupIfResolved(Context context,DatabaseHelper helper,String importId){
        if(pendingCount(helper,importId)>0)return;
        String p=helper.setting("import_path_"+importId,"");
        if(!p.isEmpty())deleteTree(new File(p));
        helper.setSetting("import_path_"+importId,"");
        helper.getWritableDatabase().delete("import_revisions","import_id=?",new String[]{importId});
    }

    private static StageStats stageRecords(DatabaseHelper helper,SQLiteDatabase db,String importId,File file)throws Exception{
        StageStats s=new StageStats();if(!file.isFile())return s;
        forEachJsonLine(file,o->{
            String uid=o.optString("uid"), incomingRev=o.optString("current_revision_uid");
            JSONObject incoming=pick(o,RECORD_FIELDS);incoming.put("uid",uid);incoming.put("current_revision_uid",incomingRev);
            JSONObject local=localRecord(db,uid);
            if(local==null){applyIncomingRecord(helper,db,importId,o,true,null);s.added++;return;}
            String localRev=local.optString("current_revision_uid");
            if(incomingRev.equals(localRev)){s.unchanged++;return;}
            if(isIncomingDescendant(db,importId,"RECORD",uid,incomingRev,localRev)){
                stageItem(db,importId,"RECORD",uid,uid,"UPDATE",local,o,diff(local,incoming));s.changed++;
            }else if(isLocalDescendant(db,"RECORD",uid,localRev,incomingRev)){
                s.unchanged++;
            }else{
                stageItem(db,importId,"RECORD",uid,uid,"CONFLICT",local,o,diff(local,incoming));s.conflicts++;
            }
        });return s;
    }

    private static StageStats stageFollowups(DatabaseHelper helper,SQLiteDatabase db,String importId,File file)throws Exception{
        StageStats s=new StageStats();if(!file.isFile())return s;
        forEachJsonLine(file,o->{
            String uid=o.optString("uid"),recordUid=o.optString("record_uid"),incomingRev=o.optString("current_revision_uid");
            if(!recordExists(db,recordUid)){s.conflicts++;stageItem(db,importId,"FOLLOWUP",uid,recordUid,"CONFLICT",null,o,new JSONObject().put("reason","السجل الرئيسي غير موجود"));return;}
            JSONObject incoming=pick(o,FOLLOWUP_FIELDS);incoming.put("uid",uid);incoming.put("record_uid",recordUid);incoming.put("current_revision_uid",incomingRev);
            JSONObject local=localFollowup(db,uid);
            if(local==null){applyIncomingFollowup(helper,db,importId,o,true);s.added++;return;}
            String localRev=local.optString("current_revision_uid");
            if(incomingRev.equals(localRev)){s.unchanged++;return;}
            if(isIncomingDescendant(db,importId,"FOLLOWUP",uid,incomingRev,localRev)){
                stageItem(db,importId,"FOLLOWUP",uid,recordUid,"UPDATE",local,o,diff(local,incoming));s.changed++;
            }else if(isLocalDescendant(db,"FOLLOWUP",uid,localRev,incomingRev)){
                s.unchanged++;
            }else{
                stageItem(db,importId,"FOLLOWUP",uid,recordUid,"CONFLICT",local,o,diff(local,incoming));s.conflicts++;
            }
        });return s;
    }

    private static StageStats stageDeletes(DatabaseHelper helper,SQLiteDatabase db,String importId,File file)throws Exception{
        StageStats s=new StageStats();if(!file.isFile())return s;
        forEachJsonLine(file,o->{
            String entity=o.optString("entity_type"),uid=o.optString("entity_uid"),recordUid=o.optString("record_uid",uid),tombUid=o.optString("uid");
            if(!tombUid.isEmpty()){try(Cursor known=db.rawQuery("SELECT 1 FROM deletion_tombstones WHERE uid=? LIMIT 1",new String[]{tombUid})){if(known.moveToFirst()){s.unchanged++;return;}}}
            boolean exists="RECORD".equals(entity)?recordExists(db,uid):followupExists(db,uid);
            if(!exists){s.unchanged++;return;}
            JSONObject local="RECORD".equals(entity)?localRecord(db,uid):localFollowup(db,uid);
            stageItem(db,importId,entity,uid,recordUid,"DELETE",local,o,new JSONObject().put("delete","طلب حذف وارد"));s.changed++;
        });return s;
    }

    private static void applyIncomingRecord(DatabaseHelper helper,SQLiteDatabase db,String importId,JSONObject incoming,boolean isNew,Set<String> selectedFields)throws Exception{
        String uid=incoming.optString("uid"),incomingRev=incoming.optString("current_revision_uid");
        if(isNew){
            long seq=nextSeq(db);String display="W-"+String.format(Locale.US,"%06d",seq);
            ContentValues v=new ContentValues();v.put("uid",uid);v.put("seq",seq);v.put("display_id",display);
            putRecordFields(v,incoming,RECORD_FIELDS);
            v.put("origin_device_id",incoming.optString("origin_device_id",helper.deviceId()));v.put("updated_device_id",incoming.optString("updated_device_id",incoming.optString("origin_device_id",helper.deviceId())));
            v.put("created_at",incoming.optString("created_at",TimeUtil.nowIso()));v.put("updated_at",incoming.optString("updated_at",TimeUtil.nowIso()));v.put("current_revision_uid",incomingRev);v.put("deleted",incoming.optInt("deleted",0));
            db.insertOrThrow("records",null,v);copyCachedRevisionsToLive(db,importId,"RECORD",uid);
            auditDiff(helper,db,"RECORD",uid,uid,"IMPORT_ADD","استيراد",null,pick(incoming,RECORD_FIELDS),importId);
        }else{
            JSONObject old=localRecord(db,uid);copyCachedRevisionsToLive(db,importId,"RECORD",uid);
            updateRecordCore(db,uid,incoming,incomingRev,incoming.optString("updated_device_id",incoming.optString("origin_device_id",helper.deviceId())));
            auditDiff(helper,db,"RECORD",uid,uid,"IMPORT_ACCEPT","استيراد",old,pick(incoming,RECORD_FIELDS),importId);
        }
    }

    private static void applyIncomingFollowup(DatabaseHelper helper,SQLiteDatabase db,String importId,JSONObject incoming,boolean isNew)throws Exception{
        String uid=incoming.optString("uid"),recordUid=incoming.optString("record_uid"),incomingRev=incoming.optString("current_revision_uid");
        if(isNew){
            ContentValues v=new ContentValues();v.put("uid",uid);v.put("record_uid",recordUid);putJson(v,"event_at",incoming);putJson(v,"text",incoming);
            v.put("origin_device_id",incoming.optString("origin_device_id",helper.deviceId()));v.put("updated_device_id",incoming.optString("updated_device_id",incoming.optString("origin_device_id",helper.deviceId())));
            v.put("created_at",incoming.optString("created_at",TimeUtil.nowIso()));v.put("updated_at",incoming.optString("updated_at",TimeUtil.nowIso()));v.put("current_revision_uid",incomingRev);v.put("deleted",incoming.optInt("deleted",0));
            db.insertOrThrow("followups",null,v);copyCachedRevisionsToLive(db,importId,"FOLLOWUP",uid);
            auditDiff(helper,db,"FOLLOWUP",uid,recordUid,"IMPORT_ADD","استيراد",null,pick(incoming,FOLLOWUP_FIELDS),importId);
        }else{
            JSONObject old=localFollowup(db,uid);copyCachedRevisionsToLive(db,importId,"FOLLOWUP",uid);
            ContentValues v=new ContentValues();putJson(v,"event_at",incoming);putJson(v,"text",incoming);v.put("updated_device_id",incoming.optString("updated_device_id",helper.deviceId()));v.put("updated_at",incoming.optString("updated_at",TimeUtil.nowIso()));v.put("current_revision_uid",incomingRev);v.put("deleted",incoming.optInt("deleted",0));
            db.update("followups",v,"uid=?",new String[]{uid});auditDiff(helper,db,"FOLLOWUP",uid,recordUid,"IMPORT_ACCEPT","استيراد",old,pick(incoming,FOLLOWUP_FIELDS),importId);
        }
        db.execSQL("UPDATE records SET updated_at=? WHERE uid=?",new Object[]{TimeUtil.nowIso(),recordUid});
    }

    private static void applyExcelRecord(DatabaseHelper helper,SQLiteDatabase db,String importId,String recordUid,JSONObject incoming)throws Exception{
        JSONObject old=localRecord(db,recordUid);if(old==null)throw new IllegalArgumentException("السجل المحلي غير موجود");
        String parent=old.optString("current_revision_uid",null),newRev=UUID.randomUUID().toString();incoming.put("uid",recordUid);
        updateRecordCore(db,recordUid,incoming,newRev,helper.deviceId());JSONObject snap=recordSnapshotCore(db,recordUid);
        db.execSQL("INSERT INTO record_revisions(revision_uid,record_uid,parent_revision_uid,snapshot_json,device_id,actor_name,actor_role,source,operation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                new Object[]{newRev,recordUid,parent,snap.toString(),helper.deviceId(),helper.actorName(),helper.deviceRole(),"استيراد Excel","تعديل",TimeUtil.nowIso()});
        auditDiff(helper,db,"RECORD",recordUid,recordUid,"IMPORT_EXCEL_EDIT","استيراد Excel",old,incoming,importId);
    }

    private static void applyDelete(DatabaseHelper helper,SQLiteDatabase db,String importId,String entity,String entityUid,String recordUid,JSONObject tomb)throws Exception{
        JSONObject old="RECORD".equals(entity)?localRecord(db,entityUid):localFollowup(db,entityUid);if(old==null)return;
        String revision=tomb.optString("revision_uid",UUID.randomUUID().toString());copyCachedRevisionsToLive(db,importId,entity,entityUid);String now=TimeUtil.nowIso();
        if("RECORD".equals(entity))db.execSQL("UPDATE records SET deleted=1,updated_at=?,updated_device_id=?,current_revision_uid=? WHERE uid=?",new Object[]{now,helper.deviceId(),revision,entityUid});
        else db.execSQL("UPDATE followups SET deleted=1,updated_at=?,updated_device_id=?,current_revision_uid=? WHERE uid=?",new Object[]{now,helper.deviceId(),revision,entityUid});
        db.execSQL("INSERT OR IGNORE INTO deletion_tombstones(uid,entity_type,entity_uid,record_uid,deleted_at,deleted_by_device,revision_uid) VALUES(?,?,?,?,?,?,?)",new Object[]{tomb.optString("uid",UUID.randomUUID().toString()),entity,entityUid,recordUid,tomb.optString("deleted_at",now),tomb.optString("deleted_by_device",helper.deviceId()),revision});
        auditDiff(helper,db,entity,entityUid,recordUid,"IMPORT_DELETE","استيراد",old,null,importId);
    }

    private static void cacheRevisions(SQLiteDatabase db,String importId,String type,File file)throws Exception{
        if(!file.isFile())return;
        forEachJsonLine(file,o->{String entityUid="RECORD".equals(type)?o.optString("record_uid"):o.optString("followup_uid");String recordUid=o.optString("record_uid",entityUid);
            db.execSQL("INSERT OR IGNORE INTO import_revisions(import_id,entity_type,entity_uid,record_uid,revision_uid,parent_revision_uid,payload_json) VALUES(?,?,?,?,?,?,?)",
                    new Object[]{importId,type,entityUid,recordUid,o.optString("revision_uid"),nullIfEmpty(o.optString("parent_revision_uid",null)),o.toString()});});
    }

    private static void copyCachedRevisionsToLive(SQLiteDatabase db,String importId,String type,String entityUid)throws Exception{
        try(Cursor c=db.rawQuery("SELECT payload_json FROM import_revisions WHERE import_id=? AND entity_type=? AND entity_uid=? ORDER BY _id",new String[]{importId,type,entityUid})){
            while(c.moveToNext()){
                JSONObject o=new JSONObject(c.getString(0));
                if("RECORD".equals(type)){
                    db.execSQL("INSERT OR IGNORE INTO record_revisions(revision_uid,record_uid,parent_revision_uid,snapshot_json,device_id,actor_name,actor_role,source,operation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            new Object[]{o.optString("revision_uid"),o.optString("record_uid"),nullIfEmpty(o.optString("parent_revision_uid",null)),o.optString("snapshot_json","{}"),o.optString("device_id",""),nullIfEmpty(o.optString("actor_name",null)),nullIfEmpty(o.optString("actor_role",null)),o.optString("source","استيراد"),o.optString("operation","تعديل"),o.optString("created_at",TimeUtil.nowIso())});
                }else{
                    db.execSQL("INSERT OR IGNORE INTO followup_revisions(revision_uid,followup_uid,record_uid,parent_revision_uid,event_at,text,deleted,device_id,actor_name,actor_role,source,operation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            new Object[]{o.optString("revision_uid"),o.optString("followup_uid"),o.optString("record_uid"),nullIfEmpty(o.optString("parent_revision_uid",null)),o.optString("event_at"),o.optString("text"),o.optInt("deleted",0),o.optString("device_id",""),nullIfEmpty(o.optString("actor_name",null)),nullIfEmpty(o.optString("actor_role",null)),o.optString("source","استيراد"),o.optString("operation","تعديل"),o.optString("created_at",TimeUtil.nowIso())});
                }
            }
        }
    }

    private static void importAttachments(Context context,DatabaseHelper helper,SQLiteDatabase db,String importId,File dir,File meta)throws Exception{
        if(!meta.isFile())return;
        forEachJsonLine(meta,o->{
            String uid=o.optString("uid"),recordUid=o.optString("record_uid");if(uid.isEmpty()||!recordExists(db,recordUid))return;
            try(Cursor ex=db.rawQuery("SELECT 1 FROM attachments WHERE uid=? LIMIT 1",new String[]{uid})){if(ex.moveToFirst())return;}
            String sha=o.optString("sha256"),size=String.valueOf(o.optLong("size_bytes",0));
            try(Cursor dup=db.rawQuery("SELECT 1 FROM attachments WHERE record_uid=? AND sha256=? AND size_bytes=? AND deleted=0 LIMIT 1",new String[]{recordUid,sha,size})){if(dup.moveToFirst())return;}
            File src=new File(dir,o.optString("zip_entry"));if(!src.isFile())return;
            File targetDir=new File(context.getFilesDir(),"attachments/"+recordUid);if(!targetDir.exists()&&!targetDir.mkdirs())throw new IOException("تعذر إنشاء مجلد المرفقات");
            String stored=o.optString("stored_name",uid);File dst=new File(targetDir,stored);copyFile(src,dst);
            db.execSQL("INSERT INTO attachments(uid,record_uid,followup_uid,file_name,mime_type,stored_name,relative_path,size_bytes,sha256,origin_device_id,created_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    new Object[]{uid,recordUid,nullIfEmpty(o.optString("followup_uid",null)),o.optString("file_name","attachment"),nullIfEmpty(o.optString("mime_type",null)),stored,"attachments/"+recordUid+"/"+stored,o.optLong("size_bytes",dst.length()),sha,o.optString("origin_device_id",helper.deviceId()),o.optString("created_at",TimeUtil.nowIso()),o.optInt("deleted",0)});
        });
    }

    private static void writeAttachments(ZipOutputStream zip,Context context,SQLiteDatabase db)throws Exception{
        ZipEntry meta=new ZipEntry("attachments.ndjson");zip.putNextEntry(meta);
        try(Cursor c=db.rawQuery("SELECT uid,record_uid,followup_uid,file_name,mime_type,stored_name,relative_path,size_bytes,sha256,origin_device_id,created_at,deleted FROM attachments ORDER BY _id",null)){
            while(c.moveToNext()){
                JSONObject o=rowToJson(c);String entry="attachment_files/"+safeName(o.optString("uid"));o.put("zip_entry",entry);
                zip.write(o.toString().getBytes(StandardCharsets.UTF_8));zip.write('\n');
            }
        }zip.closeEntry();
        try(Cursor c=db.rawQuery("SELECT uid,relative_path FROM attachments WHERE deleted=0 ORDER BY _id",null)){
            while(c.moveToNext()){
                File f=new File(context.getFilesDir(),c.getString(1));if(!f.isFile())continue;
                zip.putNextEntry(new ZipEntry("attachment_files/"+safeName(c.getString(0))));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){copy(in,zip);}zip.closeEntry();
            }
        }
    }

    private static void stageItem(SQLiteDatabase db,String importId,String entity,String entityUid,String recordUid,String kind,JSONObject local,JSONObject incoming,JSONObject diff){
        String incomingRev=incoming==null?null:nullIfEmpty(incoming.optString("current_revision_uid",null));
        String parent=null;
        if(incomingRev!=null){try(Cursor c=db.rawQuery("SELECT parent_revision_uid FROM import_revisions WHERE import_id=? AND entity_type=? AND entity_uid=? AND revision_uid=? LIMIT 1",new String[]{importId,entity,entityUid,incomingRev})){if(c.moveToFirst()&&!c.isNull(0))parent=c.getString(0);}}
        db.execSQL("INSERT INTO import_items(import_id,entity_type,entity_uid,record_uid,kind,local_revision_uid,incoming_revision_uid,incoming_parent_revision_uid,local_json,incoming_json,diff_json,decision) VALUES(?,?,?,?,?,?,?,?,?,?,?,'PENDING')",
                new Object[]{importId,entity,entityUid,recordUid,kind,local==null?null:nullIfEmpty(local.optString("current_revision_uid",null)),incomingRev,parent,local==null?null:local.toString(),incoming==null?null:incoming.toString(),diff==null?null:diff.toString()});
    }

    private static boolean isIncomingDescendant(SQLiteDatabase db,String importId,String type,String entityUid,String incoming,String ancestor){
        if(incoming==null||incoming.isEmpty()||ancestor==null||ancestor.isEmpty())return false;String cur=incoming;
        for(int i=0;i<10000;i++){if(ancestor.equals(cur))return true;try(Cursor c=db.rawQuery("SELECT parent_revision_uid FROM import_revisions WHERE import_id=? AND entity_type=? AND entity_uid=? AND revision_uid=? LIMIT 1",new String[]{importId,type,entityUid,cur})){if(!c.moveToFirst()||c.isNull(0))return false;cur=c.getString(0);}}
        return false;
    }

    private static boolean isLocalDescendant(SQLiteDatabase db,String type,String entityUid,String localCurrent,String ancestor){
        if(localCurrent==null||ancestor==null)return false;String table="RECORD".equals(type)?"record_revisions":"followup_revisions";String entityCol="RECORD".equals(type)?"record_uid":"followup_uid";String cur=localCurrent;
        for(int i=0;i<10000;i++){if(ancestor.equals(cur))return true;try(Cursor c=db.rawQuery("SELECT parent_revision_uid FROM "+table+" WHERE "+entityCol+"=? AND revision_uid=? LIMIT 1",new String[]{entityUid,cur})){if(!c.moveToFirst()||c.isNull(0))return false;cur=c.getString(0);}}
        return false;
    }

    private static JSONObject localRecord(SQLiteDatabase db,String uid)throws Exception{
        try(Cursor c=db.rawQuery("SELECT record_no,subject,type,start_date,expected_date,assignee,agency,status,completion_date,notes,current_revision_uid FROM records WHERE uid=? LIMIT 1",new String[]{uid})){if(!c.moveToFirst())return null;JSONObject o=rowToJson(c);o.put("uid",uid);return o;}
    }
    private static JSONObject localFollowup(SQLiteDatabase db,String uid)throws Exception{
        try(Cursor c=db.rawQuery("SELECT record_uid,event_at,text,current_revision_uid FROM followups WHERE uid=? LIMIT 1",new String[]{uid})){if(!c.moveToFirst())return null;JSONObject o=rowToJson(c);o.put("uid",uid);return o;}
    }
    private static String localCurrentRevision(SQLiteDatabase db,String uid,String type){
        String table="RECORD".equals(type)?"records":"followups";try(Cursor c=db.rawQuery("SELECT current_revision_uid FROM "+table+" WHERE uid=?",new String[]{uid})){return c.moveToFirst()?c.getString(0):null;}
    }
    private static JSONObject recordSnapshotCore(SQLiteDatabase db,String uid)throws Exception{return localRecord(db,uid);}
    private static boolean recordExists(SQLiteDatabase db,String uid){try(Cursor c=db.rawQuery("SELECT 1 FROM records WHERE uid=? LIMIT 1",new String[]{uid})){return c.moveToFirst();}}
    private static boolean followupExists(SQLiteDatabase db,String uid){try(Cursor c=db.rawQuery("SELECT 1 FROM followups WHERE uid=? LIMIT 1",new String[]{uid})){return c.moveToFirst();}}

    private static void updateRecordCore(SQLiteDatabase db,String uid,JSONObject incoming,String revision,String updatedDevice)throws Exception{
        ContentValues v=new ContentValues();putRecordFields(v,incoming,RECORD_FIELDS);v.put("current_revision_uid",revision);v.put("updated_device_id",updatedDevice);v.put("updated_at",incoming.optString("updated_at",TimeUtil.nowIso()));v.put("deleted",incoming.optInt("deleted",0));db.update("records",v,"uid=?",new String[]{uid});
    }

    private static void auditDiff(DatabaseHelper helper,SQLiteDatabase db,String entity,String entityUid,String recordUid,String operation,String source,JSONObject oldO,JSONObject newO,String importId)throws Exception{
        String event=UUID.randomUUID().toString();db.execSQL("INSERT INTO audit_events(uid,entity_type,entity_uid,record_uid,device_id,actor_name,actor_role,operation,source,occurred_at,import_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",new Object[]{event,entity,entityUid,recordUid,helper.deviceId(),helper.actorName(),helper.deviceRole(),operation,source,TimeUtil.nowIso(),importId});
        LinkedHashSet<String> keys=new LinkedHashSet<>();if(oldO!=null)for(Iterator<String> it=oldO.keys();it.hasNext();)keys.add(it.next());if(newO!=null)for(Iterator<String> it=newO.keys();it.hasNext();)keys.add(it.next());
        keys.remove("current_revision_uid");keys.remove("uid");keys.remove("record_uid");
        for(String k:keys){String a=jsonString(oldO,k),b=jsonString(newO,k);if(Objects.equals(a,b))continue;db.execSQL("INSERT INTO audit_field_changes(event_uid,field_name,old_value,new_value) VALUES(?,?,?,?)",new Object[]{event,k,a,b});}
    }

    private static JSONObject diff(JSONObject local,JSONObject incoming)throws Exception{
        JSONObject d=new JSONObject();LinkedHashSet<String> keys=new LinkedHashSet<>();if(local!=null)for(Iterator<String> it=local.keys();it.hasNext();)keys.add(it.next());if(incoming!=null)for(Iterator<String> it=incoming.keys();it.hasNext();)keys.add(it.next());keys.remove("uid");keys.remove("record_uid");keys.remove("current_revision_uid");
        for(String k:keys){String a=jsonString(local,k),b=jsonString(incoming,k);if(Objects.equals(a,b))continue;d.put(k,new JSONObject().put("old",a==null?JSONObject.NULL:a).put("new",b==null?JSONObject.NULL:b));}return d;
    }

    private static JSONObject pick(JSONObject src,String[] fields)throws Exception{JSONObject o=new JSONObject();for(String f:fields){if(src.has(f))o.put(f,src.isNull(f)?JSONObject.NULL:src.opt(f));}return o;}
    private static String jsonString(JSONObject o,String k){if(o==null||!o.has(k)||o.isNull(k))return null;return String.valueOf(o.opt(k));}
    private static void putRecordFields(ContentValues v,JSONObject o,String[] fields){for(String f:fields)putJson(v,f,o);}
    private static void putJson(ContentValues v,String key,JSONObject o){if(!o.has(key)||o.isNull(key))v.putNull(key);else v.put(key,String.valueOf(o.opt(key)));}
    private static String nullIfEmpty(String s){return s==null||s.isEmpty()?null:s;}
    private static long nextSeq(SQLiteDatabase db){try(Cursor c=db.rawQuery("SELECT COALESCE(MAX(seq),0)+1 FROM records",null)){c.moveToFirst();return c.getLong(0);}}

    private interface JsonConsumer{void accept(JSONObject o)throws Exception;}
    private static void forEachJsonLine(File file,JsonConsumer consumer)throws Exception{try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8),64*1024)){String line;while((line=r.readLine())!=null){line=line.trim();if(!line.isEmpty())consumer.accept(new JSONObject(line));}}}
    private static void writeQueryNdjson(ZipOutputStream zip,String name,SQLiteDatabase db,String sql,String[] args)throws Exception{zip.putNextEntry(new ZipEntry(name));try(Cursor c=db.rawQuery(sql,args)){while(c.moveToNext()){zip.write(rowToJson(c).toString().getBytes(StandardCharsets.UTF_8));zip.write('\n');}}zip.closeEntry();}
    private static JSONObject rowToJson(Cursor c)throws Exception{JSONObject o=new JSONObject();for(int i=0;i<c.getColumnCount();i++){String n=c.getColumnName(i);switch(c.getType(i)){case Cursor.FIELD_TYPE_NULL:o.put(n,JSONObject.NULL);break;case Cursor.FIELD_TYPE_INTEGER:o.put(n,c.getLong(i));break;case Cursor.FIELD_TYPE_FLOAT:o.put(n,c.getDouble(i));break;default:o.put(n,c.getString(i));}}return o;}
    private static void putText(ZipOutputStream zip,String name,String text)throws Exception{zip.putNextEntry(new ZipEntry(name));zip.write(text.getBytes(StandardCharsets.UTF_8));zip.closeEntry();}
    private static JSONObject readJson(File f)throws Exception{try(InputStream in=new FileInputStream(f)){ByteArrayOutputStream b=new ByteArrayOutputStream();copy(in,b);return new JSONObject(b.toString("UTF-8"));}}

    private static void extractSafe(InputStream input,File dir)throws Exception{try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(input))){ZipEntry e;byte[] buf=new byte[64*1024];while((e=zip.getNextEntry())!=null){String name=e.getName();if(name.contains("..")||name.startsWith("/")||name.startsWith("\\"))throw new IOException("مسار غير آمن داخل الحزمة");File out=new File(dir,name);String root=dir.getCanonicalPath()+File.separator;if(!out.getCanonicalPath().startsWith(root))throw new IOException("مسار غير آمن داخل الحزمة");if(e.isDirectory()){out.mkdirs();continue;}File parent=out.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("تعذر إنشاء مجلد مؤقت");try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){int n;while((n=zip.read(buf))!=-1)os.write(buf,0,n);}zip.closeEntry();}}}
    private static void copy(InputStream in,OutputStream out)throws IOException{byte[] b=new byte[64*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
    private static void copyFile(File a,File b)throws IOException{try(InputStream in=new FileInputStream(a);OutputStream out=new FileOutputStream(b)){copy(in,out);}}
    private static void copyTree(File a,File b)throws IOException{if(a.isDirectory()){if(!b.exists()&&!b.mkdirs())throw new IOException("mkdir");File[] fs=a.listFiles();if(fs!=null)for(File x:fs)copyTree(x,new File(b,x.getName()));}else copyFile(a,b);}
    private static void deleteTree(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[] xs=f.listFiles();if(xs!=null)for(File x:xs)deleteTree(x);}f.delete();}
    private static String safeName(String s){return s==null?UUID.randomUUID().toString():s.replaceAll("[^A-Za-z0-9._-]","_");}
    private static void checkpoint(DatabaseHelper helper){try{helper.getWritableDatabase().rawQuery("PRAGMA wal_checkpoint(FULL)",null).close();}catch(Exception ignored){}}

    private static String findExistingImport(DatabaseHelper helper,String packageId){try(Cursor c=helper.getReadableDatabase().rawQuery("SELECT uid FROM exchange_log WHERE kind='IMPORT' AND package_id=? ORDER BY _id DESC LIMIT 1",new String[]{packageId})){return c.moveToFirst()?c.getString(0):null;}}
    private static void logExchange(DatabaseHelper helper,String kind,String packageId,String peerDevice,String peerName,int n,int ch,int co,int u){helper.getWritableDatabase().execSQL("INSERT INTO exchange_log(uid,kind,package_id,peer_device_id,peer_name,created_at,new_count,changed_count,conflict_count,unchanged_count) VALUES(?,?,?,?,?,?,?,?,?,?)",new Object[]{UUID.randomUUID().toString(),kind,packageId,peerDevice,peerName,TimeUtil.nowIso(),n,ch,co,u});}

    private static final class StageStats{int added,changed,conflicts,unchanged;}
}
