package ye.tracker.nativeapp;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Lightweight native dashboard completion ring; no WebView or external UI library. */
public final class CompletionRingView extends View {
    private int percent;
    private final Paint track=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progress=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint number=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint caption=new Paint(Paint.ANTI_ALIAS_FLAG);

    public CompletionRingView(Context c,int pct){
        super(c); percent=Math.max(0,Math.min(100,pct));
        float d=getResources().getDisplayMetrics().density;
        track.setStyle(Paint.Style.STROKE);track.setStrokeWidth(8*d);track.setColor(Color.rgb(226,235,233));track.setStrokeCap(Paint.Cap.ROUND);
        progress.setStyle(Paint.Style.STROKE);progress.setStrokeWidth(8*d);progress.setColor(Color.rgb(47,111,102));progress.setStrokeCap(Paint.Cap.ROUND);
        number.setColor(Color.rgb(23,42,45));number.setTextAlign(Paint.Align.CENTER);number.setTypeface(Typeface.DEFAULT_BOLD);number.setTextSize(20*d);
        caption.setColor(Color.rgb(104,118,120));caption.setTextAlign(Paint.Align.CENTER);caption.setTextSize(10*d);
    }
    @Override protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f;float r=Math.min(getWidth(),getHeight())/2f-track.getStrokeWidth();RectF oval=new RectF(cx-r,cy-r,cx+r,cy+r);c.drawArc(oval,-90,360,false,track);c.drawArc(oval,-90,360f*percent/100f,false,progress);c.drawText(percent+"%",cx,cy+number.getTextSize()*0.22f,number);c.drawText("نسبة الإنجاز",cx,cy+number.getTextSize()*0.95f,caption);}
}
