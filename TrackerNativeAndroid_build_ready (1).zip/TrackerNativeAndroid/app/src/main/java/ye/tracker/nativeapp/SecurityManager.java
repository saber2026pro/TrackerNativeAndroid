package ye.tracker.nativeapp;

import android.content.Context;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.Executor;

/** Authentication helpers. Biometrics open the phone-user session only; they never identify a person. */
public final class SecurityManager {
    private SecurityManager() {}

    public interface Callback { void onSuccess(); void onError(String message); }

    public static boolean biometricAvailable(Context context) {
        if (Build.VERSION.SDK_INT < 29) return hasBiometricHardware(context);
        BiometricManager bm = context.getSystemService(BiometricManager.class);
        return bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
    }

    @SuppressWarnings("deprecation")
    private static boolean hasBiometricHardware(Context context) {
        android.hardware.fingerprint.FingerprintManager fm = context.getSystemService(android.hardware.fingerprint.FingerprintManager.class);
        return fm != null && fm.isHardwareDetected() && fm.hasEnrolledFingerprints();
    }

    public static void authenticate(android.app.Activity activity, Executor executor, Callback callback) {
        if (Build.VERSION.SDK_INT < 28) {
            callback.onError("البصمة غير مدعومة في إصدار Android هذا");
            return;
        }
        CancellationSignal cancel = new CancellationSignal();
        BiometricPrompt prompt = new BiometricPrompt.Builder(activity)
                .setTitle("فتح نظام متابعة التقارير والخطط")
                .setSubtitle("البصمة تفتح التطبيق كمستخدم هذا الهاتف")
                .setNegativeButton("إلغاء", executor, (d, which) -> callback.onError("تم إلغاء التحقق"))
                .build();
        prompt.authenticate(cancel, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) { callback.onSuccess(); }
            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                callback.onError(errString == null ? "تعذر التحقق بالبصمة" : errString.toString());
            }
        });
    }

    /** Stores a salted password for a named credential prefix such as admin_password or user_password. */
    public static void setPassword(DatabaseHelper db, String prefix, String password) {
        if (prefix == null || prefix.trim().isEmpty()) throw new IllegalArgumentException("prefix");
        if (password == null || password.length() < 4) throw new IllegalArgumentException("Password must be at least 4 characters");
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        db.setSetting(prefix + "_salt", Base64.getEncoder().encodeToString(salt));
        db.setSetting(prefix + "_hash", hash(password, salt));
    }

    public static boolean verifyPassword(DatabaseHelper db, String prefix, String password) {
        String saltText = db.setting(prefix + "_salt", "");
        String expected = db.setting(prefix + "_hash", "");
        if (saltText.isEmpty() || expected.isEmpty() || password == null) return false;
        try {
            byte[] salt = Base64.getDecoder().decode(saltText);
            return constantTimeEquals(expected, hash(password, salt));
        } catch (Exception e) { return false; }
    }

    public static boolean hasPassword(DatabaseHelper db, String prefix) {
        return !db.setting(prefix + "_hash", "").isEmpty();
    }

    // Backward-compatible wrappers for the earlier unreleased build.
    public static void setPin(DatabaseHelper db, boolean admin, String pin) {
        setPassword(db, admin ? "admin_pin" : "app_pin", pin);
    }
    public static boolean verifyPin(DatabaseHelper db, boolean admin, String pin) {
        return verifyPassword(db, admin ? "admin_pin" : "app_pin", pin);
    }
    public static boolean hasPin(DatabaseHelper db, boolean admin) {
        return hasPassword(db, admin ? "admin_pin" : "app_pin");
    }

    private static String hash(String secret, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            md.update(secret.getBytes(StandardCharsets.UTF_8));
            byte[] out = md.digest();
            for (int i = 0; i < 120_000; i++) {
                md.reset(); md.update(out); md.update(salt); out = md.digest();
            }
            return Base64.getEncoder().encodeToString(out);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    private static boolean constantTimeEquals(String a, String b) {
        byte[] aa = a.getBytes(StandardCharsets.UTF_8), bb = b.getBytes(StandardCharsets.UTF_8);
        int diff = aa.length ^ bb.length;
        int n = Math.max(aa.length, bb.length);
        for (int i=0;i<n;i++) diff |= (i<aa.length?aa[i]:0) ^ (i<bb.length?bb[i]:0);
        return diff == 0;
    }
}
