package ye.tracker.nativeapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/** Per-record default and custom reminders. */
public final class RecordAlertManager {
    private RecordAlertManager(){}
    public static final String PRESET_NONE="NONE";
    public static final String PRESET_DUE="DUE_ONLY";
    public static final String PRESET_DAY="DAY_BEFORE_AND_DUE";
    public static final String PRESET_THREE="THREE_DAYS_AND_DUE";
    public static final String PRESET_WEEK="WEEK_AND_DUE";

    public static String[] presetLabels(){return new String[]{"بدون تنبيه افتراضي","في يوم الموعد فقط","قبل يوم + يوم الموعد","قبل 3 أيام + يوم الموعد","قبل أسبوع + يوم الموعد"};}
    public static String[] presetCodes(){return new String[]{PRESET_NONE,PRESET_DUE,PRESET_DAY,PRESET_THREE,PRESET_WEEK};}
    public static int presetPosition(String code){String[] c=presetCodes();for(int i=0;i<c.length;i++)if(c[i].equals(code))return i;return 2;}
    public static String presetCodeAt(int position){String[] c=presetCodes();return c[Math.max(0,Math.min(c.length-1,position))];}

    public static void syncDefaultPreset(Context context,DatabaseHelper helper,String recordUid,String expectedDate,String presetCode){
        if(!AccessPolicy.canManageAlerts(helper))throw new SecurityException("لا توجد صلاحية لتعديل التنبيهات");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try{
            db.execSQL("UPDATE record_alerts SET deleted=1,updated_at=? WHERE record_uid=? AND kind='DEFAULT' AND deleted=0",new Object[]{TimeUtil.nowIso(),recordUid});
            if(expectedDate!=null&&!expectedDate.trim().isEmpty()&&!PRESET_NONE.equals(presetCode)){
                int[] offsets=offsetsFor(presetCode);String time=helper.setting("default_alert_time","09:00");
                for(int offset:offsets){
                    try{insert(db,helper,recordUid,"DEFAULT",offset,TimeUtil.atTimeWithDayOffset(expectedDate.trim(),offset,time),offset==0?"موعد استحقاق العمل اليوم":"تذكير قبل موعد استحقاق العمل");}catch(Exception ignored){}
                }
            }
            helper.setSetting("record_preset_"+recordUid,presetCode);
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        scheduleRecord(context,helper,recordUid);
    }

    public static String addCustom(Context context,DatabaseHelper helper,String recordUid,String targetAt,String message){
        if(!AccessPolicy.canManageAlerts(helper))throw new SecurityException("لا توجد صلاحية لإضافة تنبيه");
        SQLiteDatabase db=helper.getWritableDatabase();String uid=insert(db,helper,recordUid,"CUSTOM",null,targetAt,message==null?"تنبيه مخصص":message.trim());
        audit(db,helper,uid,recordUid,"ADD","تنبيه مخصص: "+targetAt);NotificationScheduler.scheduleAlert(context,uid,targetAt);return uid;
    }

    public static void updateCustom(Context context,DatabaseHelper helper,String uid,String targetAt,String message){
        if(!AccessPolicy.canManageAlerts(helper))throw new SecurityException("لا توجد صلاحية لتعديل التنبيه");
        SQLiteDatabase db=helper.getWritableDatabase();String recordUid=recordUid(db,uid);db.execSQL("UPDATE record_alerts SET target_at=?,message=?,enabled=1,fired_at=NULL,updated_at=? WHERE uid=? AND kind='CUSTOM' AND deleted=0",new Object[]{targetAt,message,TimeUtil.nowIso(),uid});audit(db,helper,uid,recordUid,"EDIT","تعديل التنبيه إلى "+targetAt);NotificationScheduler.cancelAlert(context,uid);NotificationScheduler.scheduleAlert(context,uid,targetAt);
    }

    public static void delete(Context context,DatabaseHelper helper,String uid){
        if(!AccessPolicy.canDelete(helper))throw new SecurityException("الحذف متاح لمسؤول النظام أو المشرف فقط");
        SQLiteDatabase db=helper.getWritableDatabase();String recordUid=recordUid(db,uid);db.execSQL("UPDATE record_alerts SET deleted=1,enabled=0,updated_at=? WHERE uid=?",new Object[]{TimeUtil.nowIso(),uid});audit(db,helper,uid,recordUid,"DELETE","حذف التنبيه");NotificationScheduler.cancelAlert(context,uid);
    }

    public static void setEnabled(Context context,DatabaseHelper helper,String uid,boolean enabled){
        if(!AccessPolicy.canManageAlerts(helper))throw new SecurityException("لا توجد صلاحية لتعديل التنبيه");
        SQLiteDatabase db=helper.getWritableDatabase();db.execSQL("UPDATE record_alerts SET enabled=?,fired_at=CASE WHEN ?=1 THEN NULL ELSE fired_at END,updated_at=? WHERE uid=? AND deleted=0",new Object[]{enabled?1:0,enabled?1:0,TimeUtil.nowIso(),uid});NotificationScheduler.cancelAlert(context,uid);if(enabled){try(Cursor c=db.rawQuery("SELECT target_at FROM record_alerts WHERE uid=?",new String[]{uid})){if(c.moveToFirst())NotificationScheduler.scheduleAlert(context,uid,c.getString(0));}}
    }

    public static Cursor cursor(DatabaseHelper helper,String recordUid){return helper.getReadableDatabase().rawQuery("SELECT _id,uid,kind,offset_days,target_at,message,enabled,fired_at,created_at FROM record_alerts WHERE record_uid=? AND deleted=0 ORDER BY target_at,_id",new String[]{recordUid});}

    public static void scheduleRecord(Context context,DatabaseHelper helper,String recordUid){
        try(Cursor c=helper.getReadableDatabase().rawQuery("SELECT uid,target_at FROM record_alerts WHERE record_uid=? AND deleted=0 AND enabled=1 AND fired_at IS NULL",new String[]{recordUid})){while(c.moveToNext()){NotificationScheduler.cancelAlert(context,c.getString(0));NotificationScheduler.scheduleAlert(context,c.getString(0),c.getString(1));}}
    }
    public static void scheduleAll(Context context,DatabaseHelper helper){
        long now=System.currentTimeMillis();try(Cursor c=helper.getReadableDatabase().rawQuery("SELECT uid,target_at FROM record_alerts WHERE deleted=0 AND enabled=1 AND fired_at IS NULL",null)){while(c.moveToNext()){try{Date d=TimeUtil.parseLocalDateTime(c.getString(1));if(d.getTime()>now-86400000L)NotificationScheduler.scheduleAlert(context,c.getString(0),c.getString(1));}catch(Exception ignored){}}}
    }

    public static String recordPreset(DatabaseHelper helper,String recordUid){return helper.setting("record_preset_"+recordUid,helper.setting("default_alert_preset",PRESET_DAY));}

    private static int[] offsetsFor(String code){if(PRESET_DUE.equals(code))return new int[]{0};if(PRESET_THREE.equals(code))return new int[]{3,0};if(PRESET_WEEK.equals(code))return new int[]{7,0};return new int[]{1,0};}
    private static String insert(SQLiteDatabase db,DatabaseHelper helper,String recordUid,String kind,Integer offset,String targetAt,String message){String uid=UUID.randomUUID().toString(),now=TimeUtil.nowIso();db.execSQL("INSERT INTO record_alerts(uid,record_uid,kind,offset_days,target_at,message,enabled,origin_device_id,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,1,?,?,?,0)",new Object[]{uid,recordUid,kind,offset,targetAt,message,helper.deviceId(),now,now});return uid;}
    private static String recordUid(SQLiteDatabase db,String uid){try(Cursor c=db.rawQuery("SELECT record_uid FROM record_alerts WHERE uid=?",new String[]{uid})){return c.moveToFirst()?c.getString(0):null;}}
    private static void audit(SQLiteDatabase db,DatabaseHelper h,String uid,String recordUid,String operation,String details){db.execSQL("INSERT INTO audit_events(uid,entity_type,entity_uid,record_uid,device_id,actor_name,actor_role,operation,source,occurred_at,details) VALUES(?,?,?,?,?,?,?,?,?,?,?)",new Object[]{UUID.randomUUID().toString(),"ALERT",uid,recordUid,h.deviceId(),h.actorName(),h.deviceRole(),operation,"يدوي",TimeUtil.nowIso(),details});}
}
