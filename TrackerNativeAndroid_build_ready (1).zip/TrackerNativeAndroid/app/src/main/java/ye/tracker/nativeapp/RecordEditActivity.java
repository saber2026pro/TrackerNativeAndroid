package ye.tracker.nativeapp;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.*;

public final class RecordEditActivity extends Activity {
    private DatabaseHelper db; private TrackerRepository repo; private String recordUid;
    private LinearLayout content; private final Map<String,EditText> fields=new LinkedHashMap<>();
    private Spinner type,status,alertPreset; private String defaultType; private String loadedExpected="",loadedPreset="";
    private final ArrayList<PendingAlert> pendingCustom=new ArrayList<>(); private LinearLayout pendingBox;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        db=((TrackerApp)getApplication()).db();repo=new TrackerRepository(db);recordUid=getIntent().getStringExtra("record_uid");defaultType=getIntent().getStringExtra("type_default");
        if(!db.hasSession()){finish();return;}if(recordUid==null&&!AccessPolicy.canCreate(db)){Ui.toast(this,"صلاحيتك للعرض فقط");finish();return;}buildShell();showData();
    }

    private void buildShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(ThemeManager.palette(this).background);
        root.addView(Ui.title(this,recordUid==null?"إضافة عمل":"تفاصيل العمل"),Ui.match());
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout tabs=Ui.row(this);
        String[] names={"بيانات السجل","مجريات المتابعة","المرفقات","التنبيهات"};
        for(String s:names){Button b=Ui.button(this,s);tabs.addView(b,new LinearLayout.LayoutParams(Ui.dp(this,135),Ui.dp(this,48)));b.setOnClickListener(v->{if("بيانات السجل".equals(s))showData();else if("مجريات المتابعة".equals(s))showFollowups();else if("المرفقات".equals(s))showAttachments();else showAlerts();});}
        hs.addView(tabs);root.addView(hs,Ui.match());content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }

    private void showData(){
        content.removeAllViews();ScrollView s=new ScrollView(this);LinearLayout b=Ui.column(this);fields.clear();
        addField(b,"record_no","رقم العمل","اختياري");addField(b,"subject","الموضوع / مهمة العمل","الموضوع");
        b.addView(Ui.label(this,"نوع العمل"));type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"مهمة","تقرير","خطة","مذكرة"}));b.addView(type,Ui.match());if(recordUid==null&&defaultType!=null)select(type,defaultType);
        addField(b,"start_date","تاريخ البدء","YYYY-MM-DD");addField(b,"expected_date","تاريخ الانتهاء المتوقع","YYYY-MM-DD");addField(b,"assignee","المعني بالمهمة","الاسم أو الجهة");addField(b,"agency","الجهة المعنية بالمتابعة","الجهة");
        b.addView(Ui.label(this,"حالة المهمة"));status=new Spinner(this);status.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"قيد المتابعة","قيد الانجاز","متأخرة","منجزة","ملغية"}));b.addView(status,Ui.match());
        addField(b,"completion_date","تاريخ الإنجاز الفعلي","YYYY-MM-DD");EditText notes=Ui.multi(this,"الملاحظات");fields.put("notes",notes);b.addView(Ui.label(this,"الملاحظات"));b.addView(notes,Ui.match());

        b.addView(Ui.sectionTitle(this,"التنبيهات لهذا العمل"),Ui.match());
        b.addView(Ui.label(this,"اختر أسلوب التنبيه الافتراضي لهذا السجل. يمكنك كذلك إضافة أي عدد من التنبيهات المخصصة بتاريخ ووقت مستقلين."),Ui.match());
        alertPreset=new Spinner(this);alertPreset.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,RecordAlertManager.presetLabels()));b.addView(alertPreset,Ui.match());
        String preset=recordUid==null?db.setting("default_alert_preset",RecordAlertManager.PRESET_DAY):RecordAlertManager.recordPreset(db,recordUid);selectPreset(preset);
        Button addAlert=Ui.button(this,"+ إضافة تنبيه مخصص");b.addView(addAlert,Ui.match());addAlert.setOnClickListener(v->pickDateTime(null,(value)->{pendingCustom.add(new PendingAlert(value,"تنبيه مخصص"));renderPendingAlerts();}));
        pendingBox=Ui.columnCompact(this);b.addView(pendingBox,Ui.match());renderPendingAlerts();
        if(recordUid!=null)b.addView(Ui.label(this,"التنبيهات المحفوظة السابقة يمكن استعراضها وتعديلها من تبويب «التنبيهات» أعلى الصفحة."),Ui.match());

        Button save=Ui.button(this,"حفظ");b.addView(save,Ui.match());save.setOnClickListener(v->save());
        boolean editable=recordUid==null?AccessPolicy.canCreate(db):AccessPolicy.canEdit(db);save.setEnabled(editable);if(!editable)save.setText("عرض فقط — لا توجد صلاحية للتعديل");
        if(recordUid!=null&&AccessPolicy.canDelete(db)){Button del=Ui.button(this,"حذف السجل");b.addView(del,Ui.match());del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف السجل؟").setMessage("سيُخفى السجل من القوائم وتُحفظ عملية الحذف في سجل التغييرات وحزمة المزامنة، ولن يُمسح تاريخه مباشرة.").setPositiveButton("حذف",(d,w)->{repo.deleteRecord(recordUid);Ui.toast(this,"تم حذف السجل مع حفظ تاريخ العملية");finish();}).setNegativeButton("إلغاء",null).show());}
        if(recordUid!=null)loadRecord();s.addView(b);content.addView(s,new LinearLayout.LayoutParams(-1,-1));
    }

    private void renderPendingAlerts(){if(pendingBox==null)return;pendingBox.removeAllViews();for(int i=0;i<pendingCustom.size();i++){final int idx=i;PendingAlert a=pendingCustom.get(i);LinearLayout row=Ui.card(this);TextView t=Ui.label(this,"مخصص: "+a.target);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));Button del=Ui.button(this,"حذف");del.setOnClickListener(v->{pendingCustom.remove(idx);renderPendingAlerts();});row.addView(del,new LinearLayout.LayoutParams(Ui.dp(this,70),-2));pendingBox.addView(row,Ui.cardParams(this));}}

    private void addField(LinearLayout b,String key,String lab,String hint){b.addView(Ui.label(this,lab));EditText e=Ui.edit(this,hint);fields.put(key,e);b.addView(e,Ui.match());}
    private Map<String,String> collect(){Map<String,String> m=new LinkedHashMap<>();for(Map.Entry<String,EditText> e:fields.entrySet())m.put(e.getKey(),e.getValue().getText().toString());m.put("type",String.valueOf(type.getSelectedItem()));m.put("status",String.valueOf(status.getSelectedItem()));return m;}

    private void save(){
        if(recordUid==null&&!AccessPolicy.canCreate(db)){Ui.toast(this,"لا توجد صلاحية للإضافة");return;}if(recordUid!=null&&!AccessPolicy.canEdit(db)){Ui.toast(this,"لا توجد صلاحية للتعديل");return;}
        Map<String,String> m=collect();if(blank(m.get("subject"))||blank(m.get("start_date"))||blank(m.get("assignee"))||blank(m.get("agency"))){Ui.toast(this,"أكمل الموضوع وتاريخ البدء والمعني والجهة");return;}
        String chosenPreset=RecordAlertManager.presetCodeAt(alertPreset.getSelectedItemPosition());String expected=m.get("expected_date")==null?"":m.get("expected_date").trim();
        boolean created=recordUid==null;
        if(created){recordUid=repo.createRecord(m);}else repo.updateRecord(recordUid,m);
        if(created||!expected.equals(loadedExpected)||!chosenPreset.equals(loadedPreset))RecordAlertManager.syncDefaultPreset(this,db,recordUid,expected,chosenPreset);
        for(PendingAlert a:pendingCustom)RecordAlertManager.addCustom(this,db,recordUid,a.target,a.message);pendingCustom.clear();loadedExpected=expected;loadedPreset=chosenPreset;
        Ui.toast(this,created?"تمت إضافة السجل":"تم حفظ التعديل");
        if(created){setTitle("تفاصيل العمل");showData();}
    }
    private boolean blank(String s){return s==null||s.trim().isEmpty();}

    private void loadRecord(){
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT record_no,subject,type,start_date,expected_date,assignee,agency,status,completion_date,notes FROM records WHERE uid=?",new String[]{recordUid})){
            if(!c.moveToFirst())return;for(String k:fields.keySet()){int i=c.getColumnIndex(k);if(i>=0&&!c.isNull(i))fields.get(k).setText(c.getString(i));}select(type,c.getString(c.getColumnIndexOrThrow("type")));select(status,c.getString(c.getColumnIndexOrThrow("status")));loadedExpected=value(c,"expected_date");loadedPreset=RecordAlertManager.recordPreset(db,recordUid);selectPreset(loadedPreset);
        }
    }
    private String value(Cursor c,String col){int i=c.getColumnIndex(col);return i<0||c.isNull(i)?"":c.getString(i);}
    private void select(Spinner s,String v){for(int i=0;i<s.getCount();i++)if(String.valueOf(s.getItemAtPosition(i)).equals(v)){s.setSelection(i);return;}}
    private void selectPreset(String code){if(alertPreset!=null)alertPreset.setSelection(RecordAlertManager.presetPosition(code));}

    private void showFollowups(){
        content.removeAllViews();if(recordUid==null){content.addView(Ui.title(this,"احفظ السجل أولًا ثم أضف مجريات المتابعة"));return;}
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);Button add=Ui.button(this,"إضافة مجريات متابعة");add.setEnabled(AccessPolicy.canManageFollowups(db));if(!AccessPolicy.canManageFollowups(db))add.setText("مجريات المتابعة — عرض فقط");b.addView(add,Ui.match());ListView list=new ListView(this);b.addView(list,new LinearLayout.LayoutParams(-1,0,1));content.addView(b,new LinearLayout.LayoutParams(-1,-1));
        Runnable reload=()->{Cursor c=repo.followupsCursor(recordUid);list.setAdapter(new FollowCursorAdapter(this,c));};add.setOnClickListener(v->followDialog(null,null,null,reload));
        list.setOnItemClickListener((p,v,pos,id)->{Cursor c=(Cursor)p.getItemAtPosition(pos);String uid=c.getString(c.getColumnIndexOrThrow("uid"));String at=c.getString(c.getColumnIndexOrThrow("event_at"));String tx=c.getString(c.getColumnIndexOrThrow("text"));showFollowMenu(uid,at,tx,reload);});reload.run();
    }
    private void showFollowMenu(String uid,String at,String tx,Runnable reload){
        ArrayList<String> items=new ArrayList<>();if(AccessPolicy.canManageFollowups(db))items.add("تعديل الإدخال السابق");items.add("عرض تاريخ هذا الإدخال");if(AccessPolicy.canDelete(db))items.add("حذف الإدخال");
        new AlertDialog.Builder(this).setTitle("مجريات المتابعة").setItems(items.toArray(new String[0]),(d,w)->{String choice=items.get(w);if("تعديل الإدخال السابق".equals(choice))followDialog(uid,at,tx,reload);else if("عرض تاريخ هذا الإدخال".equals(choice)){Intent i=new Intent(this,HistoryActivity.class);i.putExtra("followup_uid",uid);startActivity(i);}else new AlertDialog.Builder(this).setMessage("هل تريد حذف هذا الإدخال؟ يمكن تتبع الحذف في سجل التغييرات.").setPositiveButton("حذف",(x,y)->{repo.deleteFollowup(uid);reload.run();}).setNegativeButton("إلغاء",null).show();}).show();}
    private void followDialog(String uid,String oldAt,String oldText,Runnable reload){if(!AccessPolicy.canManageFollowups(db)){Ui.toast(this,"صلاحية العرض فقط");return;}LinearLayout b=Ui.column(this);EditText at=Ui.edit(this,"التاريخ والوقت");at.setText(oldAt==null?TimeUtil.nowIso():oldAt);EditText tx=Ui.multi(this,"مجريات المتابعة");if(oldText!=null)tx.setText(oldText);b.addView(Ui.label(this,"التاريخ"));b.addView(at,Ui.match());b.addView(Ui.label(this,"النص"));b.addView(tx,Ui.match());new AlertDialog.Builder(this).setTitle(uid==null?"إضافة متابعة":"تعديل متابعة سابقة").setView(b).setPositiveButton("حفظ",(d,w)->{if(tx.getText().toString().trim().isEmpty()){Ui.toast(this,"اكتب مجريات المتابعة");return;}if(uid==null)repo.addFollowup(recordUid,at.getText().toString(),tx.getText().toString());else repo.updateFollowup(uid,at.getText().toString(),tx.getText().toString());reload.run();}).setNegativeButton("إلغاء",null).show();}

    private void showAttachments(){
        content.removeAllViews();if(recordUid==null){content.addView(Ui.title(this,"احفظ السجل أولًا ثم أضف المرفقات"));return;}
        LinearLayout b=Ui.column(this);b.addView(Ui.title(this,"المرفقات المتعددة"));b.addView(Ui.label(this,"المرفقات محفوظة كملفات مستقلة عن قاعدة البيانات، ويمكن أن يحتوي السجل على عدد كبير منها دون تضخيم صف السجل."),Ui.match());Button add=Ui.button(this,"إضافة مرفقات متعددة");add.setEnabled(AccessPolicy.canManageAttachments(db));if(!AccessPolicy.canManageAttachments(db))add.setText("المرفقات — عرض فقط");b.addView(add,Ui.match());add.setOnClickListener(v->{if(!AccessPolicy.canManageAttachments(db))return;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,501);});ListView list=new ListView(this);b.addView(list,new LinearLayout.LayoutParams(-1,0,1));content.addView(b,new LinearLayout.LayoutParams(-1,-1));loadAttachments(list);
    }
    private void loadAttachments(ListView list){Cursor c=db.getReadableDatabase().rawQuery("SELECT _id,file_name,mime_type,size_bytes,created_at FROM attachments WHERE record_uid=? AND deleted=0 ORDER BY _id DESC",new String[]{recordUid});list.setAdapter(new SimpleCursorAdapter(this,android.R.layout.simple_list_item_2,c,new String[]{"file_name","created_at"},new int[]{android.R.id.text1,android.R.id.text2},0));}

    private void showAlerts(){
        content.removeAllViews();if(recordUid==null){content.addView(Ui.title(this,"احفظ السجل أولًا ثم أضف التنبيهات"));return;}
        LinearLayout b=Ui.column(this);b.addView(Ui.title(this,"تنبيهات هذا العمل"));b.addView(Ui.label(this,"يمكن تعديل أو تعطيل أو حذف أي تنبيه مخصص. التنبيهات الافتراضية يعاد ضبطها من تبويب بيانات السجل."),Ui.match());Button add=Ui.button(this,"+ تنبيه مخصص جديد");add.setEnabled(AccessPolicy.canManageAlerts(db));if(!AccessPolicy.canManageAlerts(db))add.setText("التنبيهات — عرض فقط");b.addView(add,Ui.match());ListView list=new ListView(this);b.addView(list,new LinearLayout.LayoutParams(-1,0,1));content.addView(b,new LinearLayout.LayoutParams(-1,-1));
        Runnable reload=()->list.setAdapter(new AlertCursorAdapter(this,RecordAlertManager.cursor(db,recordUid)));
        add.setOnClickListener(v->pickDateTime(null,target->customMessageDialog(target,null,null,reload)));
        list.setOnItemClickListener((p,v,pos,id)->{Cursor c=(Cursor)p.getItemAtPosition(pos);if(!AccessPolicy.canManageAlerts(db)){Ui.toast(this,"صلاحية العرض فقط");return;}String uid=c.getString(c.getColumnIndexOrThrow("uid")),kind=c.getString(c.getColumnIndexOrThrow("kind")),target=c.getString(c.getColumnIndexOrThrow("target_at")),msg=value(c,"message");boolean enabled=c.getInt(c.getColumnIndexOrThrow("enabled"))==1;if("CUSTOM".equals(kind))showCustomAlertMenu(uid,target,msg,enabled,reload);else showDefaultAlertMenu(uid,enabled,reload);});reload.run();
    }
    private void showCustomAlertMenu(String uid,String target,String msg,boolean enabled,Runnable reload){String[] items={"تعديل الموعد والنص",enabled?"تعطيل التنبيه":"تشغيل التنبيه","حذف التنبيه"};new AlertDialog.Builder(this).setTitle("التنبيه المخصص").setItems(items,(d,w)->{if(w==0)pickDateTime(target,newTarget->customMessageDialog(newTarget,uid,msg,reload));else if(w==1){RecordAlertManager.setEnabled(this,db,uid,!enabled);reload.run();}else new AlertDialog.Builder(this).setMessage("حذف هذا التنبيه؟").setPositiveButton("حذف",(x,y)->{RecordAlertManager.delete(this,db,uid);reload.run();}).setNegativeButton("إلغاء",null).show();}).show();}
    private void showDefaultAlertMenu(String uid,boolean enabled,Runnable reload){new AlertDialog.Builder(this).setTitle("تنبيه افتراضي").setItems(new String[]{enabled?"تعطيل هذا التنبيه":"تشغيل هذا التنبيه","العودة لضبط النمط الافتراضي"},(d,w)->{if(w==0){RecordAlertManager.setEnabled(this,db,uid,!enabled);reload.run();}else showData();}).show();}
    private void customMessageDialog(String target,String uid,String oldMessage,Runnable reload){EditText e=Ui.edit(this,"نص التنبيه المخصص");e.setText(oldMessage==null?"تنبيه مخصص":oldMessage);new AlertDialog.Builder(this).setTitle("موعد التنبيه: "+target).setView(e).setPositiveButton("حفظ",(d,w)->{String m=e.getText().toString().trim();if(m.isEmpty())m="تنبيه مخصص";if(uid==null)RecordAlertManager.addCustom(this,db,recordUid,target,m);else RecordAlertManager.updateCustom(this,db,uid,target,m);reload.run();}).setNegativeButton("إلغاء",null).show();}

    private interface DateTimeResult{void onResult(String value);}
    private void pickDateTime(String initial,DateTimeResult cb){Calendar cal=Calendar.getInstance();if(initial!=null)try{cal.setTime(TimeUtil.parseLocalDateTime(initial));}catch(Exception ignored){}DatePickerDialog dp=new DatePickerDialog(this,(view,y,m,d)->{TimePickerDialog tp=new TimePickerDialog(this,(tv,h,min)->{Calendar x=Calendar.getInstance();x.set(Calendar.YEAR,y);x.set(Calendar.MONTH,m);x.set(Calendar.DAY_OF_MONTH,d);x.set(Calendar.HOUR_OF_DAY,h);x.set(Calendar.MINUTE,min);x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);cb.onResult(TimeUtil.localDateTime(x.getTime()));},cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),true);tp.show();},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));dp.show();}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==501&&resultCode==RESULT_OK&&data!=null){if(!AccessPolicy.canManageAttachments(db)){Ui.toast(this,"لا توجد صلاحية لإضافة مرفقات");return;}((TrackerApp)getApplication()).io().execute(()->{try{int n=AttachmentStore.importSelection(this,db,recordUid,data);runOnUiThread(()->{Ui.toast(this,"تمت إضافة "+n+" مرفق");showAttachments();});}catch(Exception e){runOnUiThread(()->Ui.toast(this,"تعذر حفظ المرفقات: "+e.getMessage()));}});}}

    private static final class PendingAlert{final String target,message;PendingAlert(String target,String message){this.target=target;this.message=message;}}
    private static final class FollowCursorAdapter extends CursorAdapter{FollowCursorAdapter(Context c,Cursor x){super(c,x,0);}public View newView(Context c,Cursor x,ViewGroup p){return Ui.column(c);}public void bindView(View v,Context c,Cursor x){LinearLayout b=(LinearLayout)v;b.removeAllViews();TextView t=Ui.title(c,x.getString(x.getColumnIndexOrThrow("event_at")));t.setTextSize(Ui.sp(c,14));b.addView(t);TextView tx=Ui.label(c,x.getString(x.getColumnIndexOrThrow("text")));tx.setTextSize(Ui.sp(c,15));b.addView(tx,Ui.match());String u=x.getString(x.getColumnIndexOrThrow("updated_at"));b.addView(Ui.label(c,"آخر تعديل: "+u+" — اضغط للاستعراض أو التعديل"),Ui.match());}}
    private static final class AlertCursorAdapter extends CursorAdapter{AlertCursorAdapter(Context c,Cursor x){super(c,x,0);}public View newView(Context c,Cursor x,ViewGroup p){return Ui.column(c);}public void bindView(View v,Context c,Cursor x){LinearLayout b=(LinearLayout)v;b.removeAllViews();String kind=x.getString(x.getColumnIndexOrThrow("kind")),target=x.getString(x.getColumnIndexOrThrow("target_at"));int enabled=x.getInt(x.getColumnIndexOrThrow("enabled"));String fired=x.isNull(x.getColumnIndexOrThrow("fired_at"))?"":x.getString(x.getColumnIndexOrThrow("fired_at"));Integer off=x.isNull(x.getColumnIndexOrThrow("offset_days"))?null:x.getInt(x.getColumnIndexOrThrow("offset_days"));String title="CUSTOM".equals(kind)?"تنبيه مخصص":"تنبيه افتراضي"+(off==null?"":(off==0?" — يوم الموعد":" — قبل "+off+" يوم"));b.addView(Ui.title(c,title),Ui.match());String state=enabled==0?"معطل":(!fired.isEmpty()?"تم إرساله":"قادم");b.addView(Ui.label(c,"الموعد: "+target+" | الحالة: "+state),Ui.match());String msg=x.isNull(x.getColumnIndexOrThrow("message"))?"":x.getString(x.getColumnIndexOrThrow("message"));if(!msg.isEmpty())b.addView(Ui.label(c,msg),Ui.match());}}
}
