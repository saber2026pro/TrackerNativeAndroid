package ye.tracker.nativeapp;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

final class Ui {
    private Ui() {}
    static int dp(Context c,int v){return Math.round(v*c.getResources().getDisplayMetrics().density*ThemeManager.densityFactor(c));}
    static float sp(Context c,float v){return v*ThemeManager.textScale(c);}
    static TextView title(Context c,String s){ThemeManager.Palette p=ThemeManager.palette(c);TextView v=new TextView(c);v.setText(s);v.setTextSize(sp(c,20));v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setTextColor(p.text);v.setGravity(Gravity.RIGHT);v.setPadding(dp(c,16),dp(c,12),dp(c,16),dp(c,12));return v;}
    static TextView label(Context c,String s){ThemeManager.Palette p=ThemeManager.palette(c);TextView v=new TextView(c);v.setText(s);v.setTextSize(sp(c,13));v.setTextColor(p.muted);v.setGravity(Gravity.RIGHT);v.setPadding(0,dp(c,8),0,dp(c,3));return v;}
    static EditText edit(Context c,String hint){ThemeManager.Palette p=ThemeManager.palette(c);EditText e=new EditText(c);e.setHint(hint);e.setTextSize(sp(c,15));e.setTextColor(p.text);e.setHintTextColor(p.muted);e.setGravity(Gravity.RIGHT);e.setSingleLine(true);e.setPadding(dp(c,10),dp(c,8),dp(c,10),dp(c,8));return e;}
    static EditText multi(Context c,String hint){EditText e=edit(c,hint);e.setSingleLine(false);e.setMinLines(3);e.setGravity(Gravity.TOP|Gravity.RIGHT);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);return e;}
    static Button button(Context c,String text){ThemeManager.Palette p=ThemeManager.palette(c);Button b=new Button(c);b.setText(text);b.setAllCaps(false);b.setTextSize(sp(c,13));b.setTextColor(p.text);b.setMinHeight(dp(c,42));return b;}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER);return l;}
    static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(c,14),dp(c,8),dp(c,14),dp(c,14));return l;}
    static LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f);}
    static LinearLayout.LayoutParams match(){return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);}
    static Toast toast(Context c,String s){Toast t=Toast.makeText(c,s,Toast.LENGTH_SHORT);t.show();return t;}

    static GradientDrawable rounded(Context c,int color,int radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radiusDp));return g;}
    static GradientDrawable sidebarBackground(Context c){ThemeManager.Palette p=ThemeManager.palette(c);return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{p.sidebarTop,p.sidebarBottom});}
    static LinearLayout columnCompact(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);return l;}
    static TextView sideTitle(Context c,String s){TextView v=title(c,s);v.setTextColor(Color.WHITE);v.setPadding(dp(c,8),0,dp(c,8),0);return v;}
    static TextView sideLabel(Context c,String s){TextView v=label(c,s);v.setTextColor(ThemeManager.palette(c).sideText);v.setPadding(dp(c,8),0,dp(c,8),0);return v;}
    static Button sideButton(Context c,String text){Button b=button(c,text);b.setTextColor(Color.WHITE);b.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);b.setPadding(dp(c,16),0,dp(c,16),0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    static Button iconButton(Context c,String text){Button b=button(c,text);b.setText(text);b.setTextSize(sp(c,20));b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b;}
    static LinearLayout card(Context c){ThemeManager.Palette p=ThemeManager.palette(c);LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));l.setBackground(rounded(c,p.surface,16));l.setElevation(dp(c,2));return l;}
    static LinearLayout.LayoutParams cardParams(Context c){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(dp(c,4),dp(c,5),dp(c,4),dp(c,5));return p;}
    static TextView sectionTitle(Context c,String s){TextView v=title(c,s);v.setTextSize(sp(c,16));v.setPadding(dp(c,8),dp(c,14),dp(c,8),dp(c,6));return v;}
    static TextView metricNumber(Context c,String s){TextView v=title(c,s);v.setTextSize(sp(c,18));v.setTextColor(ThemeManager.palette(c).primary);return v;}
    static LinearLayout metricCard(Context c,String label,long value,String hint){LinearLayout card=card(c);LinearLayout copy=columnCompact(c);TextView l=label(c,label);l.setTextSize(sp(c,13));TextView n=metricNumber(c,String.valueOf(value));n.setTextSize(sp(c,24));TextView h=label(c,hint);h.setTextSize(sp(c,10));copy.addView(l);copy.addView(n);copy.addView(h);card.addView(copy,new LinearLayout.LayoutParams(0,-2,1));return card;}
    static LinearLayout smallMetricCard(Context c,String label,long value){LinearLayout card=metricCard(c,label,value,"");card.setMinimumWidth(dp(c,118));card.setPadding(dp(c,10),dp(c,8),dp(c,10),dp(c,8));return card;}
    static LinearLayout breakdownRow(Context c,String title,String subtitle,String value){LinearLayout row=card(c);LinearLayout copy=columnCompact(c);TextView t=label(c,title);t.setTextSize(sp(c,14));t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView s=label(c,subtitle);s.setTextSize(sp(c,11));copy.addView(t);copy.addView(s);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView n=metricNumber(c,value);row.addView(n);return row;}
}
