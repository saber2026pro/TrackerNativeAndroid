package ye.tracker.nativeapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;

/** Runtime appearance settings for the native UI. */
public final class ThemeManager {
    private static final String PREFS = "appearance";
    private ThemeManager() {}

    public static final class Palette {
        public final int background, surface, text, muted, primary, primarySoft, sidebarTop, sidebarBottom, sideText, divider;
        Palette(int background,int surface,int text,int muted,int primary,int primarySoft,int sidebarTop,int sidebarBottom,int sideText,int divider){
            this.background=background;this.surface=surface;this.text=text;this.muted=muted;this.primary=primary;this.primarySoft=primarySoft;
            this.sidebarTop=sidebarTop;this.sidebarBottom=sidebarBottom;this.sideText=sideText;this.divider=divider;
        }
    }

    public static String theme(Context c){return prefs(c).getString("theme","MERSAD");}
    public static String mode(Context c){return prefs(c).getString("mode","SYSTEM");}
    public static String density(Context c){return prefs(c).getString("density","STANDARD");}
    public static float textScale(Context c){return prefs(c).getFloat("text_scale",1.0f);}

    public static void setTheme(Context c,String v){prefs(c).edit().putString("theme",v).apply();}
    public static void setMode(Context c,String v){prefs(c).edit().putString("mode",v).apply();}
    public static void setDensity(Context c,String v){prefs(c).edit().putString("density",v).apply();}
    public static void setTextScale(Context c,float v){prefs(c).edit().putFloat("text_scale",Math.max(0.85f,Math.min(1.35f,v))).apply();}

    public static boolean dark(Context c){
        String m=mode(c); if("DARK".equals(m))return true; if("LIGHT".equals(m))return false;
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
    }

    public static float densityFactor(Context c){String d=density(c);return "COMPACT".equals(d)?0.84f:("COMFORTABLE".equals(d)?1.16f:1f);}

    public static Palette palette(Context c){
        boolean dark=dark(c);String t=theme(c);
        int primary,side1,side2,soft;
        switch(t){
            case "NAVY": primary=Color.rgb(41,83,132);side1=Color.rgb(24,48,78);side2=Color.rgb(16,33,55);soft=Color.rgb(223,234,247);break;
            case "TEAL": primary=Color.rgb(0,121,140);side1=Color.rgb(0,77,90);side2=Color.rgb(0,55,65);soft=Color.rgb(218,242,245);break;
            case "GRAPHITE": primary=Color.rgb(81,89,98);side1=Color.rgb(47,53,60);side2=Color.rgb(30,35,40);soft=Color.rgb(231,234,237);break;
            case "SAND": primary=Color.rgb(143,103,55);side1=Color.rgb(86,64,42);side2=Color.rgb(61,44,29);soft=Color.rgb(246,236,221);break;
            default: primary=Color.rgb(47,111,102);side1=Color.rgb(23,42,45);side2=Color.rgb(16,34,38);soft=Color.rgb(224,241,238);break;
        }
        if(dark){
            return new Palette(Color.rgb(18,21,23),Color.rgb(29,34,37),Color.rgb(238,241,241),Color.rgb(174,185,186),
                    primary,Color.rgb(42,56,57),side1,side2,Color.rgb(211,224,223),Color.rgb(57,65,68));
        }
        return new Palette(Color.rgb(243,245,245),Color.WHITE,Color.rgb(23,42,45),Color.rgb(104,118,120),
                primary,soft,side1,side2,Color.rgb(202,218,217),Color.rgb(224,229,229));
    }

    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
}
