package ye.tracker.nativeapp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class TimeUtil {
    private TimeUtil() {}
    public static String nowIso() {return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(new Date());}
    public static String today() {return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());}
    public static String localDateTime(Date d){return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US).format(d);}
    public static String humanDateTime(Date d){return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(d);}
    public static Date parseLocalDateTime(String value)throws ParseException{
        if(value==null)throw new ParseException("null",0);
        String v=value.trim();
        String[] patterns={"yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss.SSSXXX","yyyy-MM-dd HH:mm","yyyy-MM-dd'T'HH:mm","yyyy-MM-dd"};
        ParseException last=null;for(String p:patterns){try{return new SimpleDateFormat(p,Locale.US).parse(v);}catch(ParseException e){last=e;}}
        throw last==null?new ParseException(v,0):last;
    }
    public static String atTimeWithDayOffset(String yyyyMmDd,int offsetDays,String hhmm)throws ParseException{
        Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(yyyyMmDd);
        Calendar c=Calendar.getInstance();c.setTime(d);c.add(Calendar.DAY_OF_YEAR,-Math.max(0,offsetDays));
        String[] parts=(hhmm==null?"09:00":hhmm).split(":");int h=9,m=0;try{h=Integer.parseInt(parts[0]);m=parts.length>1?Integer.parseInt(parts[1]):0;}catch(Exception ignored){}
        c.set(Calendar.HOUR_OF_DAY,Math.max(0,Math.min(23,h)));c.set(Calendar.MINUTE,Math.max(0,Math.min(59,m)));c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        return localDateTime(c.getTime());
    }
}
