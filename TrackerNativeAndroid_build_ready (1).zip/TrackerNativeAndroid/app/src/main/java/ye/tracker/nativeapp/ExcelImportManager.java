package ye.tracker.nativeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Xml;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Administrative import of records from the application's XLSX export. */
public final class ExcelImportManager {
    private ExcelImportManager(){}
    private static final String[] CORE={"record_no","subject","type","start_date","expected_date","assignee","agency","status","completion_date","notes"};

    public static String stageImport(Context context,DatabaseHelper helper,InputStream input)throws Exception{
        if(!AccessPolicy.canImport(helper))throw new SecurityException("استيراد Excel متاح لمسؤول النظام فقط");
        String importId=UUID.randomUUID().toString();File dir=new File(context.getFilesDir(),"excel_imports/"+importId);if(!dir.mkdirs())throw new IOException("تعذر إنشاء مساحة الاستيراد");
        try{
            extractSafe(input,dir);File sheet=new File(dir,"xl/worksheets/sheet1.xml");if(!sheet.isFile())throw new IOException("ورقة السجل غير موجودة في ملف Excel");
            List<String> shared=readSharedStrings(new File(dir,"xl/sharedStrings.xml"));
            List<Map<String,String>> rows=readRows(sheet,shared);SQLiteDatabase db=helper.getWritableDatabase();int added=0,changed=0,unchanged=0;db.beginTransaction();
            try{
                for(Map<String,String> row:rows){
                    JSONObject incoming=toRecordJson(row);if(incoming==null)continue;
                    String uid=trim(row.get("المعرف الداخلي (لا يعدل)"));String display=trim(row.get("المعرف"));
                    if(uid.isEmpty()&&!display.isEmpty())uid=findUidByDisplay(db,display);
                    if(uid.isEmpty()||!recordExists(db,uid)){
                        createExcelRecord(helper,db,incoming);added++;continue;
                    }
                    incoming.put("uid",uid);JSONObject local=localRecord(db,uid);JSONObject changes=diff(local,incoming);
                    if(changes.length()==0){unchanged++;continue;}
                    db.execSQL("INSERT INTO import_items(import_id,entity_type,entity_uid,record_uid,kind,local_revision_uid,incoming_revision_uid,incoming_parent_revision_uid,local_json,incoming_json,diff_json,decision) VALUES(?,?,?,?,?,?,?,?,?,?,?,'PENDING')",
                            new Object[]{importId,"RECORD",uid,uid,"EXCEL_UPDATE",local.optString("current_revision_uid",null),null,null,local.toString(),incoming.toString(),changes.toString()});changed++;
                }
                db.execSQL("INSERT INTO exchange_log(uid,kind,package_id,peer_device_id,peer_name,created_at,new_count,changed_count,conflict_count,unchanged_count) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        new Object[]{importId,"IMPORT_EXCEL","excel:"+UUID.randomUUID(),null,"Excel",TimeUtil.nowIso(),added,changed,0,unchanged});db.setTransactionSuccessful();
            }finally{db.endTransaction();}
            return importId;
        }finally{deleteTree(dir);}
    }

    private static JSONObject toRecordJson(Map<String,String> r)throws Exception{
        String subject=trim(r.get("الموضوع / مهمة العمل"));if(subject.isEmpty())return null;
        JSONObject o=new JSONObject();o.put("record_no",nullValue(r.get("رقم العمل")));o.put("subject",subject);o.put("type",fallback(trim(r.get("النوع")),"مهمة"));o.put("start_date",fallback(trim(r.get("تاريخ البدء")),TimeUtil.today()));o.put("expected_date",nullValue(r.get("تاريخ الانتهاء المتوقع")));o.put("assignee",fallback(trim(r.get("المعني بالمهمة")),"غير محدد"));o.put("agency",fallback(trim(r.get("الجهة المعنية بالمتابعة")),"غير محدد"));o.put("status",fallback(trim(r.get("حالة المهمة")),"قيد المتابعة"));o.put("completion_date",nullValue(r.get("تاريخ الإنجاز الفعلي")));o.put("notes",nullValue(r.get("الملاحظات")));return o;
    }

    private static void createExcelRecord(DatabaseHelper h,SQLiteDatabase db,JSONObject o)throws Exception{
        String uid=UUID.randomUUID().toString(),rev=UUID.randomUUID().toString(),now=TimeUtil.nowIso();long seq=nextSeq(db);String display="W-"+String.format(Locale.US,"%06d",seq);ContentValues v=new ContentValues();v.put("uid",uid);v.put("seq",seq);v.put("display_id",display);putFields(v,o);v.put("origin_device_id",h.deviceId());v.put("updated_device_id",h.deviceId());v.put("created_at",now);v.put("updated_at",now);v.put("current_revision_uid",rev);v.put("deleted",0);db.insertOrThrow("records",null,v);
        JSONObject snap=localRecord(db,uid);db.execSQL("INSERT INTO record_revisions(revision_uid,record_uid,parent_revision_uid,snapshot_json,device_id,actor_name,actor_role,source,operation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",new Object[]{rev,uid,null,snap.toString(),h.deviceId(),h.actorName(),h.deviceRole(),"استيراد Excel","إضافة",now});
        String event=UUID.randomUUID().toString();db.execSQL("INSERT INTO audit_events(uid,entity_type,entity_uid,record_uid,device_id,actor_name,actor_role,operation,source,occurred_at) VALUES(?,?,?,?,?,?,?,?,?,?)",new Object[]{event,"RECORD",uid,uid,h.deviceId(),h.actorName(),h.deviceRole(),"IMPORT_ADD","استيراد Excel",now});for(String f:CORE){String val=jsonString(o,f);if(val!=null)db.execSQL("INSERT INTO audit_field_changes(event_uid,field_name,old_value,new_value) VALUES(?,?,NULL,?)",new Object[]{event,f,val});}
    }

    private static List<Map<String,String>> readRows(File sheet,List<String> shared)throws Exception{
        ArrayList<Map<String,String>> out=new ArrayList<>();try(InputStream in=new BufferedInputStream(new FileInputStream(sheet))){XmlPullParser p=Xml.newPullParser();p.setInput(in,"UTF-8");int event=p.getEventType();ArrayList<String> row=null;String cellRef=null,cellType=null,cellValue=null;ArrayList<String> headers=null;
            while(event!=XmlPullParser.END_DOCUMENT){String name=p.getName();if(event==XmlPullParser.START_TAG){if("row".equals(name))row=new ArrayList<>();else if("c".equals(name)){cellRef=p.getAttributeValue(null,"r");cellType=p.getAttributeValue(null,"t");cellValue="";}else if(("v".equals(name)||"t".equals(name))&&row!=null){cellValue=p.nextText();}}
                else if(event==XmlPullParser.END_TAG){if("c".equals(name)&&row!=null){int col=columnIndex(cellRef);while(row.size()<=col)row.add("");String val=cellValue==null?"":cellValue;if("s".equals(cellType)){try{int idx=Integer.parseInt(val);val=idx>=0&&idx<shared.size()?shared.get(idx):val;}catch(Exception ignored){}}row.set(col,val);cellRef=null;cellType=null;cellValue=null;}else if("row".equals(name)&&row!=null){if(headers==null){headers=row;}
                    else{LinkedHashMap<String,String> m=new LinkedHashMap<>();for(int i=0;i<headers.size();i++){String h=headers.get(i);if(h!=null&&!h.trim().isEmpty())m.put(h.trim(),i<row.size()?row.get(i):"");}out.add(m);}row=null;}}
                event=p.next();}
        }return out;
    }

    private static List<String> readSharedStrings(File file)throws Exception{ArrayList<String> out=new ArrayList<>();if(!file.isFile())return out;try(InputStream in=new BufferedInputStream(new FileInputStream(file))){XmlPullParser p=Xml.newPullParser();p.setInput(in,"UTF-8");int event=p.getEventType();StringBuilder item=null;while(event!=XmlPullParser.END_DOCUMENT){String name=p.getName();if(event==XmlPullParser.START_TAG&&"si".equals(name))item=new StringBuilder();else if(event==XmlPullParser.START_TAG&&"t".equals(name)&&item!=null)item.append(p.nextText());else if(event==XmlPullParser.END_TAG&&"si".equals(name)&&item!=null){out.add(item.toString());item=null;}event=p.next();}}return out;}
    private static int columnIndex(String ref){if(ref==null)return 0;int n=0;for(int i=0;i<ref.length();i++){char c=ref.charAt(i);if(c<'A'||c>'Z')break;n=n*26+(c-'A'+1);}return Math.max(0,n-1);}

    private static JSONObject localRecord(SQLiteDatabase db,String uid)throws Exception{try(Cursor c=db.rawQuery("SELECT record_no,subject,type,start_date,expected_date,assignee,agency,status,completion_date,notes,current_revision_uid FROM records WHERE uid=?",new String[]{uid})){if(!c.moveToFirst())return null;JSONObject o=new JSONObject();for(int i=0;i<c.getColumnCount();i++)o.put(c.getColumnName(i),c.isNull(i)?JSONObject.NULL:c.getString(i));o.put("uid",uid);return o;}}
    private static JSONObject diff(JSONObject a,JSONObject b)throws Exception{JSONObject d=new JSONObject();for(String f:CORE){String x=jsonString(a,f),y=jsonString(b,f);if(Objects.equals(x,y))continue;d.put(f,new JSONObject().put("old",x==null?JSONObject.NULL:x).put("new",y==null?JSONObject.NULL:y));}return d;}
    private static String findUidByDisplay(SQLiteDatabase db,String display){try(Cursor c=db.rawQuery("SELECT uid FROM records WHERE display_id=? LIMIT 1",new String[]{display})){return c.moveToFirst()?c.getString(0):"";}}
    private static boolean recordExists(SQLiteDatabase db,String uid){try(Cursor c=db.rawQuery("SELECT 1 FROM records WHERE uid=? LIMIT 1",new String[]{uid})){return c.moveToFirst();}}
    private static long nextSeq(SQLiteDatabase db){try(Cursor c=db.rawQuery("SELECT COALESCE(MAX(seq),0)+1 FROM records",null)){c.moveToFirst();return c.getLong(0);}}
    private static void putFields(ContentValues v,JSONObject o){for(String f:CORE){if(!o.has(f)||o.isNull(f))v.putNull(f);else v.put(f,String.valueOf(o.opt(f)));}}
    private static String jsonString(JSONObject o,String k){if(o==null||!o.has(k)||o.isNull(k))return null;return String.valueOf(o.opt(k));}
    private static String trim(String s){return s==null?"":s.trim();}private static String fallback(String s,String f){return s==null||s.trim().isEmpty()?f:s.trim();}private static Object nullValue(String s){String x=trim(s);return x.isEmpty()?JSONObject.NULL:x;}

    private static void extractSafe(InputStream input,File dir)throws Exception{try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(input))){ZipEntry e;byte[] buf=new byte[64*1024];while((e=zip.getNextEntry())!=null){String name=e.getName();if(name.contains("..")||name.startsWith("/")||name.startsWith("\\"))throw new IOException("مسار غير آمن داخل Excel");File out=new File(dir,name);String root=dir.getCanonicalPath()+File.separator;if(!out.getCanonicalPath().startsWith(root))throw new IOException("مسار غير آمن داخل Excel");if(e.isDirectory()){out.mkdirs();continue;}File parent=out.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("تعذر إنشاء مجلد مؤقت");try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){int n;while((n=zip.read(buf))!=-1)os.write(buf,0,n);}zip.closeEntry();}}}
    private static void deleteTree(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[] xs=f.listFiles();if(xs!=null)for(File x:xs)deleteTree(x);}f.delete();}
}
