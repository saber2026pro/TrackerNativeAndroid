package ye.tracker.nativeapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.*;
import java.util.UUID;
import java.util.zip.*;

/** Full local backup and verified restore: SQLite database + attachment files. */
public final class BackupManager {
    private BackupManager(){}

    public static synchronized void exportFull(Context c,DatabaseHelper db,OutputStream out)throws Exception{
        checkpoint(db);
        try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(out))){
            File dbFile=c.getDatabasePath(DatabaseHelper.DB_NAME);addFile(z,dbFile,"database/"+DatabaseHelper.DB_NAME);File att=new File(c.getFilesDir(),"attachments");addTree(z,att,"attachments");
            String meta="version=3\nexported_at="+TimeUtil.nowIso()+"\ndevice_id="+db.deviceId()+"\ndevice_name="+db.deviceName()+"\nphone_user="+db.phoneUserName()+"\nphone_role="+db.phoneUserRole()+"\nuser_username="+db.userUsername()+"\nexport_actor="+db.actorName()+"\nexport_role="+db.deviceRole()+"\n";
            z.putNextEntry(new ZipEntry("backup.properties"));z.write(meta.getBytes(java.nio.charset.StandardCharsets.UTF_8));z.closeEntry();z.finish();z.flush();
        }
    }

    public static synchronized void exportDatabaseOnly(Context c,DatabaseHelper db,OutputStream out)throws Exception{
        checkpoint(db);try(InputStream in=new BufferedInputStream(new FileInputStream(c.getDatabasePath(DatabaseHelper.DB_NAME)))){copy(in,out);}out.flush();
    }

    /** Destructive administrative restore. Caller must close/reopen DatabaseHelper after success. */
    public static synchronized RestoreResult restoreDatabaseOnly(Context c,DatabaseHelper db,InputStream input)throws Exception{
        File work=new File(c.getFilesDir(),"restore_work_"+UUID.randomUUID());if(!work.mkdirs())throw new IOException("تعذر إنشاء مساحة الاستعادة");
        File candidate=new File(work,"candidate.db");try(OutputStream out=new BufferedOutputStream(new FileOutputStream(candidate))){copy(input,out);}validateDatabase(candidate);
        checkpoint(db);db.close();
        File target=c.getDatabasePath(DatabaseHelper.DB_NAME);File rollback=new File(c.getFilesDir(),"restore_rollback_"+System.currentTimeMillis()+".db");
        if(target.isFile())copyFile(target,rollback);
        deleteWalSidecars(target);
        try{copyFile(candidate,target);validateDatabase(target);deleteTree(work);return new RestoreResult(rollback,null);}
        catch(Exception e){if(rollback.isFile())copyFile(rollback,target);deleteTree(work);throw e;}
    }

    /** Restores database and attachments from a .trackbackup archive after validating the database. */
    public static synchronized RestoreResult restoreFull(Context c,DatabaseHelper db,InputStream input)throws Exception{
        File work=new File(c.getFilesDir(),"restore_work_"+UUID.randomUUID());if(!work.mkdirs())throw new IOException("تعذر إنشاء مساحة الاستعادة");
        extractSafe(input,work);
        File candidate=new File(work,"database/"+DatabaseHelper.DB_NAME);if(!candidate.isFile()){deleteTree(work);throw new IOException("قاعدة البيانات غير موجودة داخل النسخة الاحتياطية");}
        validateDatabase(candidate);
        checkpoint(db);db.close();
        File target=c.getDatabasePath(DatabaseHelper.DB_NAME);File rollbackDb=new File(c.getFilesDir(),"restore_rollback_"+System.currentTimeMillis()+".db");if(target.isFile())copyFile(target,rollbackDb);
        File currentAtt=new File(c.getFilesDir(),"attachments");File rollbackAtt=new File(c.getFilesDir(),"attachments_before_restore_"+System.currentTimeMillis());
        if(currentAtt.exists()&&!currentAtt.renameTo(rollbackAtt)){copyTree(currentAtt,rollbackAtt);deleteTree(currentAtt);}
        deleteWalSidecars(target);
        try{
            copyFile(candidate,target);validateDatabase(target);
            File incomingAtt=new File(work,"attachments");if(incomingAtt.exists())copyTree(incomingAtt,currentAtt);else if(!currentAtt.exists())currentAtt.mkdirs();
            deleteTree(work);return new RestoreResult(rollbackDb,rollbackAtt.exists()?rollbackAtt:null);
        }catch(Exception e){
            if(rollbackDb.isFile())copyFile(rollbackDb,target);deleteTree(currentAtt);if(rollbackAtt.exists()&&!rollbackAtt.renameTo(currentAtt))copyTree(rollbackAtt,currentAtt);deleteTree(work);throw e;
        }
    }

    public static final class RestoreResult{
        public final File rollbackDatabase;public final File rollbackAttachments;
        RestoreResult(File db,File att){rollbackDatabase=db;rollbackAttachments=att;}
    }

    private static void validateDatabase(File file)throws Exception{
        if(!file.isFile()||file.length()<4096)throw new IOException("ملف قاعدة البيانات غير صالح أو فارغ");
        SQLiteDatabase test=null;try{
            test=SQLiteDatabase.openDatabase(file.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
            String[] required={"records","settings","device_profile","record_revisions","followups","attachments"};
            for(String table:required){try(Cursor c=test.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",new String[]{table})){if(!c.moveToFirst())throw new IOException("قاعدة البيانات لا تحتوي الجدول المطلوب: "+table);}}
            try(Cursor c=test.rawQuery("PRAGMA integrity_check(1)",null)){if(!c.moveToFirst()||!"ok".equalsIgnoreCase(c.getString(0)))throw new IOException("فشل فحص سلامة قاعدة البيانات");}
        }finally{if(test!=null)test.close();}
    }

    private static void checkpoint(DatabaseHelper db){try(Cursor x=db.getWritableDatabase().rawQuery("PRAGMA wal_checkpoint(FULL)",null)){while(x.moveToNext()){} }}
    private static void addTree(ZipOutputStream z,File f,String path)throws IOException{if(!f.exists())return;if(f.isDirectory()){File[] xs=f.listFiles();if(xs!=null)for(File x:xs)addTree(z,x,path+"/"+x.getName());}else addFile(z,f,path);}
    private static void addFile(ZipOutputStream z,File f,String name)throws IOException{z.putNextEntry(new ZipEntry(name));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){copy(in,z);}z.closeEntry();}
    private static void copy(InputStream in,OutputStream out)throws IOException{byte[] b=new byte[64*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
    private static void copyFile(File a,File b)throws IOException{File parent=b.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("تعذر إنشاء المجلد");try(InputStream in=new BufferedInputStream(new FileInputStream(a));OutputStream out=new BufferedOutputStream(new FileOutputStream(b))){copy(in,out);}}
    private static void copyTree(File a,File b)throws IOException{if(a.isDirectory()){if(!b.exists()&&!b.mkdirs())throw new IOException("تعذر إنشاء مجلد المرفقات");File[] xs=a.listFiles();if(xs!=null)for(File x:xs)copyTree(x,new File(b,x.getName()));}else copyFile(a,b);}
    private static void deleteTree(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[] xs=f.listFiles();if(xs!=null)for(File x:xs)deleteTree(x);}f.delete();}
    private static void deleteWalSidecars(File target){new File(target.getAbsolutePath()+"-wal").delete();new File(target.getAbsolutePath()+"-shm").delete();new File(target.getAbsolutePath()+"-journal").delete();}
    private static void extractSafe(InputStream input,File dir)throws Exception{try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(input))){ZipEntry e;byte[] buf=new byte[64*1024];while((e=zip.getNextEntry())!=null){String name=e.getName();if(name.contains("..")||name.startsWith("/")||name.startsWith("\\"))throw new IOException("مسار غير آمن داخل النسخة الاحتياطية");File out=new File(dir,name);String root=dir.getCanonicalPath()+File.separator;if(!out.getCanonicalPath().startsWith(root))throw new IOException("مسار غير آمن داخل النسخة الاحتياطية");if(e.isDirectory()){out.mkdirs();continue;}File parent=out.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new IOException("تعذر إنشاء مجلد مؤقت");try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){int n;while((n=zip.read(buf))!=-1)os.write(buf,0,n);}zip.closeEntry();}}}
}
