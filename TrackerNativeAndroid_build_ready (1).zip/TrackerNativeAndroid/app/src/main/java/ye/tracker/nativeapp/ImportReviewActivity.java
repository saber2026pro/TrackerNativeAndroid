package ye.tracker.nativeapp;

import android.app.*;
import android.database.Cursor;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.util.*;

/** Review incoming changes record-by-record before modifying local data. */
public final class ImportReviewActivity extends Activity {
    private DatabaseHelper db;
    private String importId;
    private LinearLayout body;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);db=((TrackerApp)getApplication()).db();importId=getIntent().getStringExtra("import_id");
        if(importId==null||importId.isEmpty()){finish();return;}
        if(!db.isAdminSession()){Ui.toast(this,"يلزم الدخول كمسؤول النظام لمراجعة الاستيراد");finish();return;}
        render();
    }

    private void render(){
        ScrollView scroll=new ScrollView(this);body=Ui.column(this);scroll.addView(body);setContentView(scroll);
        LinearLayout head=Ui.row(this);Button back=Ui.button(this,"رجوع");head.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,86),Ui.dp(this,48)));back.setOnClickListener(v->finish());
        TextView title=Ui.title(this,"مراجعة التغييرات المستوردة");head.addView(title,new LinearLayout.LayoutParams(0,-2,1));body.addView(head,Ui.match());
        int pending=SyncPackageManager.pendingCount(db,importId);
        body.addView(Ui.label(this,"تُراجع التعديلات والتعارضات فقط. الإضافات الجديدة والمرفقات الجديدة تُدمج تلقائيًا، أما البيانات الموجودة فلا تُستبدل دون قرارك."),Ui.match());
        body.addView(Ui.title(this,"بانتظار القرار: "+pending),Ui.match());
        if(pending==0){
            SyncPackageManager.cleanupIfResolved(this,db,importId);
            TextView done=Ui.label(this,"تمت معالجة الحزمة ولا توجد تغييرات معلقة. بقي تاريخ الاستيراد محفوظًا في سجل التبادل وسجل التغييرات.");done.setTextSize(Ui.sp(this,16));body.addView(done,Ui.cardParams(this));return;
        }
        try(Cursor c=SyncPackageManager.pendingCursor(db,importId)){
            int shown=0;
            while(c.moveToNext()&&shown<300){addItem(c);shown++;}
            if(c.getCount()>shown)body.addView(Ui.label(this,"يتم عرض أول 300 تغيير. عالجها ثم ستظهر الدفعة التالية."),Ui.match());
        }
    }

    private void addItem(Cursor c){
        final long itemId=c.getLong(c.getColumnIndexOrThrow("_id"));
        final String entity=c.getString(c.getColumnIndexOrThrow("entity_type"));
        final String kind=c.getString(c.getColumnIndexOrThrow("kind"));
        final String display=c.getString(c.getColumnIndexOrThrow("display_id"));
        final String subject=c.getString(c.getColumnIndexOrThrow("subject"));
        final String diff=c.isNull(c.getColumnIndexOrThrow("diff_json"))?"{}":c.getString(c.getColumnIndexOrThrow("diff_json"));
        final String peerName=c.getString(c.getColumnIndexOrThrow("peer_name"));
        final String peerDevice=c.getString(c.getColumnIndexOrThrow("peer_device_id"));
        final String revisionPayload=c.getString(c.getColumnIndexOrThrow("revision_payload"));

        LinearLayout card=Ui.card(this);card.setOrientation(LinearLayout.VERTICAL);
        String entityLabel="RECORD".equals(entity)?"السجل الرئيسي":"مجرى متابعة";
        TextView t=Ui.title(this,(display==null||display.isEmpty()?"":display+" — ")+(subject==null||subject.isEmpty()?entityLabel:subject));t.setTextSize(Ui.sp(this,16));card.addView(t,Ui.match());
        TextView badge=Ui.label(this,entityLabel+" | "+kindLabel(kind));badge.setTextColor(ThemeManager.palette(this).primary);card.addView(badge,Ui.match());
        TextView source=Ui.label(this,sourceText(peerName,peerDevice,revisionPayload));source.setTextSize(Ui.sp(this,13));card.addView(source,Ui.match());
        TextView changes=Ui.label(this,diffText(diff));changes.setTextSize(Ui.sp(this,14));card.addView(changes,Ui.match());

        LinearLayout actions=Ui.row(this);
        Button keep=Ui.button(this,"الاحتفاظ بالسابق");actions.addView(keep,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        Button incoming=Ui.button(this,"اعتماد الجديد");actions.addView(incoming,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        keep.setOnClickListener(v->{try{SyncPackageManager.keepLocal(db,itemId);refresh();}catch(Exception e){Ui.toast(this,e.getMessage());}});
        incoming.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("اعتماد النسخة الواردة؟").setMessage("ستصبح النسخة الواردة هي الحالية، مع بقاء النسخة السابقة محفوظة في سجل الإصدارات.").setPositiveButton("اعتماد",(d,w)->{try{SyncPackageManager.acceptIncoming(db,itemId);refresh();}catch(Exception e){Ui.toast(this,"تعذر الاعتماد: "+e.getMessage());}}).setNegativeButton("إلغاء",null).show());
        card.addView(actions,Ui.match());

        if("RECORD".equals(entity)&&!"DELETE".equals(kind)){
            Button merge=Ui.button(this,"دمج حقول مختارة من الجديد");card.addView(merge,Ui.match());merge.setOnClickListener(v->mergeDialog(itemId,diff));
        }
        body.addView(card,Ui.cardParams(this));
    }

    private void mergeDialog(long itemId,String diffText){
        try{
            JSONObject d=new JSONObject(diffText);ArrayList<String> keys=new ArrayList<>();ArrayList<String> labels=new ArrayList<>();
            Iterator<String> it=d.keys();while(it.hasNext()){String k=it.next();keys.add(k);JSONObject x=d.optJSONObject(k);String old=x==null?"":x.optString("old","—"), neu=x==null?"":x.optString("new","—");labels.add(fieldLabel(k)+"\nالحالي: "+old+"\nالوارد: "+neu);}
            if(keys.isEmpty()){Ui.toast(this,"لا توجد حقول قابلة للدمج");return;}
            boolean[] checked=new boolean[keys.size()];
            new AlertDialog.Builder(this).setTitle("اختر الحقول التي ستأخذ قيمتها من النسخة الجديدة").setMultiChoiceItems(labels.toArray(new String[0]),checked,(d0,which,isChecked)->checked[which]=isChecked)
                    .setPositiveButton("تنفيذ الدمج",(d0,w)->{Set<String> selected=new LinkedHashSet<>();for(int i=0;i<checked.length;i++)if(checked[i])selected.add(keys.get(i));if(selected.isEmpty()){Ui.toast(this,"لم تحدد أي حقل");return;}try{SyncPackageManager.mergeRecordFields(db,itemId,selected);refresh();}catch(Exception e){Ui.toast(this,"تعذر الدمج: "+e.getMessage());}})
                    .setNegativeButton("إلغاء",null).show();
        }catch(Exception e){Ui.toast(this,"تعذر قراءة تفاصيل التغيير");}
    }

    private void refresh(){body.removeAllViews();render();}


    private String sourceText(String peerName,String peerDevice,String revisionPayload){
        String actor="", role="", changedAt="";
        try{
            if(revisionPayload!=null&&!revisionPayload.isEmpty()){
                JSONObject r=new JSONObject(revisionPayload);
                actor=r.optString("actor_name","");role=r.optString("actor_role","");changedAt=r.optString("created_at","");
            }
        }catch(Exception ignored){}
        StringBuilder s=new StringBuilder("المصدر: ");
        if(actor!=null&&!actor.isEmpty())s.append(actor);else if(peerName!=null&&!peerName.isEmpty())s.append(peerName);else s.append("جهاز مستورد");
        if(role!=null&&!role.isEmpty())s.append(" — ").append(role);
        if(peerDevice!=null&&!peerDevice.isEmpty())s.append("\nمعرف الجهاز: ").append(shortId(peerDevice));
        if(changedAt!=null&&!changedAt.isEmpty())s.append("\nوقت التعديل في المصدر: ").append(changedAt);
        return s.toString();
    }

    private String shortId(String id){if(id==null)return "—";return id.length()<=12?id:id.substring(0,12)+"…";}

    private String diffText(String json){
        try{JSONObject d=new JSONObject(json);StringBuilder s=new StringBuilder();Iterator<String> it=d.keys();int n=0;while(it.hasNext()){String k=it.next();JSONObject x=d.optJSONObject(k);if(x==null)continue;if(n++>0)s.append("\n");s.append(fieldLabel(k)).append(": ").append(value(x,"old")).append(" ← ").append(value(x,"new"));}return n==0?"لا توجد فروق نصية في الحقول الأساسية.":s.toString();}catch(Exception e){return "تفاصيل التغيير متاحة في سجل الاستيراد.";}
    }
    private String value(JSONObject o,String k){return o.isNull(k)||!o.has(k)?"—":String.valueOf(o.opt(k));}
    private String kindLabel(String k){if("UPDATE".equals(k))return "تعديل لاحق على نسخة سبق استيرادها";if("CONFLICT".equals(k))return "تعارض بين نسختين";if("DELETE".equals(k))return "طلب حذف وارد";if("EXCEL_UPDATE".equals(k))return "تعديل وارد من Excel";return k;}
    private String fieldLabel(String k){
        switch(k){case "record_no":return "رقم العمل";case "subject":return "الموضوع";case "type":return "النوع";case "start_date":return "تاريخ البدء";case "expected_date":return "الانتهاء المتوقع";case "assignee":return "المعني بالمهمة";case "agency":return "الجهة";case "status":return "الحالة";case "completion_date":return "تاريخ الإنجاز";case "notes":return "الملاحظات";case "event_at":return "تاريخ مجرى المتابعة";case "text":return "مجرى المتابعة";default:return k;}
    }
}
