package ye.tracker.nativeapp;

import android.content.Context;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Native exports without WebView or third-party spreadsheet/PDF libraries. */
public final class ExportManager {
    private ExportManager() {}

    public static void exportPdf(DatabaseHelper db, OutputStream out) throws Exception {
        PdfDocument pdf = new PdfDocument();
        Paint title = new Paint(Paint.ANTI_ALIAS_FLAG); title.setTextSize(18); title.setTypeface(Typeface.DEFAULT_BOLD); title.setTextAlign(Paint.Align.RIGHT);
        Paint text = new Paint(Paint.ANTI_ALIAS_FLAG); text.setTextSize(10); text.setTextAlign(Paint.Align.RIGHT);
        int pageNo=1, y=55; PdfDocument.Page page = newPage(pdf,pageNo); Canvas canvas=page.getCanvas();
        canvas.drawText("نظام متابعة التقارير والخطط — سجل المتابعة", 555, 32, title);
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT display_id,record_no,subject,type,status,agency,assignee,start_date,expected_date,completion_date FROM records WHERE deleted=0 ORDER BY _id",null)){
            while(c.moveToNext()){
                if(y>790){pdf.finishPage(page);page=newPage(pdf,++pageNo);canvas=page.getCanvas();y=45;}
                String line=s(c,0)+" | "+s(c,3)+" | "+s(c,4)+" | "+s(c,2);
                canvas.drawText(ellipsize(line,95),555,y,text);y+=16;
                String line2="الجهة: "+s(c,5)+" | المعني: "+s(c,6)+" | البدء: "+s(c,7)+" | المتوقع: "+s(c,8);
                canvas.drawText(ellipsize(line2,105),555,y,text);y+=20;
            }
        }
        pdf.finishPage(page); pdf.writeTo(out); pdf.close();
    }

    private static PdfDocument.Page newPage(PdfDocument pdf,int n){return pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,n).create());}
    private static String s(Cursor c,int i){return c.isNull(i)?"":c.getString(i);}
    private static String ellipsize(String s,int max){return s.length()<=max?s:s.substring(0,max-1)+"…";}

    public static void exportXlsx(DatabaseHelper db, OutputStream out) throws Exception {
        ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(out));
        put(z,"[Content_Types].xml",contentTypes());
        put(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        put(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"السجل\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"مجريات المتابعة\" sheetId=\"2\" r:id=\"rId2\"/><sheet name=\"المرفقات\" sheetId=\"3\" r:id=\"rId3\"/></sheets></workbook>");
        put(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/><Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet3.xml\"/></Relationships>");
        writeRecordsSheet(db,z); writeFollowupsSheet(db,z); writeAttachmentsSheet(db,z); z.finish(); z.flush();
    }

    private static String contentTypes(){return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>";}

    private static void writeRecordsSheet(DatabaseHelper db,ZipOutputStream z)throws Exception{
        String[] h={"المعرف","رقم العمل","الموضوع / مهمة العمل","النوع","تاريخ البدء","تاريخ الانتهاء المتوقع","المعني بالمهمة","الجهة المعنية بالمتابعة","حالة المهمة","تاريخ الإنجاز الفعلي","الملاحظات","آخر تحديث","معرف الجهاز المنشئ","معرف جهاز آخر تعديل","المعرف الداخلي (لا يعدل)","معرف الإصدار (لا يعدل)"};
        String sql="SELECT display_id,record_no,subject,type,start_date,expected_date,assignee,agency,status,completion_date,notes,updated_at,origin_device_id,updated_device_id,uid,current_revision_uid FROM records WHERE deleted=0 ORDER BY _id";
        writeCursorSheet(db,z,"xl/worksheets/sheet1.xml",h,sql);
    }
    private static void writeFollowupsSheet(DatabaseHelper db,ZipOutputStream z)throws Exception{
        String[] h={"معرف المتابعة","معرف السجل","التاريخ","مجريات المتابعة","تاريخ الإنشاء","آخر تعديل","جهاز الإنشاء","جهاز آخر تعديل"};
        String sql="SELECT f.uid,r.display_id,f.event_at,f.text,f.created_at,f.updated_at,f.origin_device_id,f.updated_device_id FROM followups f JOIN records r ON r.uid=f.record_uid WHERE f.deleted=0 AND r.deleted=0 ORDER BY f._id";
        writeCursorSheet(db,z,"xl/worksheets/sheet2.xml",h,sql);
    }
    private static void writeAttachmentsSheet(DatabaseHelper db,ZipOutputStream z)throws Exception{
        String[] h={"معرف المرفق","معرف السجل","اسم الملف","النوع","الحجم","SHA-256","تاريخ الإضافة","جهاز المصدر"};
        String sql="SELECT a.uid,r.display_id,a.file_name,a.mime_type,a.size_bytes,a.sha256,a.created_at,a.origin_device_id FROM attachments a JOIN records r ON r.uid=a.record_uid WHERE a.deleted=0 AND r.deleted=0 ORDER BY a._id";
        writeCursorSheet(db,z,"xl/worksheets/sheet3.xml",h,sql);
    }
    private static void writeCursorSheet(DatabaseHelper db,ZipOutputStream z,String path,String[] headers,String sql)throws Exception{
        z.putNextEntry(new ZipEntry(path));Writer w=new OutputStreamWriter(z,java.nio.charset.StandardCharsets.UTF_8);w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"/></sheetViews><sheetData>");int row=1;writeRow(w,row++,headers);try(Cursor c=db.getReadableDatabase().rawQuery(sql,null)){while(c.moveToNext()){String[] vals=new String[c.getColumnCount()];for(int i=0;i<vals.length;i++)vals[i]=c.isNull(i)?"":c.getString(i);writeRow(w,row++,vals);}}w.write("</sheetData></worksheet>");w.flush();z.closeEntry();
    }
    private static void writeRow(Writer w,int row,String[] vals)throws IOException{w.write("<row r=\"");w.write(String.valueOf(row));w.write("\">");for(int i=0;i<vals.length;i++){w.write("<c r=\"");w.write(col(i+1));w.write(String.valueOf(row));w.write("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">");w.write(xml(vals[i]));w.write("</t></is></c>");}w.write("</row>");}
    private static String col(int n){StringBuilder s=new StringBuilder();while(n>0){n--;s.insert(0,(char)('A'+n%26));n/=26;}return s.toString();}
    private static String xml(String s){if(s==null)return "";return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private static void put(ZipOutputStream z,String name,String text)throws IOException{z.putNextEntry(new ZipEntry(name));z.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));z.closeEntry();}
}
