package ye.tracker.nativeapp;

/** Central role policy. Every write surface should consult this class. */
public final class AccessPolicy {
    private AccessPolicy() {}

    public static boolean isAdmin(DatabaseHelper db){ return db.isAdminSession(); }
    public static boolean isSupervisor(DatabaseHelper db){ return "مشرف".equals(db.deviceRole()); }
    public static boolean isFollower(DatabaseHelper db){ return "متابع".equals(db.deviceRole()); }
    public static boolean isViewer(DatabaseHelper db){ return "مطلع فقط".equals(db.deviceRole()); }

    public static boolean canCreate(DatabaseHelper db){ return isAdmin(db) || isSupervisor(db) || isFollower(db); }
    public static boolean canEdit(DatabaseHelper db){ return isAdmin(db) || isSupervisor(db) || isFollower(db); }
    public static boolean canManageFollowups(DatabaseHelper db){ return canEdit(db); }
    public static boolean canManageAttachments(DatabaseHelper db){ return canEdit(db); }
    public static boolean canManageAlerts(DatabaseHelper db){ return canEdit(db); }
    public static boolean canDelete(DatabaseHelper db){ return isAdmin(db) || isSupervisor(db); }
    public static boolean canExport(DatabaseHelper db){ return isAdmin(db) || isSupervisor(db) || isFollower(db); }
    public static boolean canImport(DatabaseHelper db){ return isAdmin(db); }
    public static boolean canChangeSettings(DatabaseHelper db){ return isAdmin(db); }
}
