package ye.tracker.nativeapp;
import android.content.*;
public final class BootReceiver extends BroadcastReceiver{
    @Override public void onReceive(Context c,Intent i){NotificationScheduler.ensureChannel(c);NotificationScheduler.scheduleDaily(c);DatabaseHelper db=new DatabaseHelper(c);RecordAlertManager.scheduleAll(c,db);}
}
