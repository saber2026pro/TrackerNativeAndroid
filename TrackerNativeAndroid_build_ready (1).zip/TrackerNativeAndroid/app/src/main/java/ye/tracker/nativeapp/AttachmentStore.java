package ye.tracker.nativeapp;

import android.content.*;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;

public final class AttachmentStore {
 private AttachmentStore(){}
 public static int importSelection(Context c,DatabaseHelper db,String recordUid,Intent data)throws Exception{
   if(!AccessPolicy.canManageAttachments(db))throw new SecurityException("لا توجد صلاحية لإضافة مرفقات");
   ArrayList<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)uris.add(data.getData());int count=0;for(Uri u:uris){if(importOne(c,db,recordUid,u))count++;}return count;
 }
 private static boolean importOne(Context c,DatabaseHelper h,String recordUid,Uri uri)throws Exception{
   String name="attachment",mime=c.getContentResolver().getType(uri);long declared=0;try(android.database.Cursor q=c.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){if(q!=null&&q.moveToFirst()){int ni=q.getColumnIndex(OpenableColumns.DISPLAY_NAME),si=q.getColumnIndex(OpenableColumns.SIZE);if(ni>=0)name=q.getString(ni);if(si>=0&&!q.isNull(si))declared=q.getLong(si);}}
   File dir=new File(c.getFilesDir(),"attachments/"+recordUid);if(!dir.exists()&&!dir.mkdirs())throw new IOException("تعذر إنشاء مجلد المرفقات");String stored=UUID.randomUUID()+ext(name);File out=new File(dir,stored);MessageDigest md=MessageDigest.getInstance("SHA-256");long size=0;try(InputStream in=c.getContentResolver().openInputStream(uri);OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){if(in==null)throw new IOException("تعذر فتح الملف");byte[] buf=new byte[64*1024];int n;while((n=in.read(buf))!=-1){os.write(buf,0,n);md.update(buf,0,n);size+=n;}}
   String sha=hex(md.digest());SQLiteDatabase db=h.getWritableDatabase();try(android.database.Cursor ex=db.rawQuery("SELECT 1 FROM attachments WHERE record_uid=? AND sha256=? AND size_bytes=? AND deleted=0 LIMIT 1",new String[]{recordUid,sha,String.valueOf(size)})){if(ex.moveToFirst()){out.delete();return false;}}
   db.execSQL("INSERT INTO attachments(uid,record_uid,file_name,mime_type,stored_name,relative_path,size_bytes,sha256,origin_device_id,created_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,0)",new Object[]{UUID.randomUUID().toString(),recordUid,name,mime,stored,"attachments/"+recordUid+"/"+stored,size,sha,h.deviceId(),TimeUtil.nowIso()});return true;
 }
 public static void exportRecord(Context c,DatabaseHelper h,String recordUid,OutputStream output)throws Exception{
   if(!AccessPolicy.canExport(h))throw new SecurityException("لا توجد صلاحية للتصدير");
   java.util.zip.ZipOutputStream z=new java.util.zip.ZipOutputStream(new BufferedOutputStream(output));java.util.HashSet<String> used=new java.util.HashSet<>();
   try(android.database.Cursor q=h.getReadableDatabase().rawQuery("SELECT uid,file_name,relative_path FROM attachments WHERE record_uid=? AND deleted=0 ORDER BY _id",new String[]{recordUid})){
     while(q.moveToNext()){File f=new File(c.getFilesDir(),q.getString(2));if(!f.isFile())continue;String name=safeEntry(q.getString(1));if(name.isEmpty())name=q.getString(0);String base=name;int k=2;while(!used.add(name)){name=k+"_"+base;k++;}z.putNextEntry(new java.util.zip.ZipEntry(name));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[64*1024];int n;while((n=in.read(b))!=-1)z.write(b,0,n);}z.closeEntry();}
   }z.finish();z.flush();
 }
 public static void delete(Context c,DatabaseHelper h,String uid){
   if(!AccessPolicy.canDelete(h))throw new SecurityException("الحذف متاح لمسؤول النظام أو المشرف فقط");SQLiteDatabase db=h.getWritableDatabase();String rel=null,record=null,name=null;try(android.database.Cursor q=db.rawQuery("SELECT record_uid,relative_path,file_name FROM attachments WHERE uid=? AND deleted=0",new String[]{uid})){if(q.moveToFirst()){record=q.getString(0);rel=q.getString(1);name=q.getString(2);}}if(record==null)return;db.execSQL("UPDATE attachments SET deleted=1 WHERE uid=?",new Object[]{uid});db.execSQL("INSERT INTO audit_events(uid,entity_type,entity_uid,record_uid,device_id,actor_name,actor_role,operation,source,occurred_at,details) VALUES(?,?,?,?,?,?,?,?,?,?,?)",new Object[]{UUID.randomUUID().toString(),"ATTACHMENT",uid,record,h.deviceId(),h.actorName(),h.deviceRole(),"DELETE","يدوي",TimeUtil.nowIso(),name});if(rel!=null)new File(c.getFilesDir(),rel).delete();
 }
 private static String safeEntry(String s){if(s==null)return "";String x=s.replace('\\','_').replace('/','_').replaceAll("[\r\n\t]","_");while(x.startsWith("."))x=x.substring(1);return x;}
 private static String ext(String n){int i=n.lastIndexOf('.');if(i<0||n.length()-i>12)return "";return n.substring(i).replaceAll("[^A-Za-z0-9.]","");}
 private static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x));return s.toString();}
}
