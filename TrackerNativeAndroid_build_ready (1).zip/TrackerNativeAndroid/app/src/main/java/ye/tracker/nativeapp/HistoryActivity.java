package ye.tracker.nativeapp;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public final class HistoryActivity extends Activity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);String uid=getIntent().getStringExtra("followup_uid");DatabaseHelper db=((TrackerApp)getApplication()).db();TrackerRepository repo=new TrackerRepository(db);LinearLayout root=Ui.column(this);root.addView(Ui.title(this,"تاريخ مجريات المتابعة"));ListView l=new ListView(this);root.addView(l,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);Cursor c=repo.followupHistory(uid);l.setAdapter(new SimpleCursorAdapter(this,android.R.layout.simple_list_item_2,c,new String[]{"operation","created_at"},new int[]{android.R.id.text1,android.R.id.text2},0));l.setOnItemClickListener((p,v,pos,id)->{Cursor x=(Cursor)p.getItemAtPosition(pos);String msg="العملية: "+x.getString(x.getColumnIndexOrThrow("operation"))+"\nالوقت: "+x.getString(x.getColumnIndexOrThrow("created_at"))+"\nالمستخدم: "+x.getString(x.getColumnIndexOrThrow("actor_name"))+" — "+(x.isNull(x.getColumnIndexOrThrow("actor_role"))?"—":x.getString(x.getColumnIndexOrThrow("actor_role")))+"\n\n"+x.getString(x.getColumnIndexOrThrow("text"));new android.app.AlertDialog.Builder(this).setTitle("نسخة الإدخال").setMessage(msg).setPositiveButton("إغلاق",null).show();});}
}
