package ye.tracker.nativeapp;

import android.content.*;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Read-only provider for opening private attachments with one-time URI grants. */
public final class AttachmentContentProvider extends ContentProvider {
    public static final String AUTHORITY="ye.tracker.nativeapp.attachments";
    @Override public boolean onCreate(){return true;}

    @Override public String getType(Uri uri){
        String uid=uid(uri);if(uid==null)return "application/octet-stream";DatabaseHelper db=TrackerApp.app().db();
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT mime_type FROM attachments WHERE uid=? AND deleted=0",new String[]{uid})){return c.moveToFirst()&&!c.isNull(0)?c.getString(0):"application/octet-stream";}
    }

    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{
        if(!"r".equals(mode)&&!"rt".equals(mode))throw new FileNotFoundException("Read only");String id=uid(uri);if(id==null)throw new FileNotFoundException();
        DatabaseHelper db=TrackerApp.app().db();String rel=null;try(Cursor c=db.getReadableDatabase().rawQuery("SELECT relative_path FROM attachments WHERE uid=? AND deleted=0",new String[]{id})){if(c.moveToFirst())rel=c.getString(0);}if(rel==null)throw new FileNotFoundException();
        try{File root=getContext().getFilesDir().getCanonicalFile(),f=new File(root,rel).getCanonicalFile();if(!f.getPath().startsWith(root.getPath()+File.separator)||!f.isFile())throw new FileNotFoundException();return ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);}catch(Exception e){throw new FileNotFoundException(e.getMessage());}
    }

    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        String id=uid(uri);MatrixCursor out=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});if(id==null)return out;DatabaseHelper db=TrackerApp.app().db();try(Cursor c=db.getReadableDatabase().rawQuery("SELECT file_name,size_bytes FROM attachments WHERE uid=? AND deleted=0",new String[]{id})){if(c.moveToFirst())out.addRow(new Object[]{c.getString(0),c.getLong(1)});}return out;
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){throw new UnsupportedOperationException();}
    private String uid(Uri u){if(u==null||!AUTHORITY.equals(u.getAuthority())||u.getPathSegments().size()!=2||!"attachment".equals(u.getPathSegments().get(0)))return null;return u.getPathSegments().get(1);}
    public static Uri uri(String uid){return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("attachment").appendPath(uid).build();}
}
