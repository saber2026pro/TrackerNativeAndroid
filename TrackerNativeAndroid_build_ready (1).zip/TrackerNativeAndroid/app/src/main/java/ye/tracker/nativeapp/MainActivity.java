package ye.tracker.nativeapp;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.concurrent.Executor;

public final class MainActivity extends Activity {
    private DatabaseHelper db;
    private TrackerRepository repo;
    private LinearLayout root, content;
    private FrameLayout appFrame;
    private LinearLayout sidebar;
    private TextView pageTitleView;
    private boolean sidebarOpen=false;
    private boolean persistentSidebar=false;
    private String settingsTab="appearance";
    private boolean unlocked=false;
    private String currentPage="لوحة المؤشرات";
    private String pendingRecordUid;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        db=((TrackerApp)getApplication()).db(); repo=new TrackerRepository(db); pendingRecordUid=getIntent().getStringExtra("record_uid");
        if(!db.isConfigured() || db.adminUsername().isEmpty() || db.userUsername().isEmpty() || !SecurityManager.hasPassword(db,"admin_password") || !SecurityManager.hasPassword(db,"user_password")) showFirstRun(); else showLogin();
    }

    private void showFirstRun(){
        LinearLayout box=Ui.column(this);box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(Ui.title(this,"تهيئة النظام لأول مرة"));
        TextView note=Ui.label(this,"المرحلة 1 من 2 — إنشاء حساب مسؤول النظام. هذا الحساب يملك إعدادات النظام والاستيراد ومراجعة التعارضات ولا يُستخدم كحساب العمل اليومي على الهاتف.");note.setTextSize(Ui.sp(this,15));box.addView(note,Ui.match());
        EditText adminUser=Ui.edit(this,"اسم مستخدم مسؤول النظام");box.addView(adminUser,Ui.match());
        EditText adminName=Ui.edit(this,"اسم مسؤول النظام الظاهر في سجل التغييرات");adminName.setText("مسؤول النظام");box.addView(adminName,Ui.match());
        EditText adminPassword=Ui.edit(this,"كلمة مرور مسؤول النظام");adminPassword.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(adminPassword,Ui.match());
        EditText adminConfirm=Ui.edit(this,"تأكيد كلمة مرور مسؤول النظام");adminConfirm.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(adminConfirm,Ui.match());
        Button next=Ui.button(this,"التالي — تهيئة مستخدم الهاتف");box.addView(next,Ui.match());
        next.setOnClickListener(v->{
            String au=adminUser.getText().toString().trim(),an=adminName.getText().toString().trim(),ap=adminPassword.getText().toString();
            if(au.isEmpty()){adminUser.setError("مطلوب");return;}if(an.isEmpty()){adminName.setError("مطلوب");return;}
            if(ap.length()<4){adminPassword.setError("الحد الأدنى 4 أحرف أو أرقام");return;}if(!ap.equals(adminConfirm.getText().toString())){adminConfirm.setError("كلمتا المرور غير متطابقتين");return;}
            showFirstRunUser(au,an,ap);
        });
        ScrollView scroll=new ScrollView(this);scroll.addView(box);setContentView(scroll);
    }

    private void showFirstRunUser(String adminUsername,String adminName,String adminPassword){
        LinearLayout box=Ui.column(this);box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(Ui.title(this,"تهيئة مستخدم هذا الهاتف"));
        TextView note=Ui.label(this,"المرحلة 2 من 2 — هذا الهاتف يرتبط بمستخدم عمل واحد فقط. بعد الحفظ يتعرف النظام على المستخدم من اسم الدخول وكلمة المرور، وتُسجل كل عملياته باسم هذا المستخدم ومعرف الجهاز.");note.setTextSize(Ui.sp(this,15));box.addView(note,Ui.match());
        EditText userLogin=Ui.edit(this,"اسم المستخدم للدخول");box.addView(userLogin,Ui.match());
        EditText userPassword=Ui.edit(this,"كلمة مرور المستخدم");userPassword.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(userPassword,Ui.match());
        EditText userConfirm=Ui.edit(this,"تأكيد كلمة مرور المستخدم");userConfirm.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(userConfirm,Ui.match());
        EditText name=Ui.edit(this,"اسم المستخدم الظاهر في السجلات");box.addView(name,Ui.match());
        EditText job=Ui.edit(this,"المسمى أو العمل (اختياري)");box.addView(job,Ui.match());
        box.addView(Ui.label(this,"صلاحية مستخدم الهاتف"),Ui.match());
        Spinner role=new Spinner(this);String[] roles={"مشرف","متابع","مطلع فقط"};role.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,roles));role.setSelection(1);box.addView(role,Ui.match());
        EditText deviceName=Ui.edit(this,"اسم الجهاز داخل النظام — مثال: هاتف أحمد / المتابعة");box.addView(deviceName,Ui.match());
        LinearLayout actions=Ui.row(this);Button back=Ui.button(this,"رجوع");Button save=Ui.button(this,"حفظ التهيئة");actions.addView(back,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));actions.addView(save,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));box.addView(actions,Ui.match());
        back.setOnClickListener(v->showFirstRun());
        save.setOnClickListener(v->{
            String up=userLogin.getText().toString().trim(),pn=name.getText().toString().trim(),pw=userPassword.getText().toString(),dev=deviceName.getText().toString().trim();
            if(up.isEmpty()){userLogin.setError("مطلوب");return;}if(adminUsername.equalsIgnoreCase(up)){userLogin.setError("يجب أن يختلف اسم المستخدم عن اسم مسؤول النظام");return;}
            if(pn.isEmpty()){name.setError("مطلوب");return;}if(pw.length()<4){userPassword.setError("الحد الأدنى 4 أحرف أو أرقام");return;}if(!pw.equals(userConfirm.getText().toString())){userConfirm.setError("كلمتا المرور غير متطابقتين");return;}
            if(dev.isEmpty())dev="هاتف "+pn;
            db.configureDevice(pn,String.valueOf(role.getSelectedItem()),dev,adminName);db.configureCredentials(adminUsername,adminName,up);db.setSetting("user_job",job.getText().toString().trim());
            SecurityManager.setPassword(db,"admin_password",adminPassword);SecurityManager.setPassword(db,"user_password",pw);db.endSession();unlocked=false;showLogin();
        });
        ScrollView scroll=new ScrollView(this);scroll.addView(box);setContentView(scroll);
    }

    private void showLogin(){
        unlocked=false;db.endSession();
        LinearLayout box=Ui.column(this);box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(Ui.title(this,"تسجيل الدخول"));
        TextView device=Ui.label(this,db.deviceName()+"\nمعرف الجهاز: "+shortId(db.deviceId()));device.setTextSize(Ui.sp(this,14));box.addView(device,Ui.match());
        EditText username=Ui.edit(this,"اسم المستخدم");box.addView(username,Ui.match());
        EditText password=Ui.edit(this,"كلمة المرور");password.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(password,Ui.match());
        Button login=Ui.button(this,"دخول");box.addView(login,Ui.match());
        login.setOnClickListener(v->{
            String u=username.getText().toString().trim(), pw=password.getText().toString();
            if(u.equalsIgnoreCase(db.adminUsername()) && SecurityManager.verifyPassword(db,"admin_password",pw)){
                db.beginAdminSession();unlocked=true;buildApp();return;
            }
            if(u.equalsIgnoreCase(db.userUsername()) && SecurityManager.verifyPassword(db,"user_password",pw)){
                db.beginUserSession();unlocked=true;buildApp();return;
            }
            password.setError("اسم المستخدم أو كلمة المرور غير صحيحة");
        });
        Button bio=Ui.button(this,"فتح بالبصمة كمستخدم هذا الهاتف");box.addView(bio,Ui.match());
        boolean biometricOn="1".equals(db.setting("biometric_enabled","1"));
        if(!biometricOn){bio.setEnabled(false);bio.setText("فتح التطبيق بالبصمة متوقف من الإعدادات");}
        else if(!SecurityManager.biometricAvailable(this)){bio.setEnabled(false);bio.setText("البصمة غير متاحة على هذا الجهاز");}
        bio.setOnClickListener(v->{Executor ex=getMainExecutor();SecurityManager.authenticate(this,ex,new SecurityManager.Callback(){public void onSuccess(){db.beginUserSession();unlocked=true;buildApp();}public void onError(String m){Ui.toast(MainActivity.this,m);}});});
        setContentView(box);
    }

    private void buildApp(){
        appFrame=new FrameLayout(this);
        appFrame.setBackgroundColor(ThemeManager.palette(this).background);
        persistentSidebar=getResources().getConfiguration().screenWidthDp>=700;

        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(ThemeManager.palette(this).background);
        FrameLayout.LayoutParams mainLp=new FrameLayout.LayoutParams(-1,-1);
        if(persistentSidebar) mainLp.rightMargin=Ui.dp(this,258);
        appFrame.addView(root,mainLp);

        LinearLayout header=Ui.row(this);
        header.setPadding(Ui.dp(this,8),Ui.dp(this,4),Ui.dp(this,8),Ui.dp(this,4));
        header.setBackground(Ui.rounded(this,ThemeManager.palette(this).surface,0));
        Button menu=Ui.iconButton(this,"☰");
        header.addView(menu,new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,52)));
        menu.setOnClickListener(v->toggleSidebar());

        LinearLayout titles=Ui.columnCompact(this);
        TextView small=Ui.label(this,"سجل العمل والمتابعة");
        small.setTextSize(Ui.sp(this,11));small.setTextColor(ThemeManager.palette(this).muted);
        pageTitleView=Ui.title(this,currentPage);pageTitleView.setTextSize(19);pageTitleView.setPadding(0,0,0,0);
        titles.addView(small);titles.addView(pageTitleView);
        header.addView(titles,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));

        Button addWork=Ui.button(this,"+ إضافة");
        header.addView(addWork,new LinearLayout.LayoutParams(Ui.dp(this,78),Ui.dp(this,52)));
        addWork.setOnClickListener(v->{if(!AccessPolicy.canCreate(db)){Ui.toast(this,"صلاحيتك للعرض فقط");return;}startActivity(new Intent(this,RecordEditActivity.class));});
        if(!AccessPolicy.canCreate(db)){addWork.setText("عرض فقط");addWork.setEnabled(false);}
        Button alerts=Ui.iconButton(this,"🔔");
        header.addView(alerts,new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,52)));
        alerts.setOnClickListener(v->navigate("تنبيهات"));
        Button lock=Ui.button(this,"قفل");
        header.addView(lock,new LinearLayout.LayoutParams(Ui.dp(this,72),Ui.dp(this,52)));
        lock.setOnClickListener(v->{unlocked=false;db.endSession();showLogin();});
        root.addView(header,new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(Ui.dp(this,8),Ui.dp(this,4),Ui.dp(this,8),Ui.dp(this,8));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));

        buildSidebar();
        setContentView(appFrame);
        if(!persistentSidebar) sidebar.setVisibility(View.GONE); else {sidebar.setVisibility(View.VISIBLE);sidebarOpen=true;}
        requestNotificationPermissionIfNeeded();
        navigate(currentPage);
        openPendingRecordIfAny();
    }

    private void buildSidebar(){
        sidebar=new LinearLayout(this);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setPadding(Ui.dp(this,14),Ui.dp(this,18),Ui.dp(this,14),Ui.dp(this,14));
        sidebar.setBackground(Ui.sidebarBackground(this));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(this,258),-1,Gravity.RIGHT);
        appFrame.addView(sidebar,lp);

        LinearLayout brand=Ui.row(this);brand.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        ImageView logo=new ImageView(this);logo.setImageResource(ye.tracker.nativeapp.R.drawable.zakat_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brand.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,46)));
        LinearLayout brandText=Ui.columnCompact(this);
        TextView name=Ui.sideTitle(this,"نظام متابعة التقارير والخطط");name.setTextSize(15);
        TextView sub=Ui.sideLabel(this,"إدارة التقارير والخطط والمتابعة");sub.setTextSize(10);
        brandText.addView(name);brandText.addView(sub);brand.addView(brandText,new LinearLayout.LayoutParams(0,-2,1));
        sidebar.addView(brand,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));

        View divider=new View(this);divider.setBackgroundColor(Color.argb(40,255,255,255));sidebar.addView(divider,new LinearLayout.LayoutParams(-1,1));
        String[] labs={"لوحة المؤشرات","سجل المتابعة","المهام","المذكرات","الخطط","التقارير","سجل التغييرات","سجل الإصدارات","تنبيهات","الاستيراد والتصدير"};
        for(String lab:labs){Button b=Ui.sideButton(this,lab);b.setTag(lab);sidebar.addView(b,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));b.setOnClickListener(v->navigate(lab));}
        Space spacer=new Space(this);sidebar.addView(spacer,new LinearLayout.LayoutParams(-1,0,1));
        Button settings=Ui.sideButton(this,"الإعدادات");settings.setTag("الإعدادات");sidebar.addView(settings,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));settings.setOnClickListener(v->navigate("الإعدادات"));
        TextView who=Ui.sideLabel(this,db.actorName()+" · "+db.deviceRole()+"\n"+db.deviceName()+" · "+shortId(db.deviceId()));who.setPadding(Ui.dp(this,10),Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,4));sidebar.addView(who,Ui.match());
    }

    private void toggleSidebar(){
        if(persistentSidebar)return;
        sidebarOpen=!sidebarOpen;
        sidebar.setVisibility(sidebarOpen?View.VISIBLE:View.GONE);
    }

    private void updateSidebarSelection(String page){
        if(sidebar==null)return;
        for(int i=0;i<sidebar.getChildCount();i++){
            View v=sidebar.getChildAt(i);
            if(v instanceof Button){Button b=(Button)v;Object tag=b.getTag();boolean active=tag!=null&&page.equals(String.valueOf(tag));b.setBackground(active?Ui.rounded(this,ThemeManager.palette(this).primary,12):Ui.rounded(this,Color.TRANSPARENT,12));}
        }
    }

    private void closeSidebarAfterNavigation(){
        if(!persistentSidebar){sidebarOpen=false;sidebar.setVisibility(View.GONE);}
    }


    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);setIntent(intent);pendingRecordUid=intent.getStringExtra("record_uid");if(unlocked)openPendingRecordIfAny();
    }

    private void openPendingRecordIfAny(){
        if(pendingRecordUid==null||pendingRecordUid.trim().isEmpty())return;String uid=pendingRecordUid;pendingRecordUid=null;Intent in=new Intent(this,RecordEditActivity.class);in.putExtra("record_uid",uid);startActivity(in);
    }

    private void navigate(String page){
        currentPage=page;
        if(pageTitleView!=null)pageTitleView.setText(page);
        updateSidebarSelection(page);
        content.removeAllViews();
        switch(page){
            case "لوحة المؤشرات": showDashboard(); break;
            case "سجل المتابعة": showRecordsPage("سجل المتابعة","الكل",true,null,""); break;
            case "المهام": showRecordsPage("المهام","مهمة",false,null,""); break;
            case "المذكرات": showRecordsPage("المذكرات","مذكرة",false,null,""); break;
            case "الخطط": showRecordsPage("الخطط","خطة",false,null,""); break;
            case "التقارير": showRecordsPage("التقارير","تقرير",false,null,""); break;
            case "سجل التغييرات": showAudit(); break;
            case "سجل الإصدارات": showVersions(); break;
            case "الإعدادات": showSettings(); break;
            case "تنبيهات": showAlerts(); break;
            default: showExchange(); break;
        }
        closeSidebarAfterNavigation();
    }


    private void showDashboard(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout b=Ui.column(this);

        long total=count("records","deleted=0");
        long done=count("records","deleted=0 AND status='منجزة'");
        int pct=total==0?0:(int)Math.round(done*100.0/total);

        LinearLayout hero=Ui.card(this);
        TextView completionTitle=Ui.title(this,"نسبة الإنجاز");completionTitle.setPadding(0,0,0,0);hero.addView(completionTitle,new LinearLayout.LayoutParams(0,-2,1));
        TextView percent=Ui.metricNumber(this,pct+"%");percent.setGravity(Gravity.CENTER);hero.addView(percent,new LinearLayout.LayoutParams(Ui.dp(this,110),Ui.dp(this,78)));
        hero.setOnClickListener(v->showRecordsPage("الأعمال المنجزة","الكل",true,"منجزة",""));
        b.addView(hero,Ui.cardParams(this));

        String[] labels={"إجمالي السجل","المهام","التقارير","الخطط","المذكرات"};
        String[] wheres={"deleted=0","deleted=0 AND type='مهمة'","deleted=0 AND type='تقرير'","deleted=0 AND type='خطة'","deleted=0 AND type='مذكرة'"};
        String[] pages={"سجل المتابعة","المهام","التقارير","الخطط","المذكرات"};
        addMetricGrid(b,labels,wheres,pages,null);

        TextView sh=Ui.sectionTitle(this,"مؤشرات حالة الأعمال");b.addView(sh,Ui.match());
        String[] statusLabels={"منجزة","ملغية","قيد المتابعة","قيد الانجاز"};
        String[] statusWhere={"deleted=0 AND status='منجزة'","deleted=0 AND status='ملغية'","deleted=0 AND status='قيد المتابعة'","deleted=0 AND status='قيد الانجاز'"};
        addMetricGrid(b,statusLabels,statusWhere,null,statusLabels);

        b.addView(Ui.sectionTitle(this,"التوزيع حسب المعني بالمهمة"),Ui.match());
        addBreakdown(b,"assignee");
        b.addView(Ui.sectionTitle(this,"التوزيع حسب الجهة المعنية بالمتابعة"),Ui.match());
        addBreakdown(b,"agency");

        b.addView(Ui.sectionTitle(this,"الأعمال القريبة من موعد التنفيذ"),Ui.match());
        String lead=db.setting("alert_lead_days","2");
        int leadDays;try{leadDays=Math.max(0,Integer.parseInt(lead));}catch(Exception e){leadDays=2;}
        String dueWhere="deleted=0 AND status NOT IN ('منجزة','ملغية') AND expected_date IS NOT NULL AND date(expected_date)>=date('now','localtime') AND date(expected_date)<=date('now','localtime','+"+leadDays+" day')";
        LinearLayout due=Ui.metricCard(this,"قريبة الموعد",count("records",dueWhere),"اضغط لفتح السجلات");
        due.setOnClickListener(v->showRecordsPage("الأعمال القريبة من الموعد","الكل",true,"__DUE__",""));b.addView(due,Ui.cardParams(this));
        String lateWhere="deleted=0 AND (status='متأخرة' OR (status NOT IN ('منجزة','ملغية') AND expected_date IS NOT NULL AND date(expected_date)<date('now','localtime')))";
        LinearLayout late=Ui.metricCard(this,"متأخرة حسب التاريخ",count("records",lateWhere),"اضغط لفتح السجلات");
        late.setOnClickListener(v->showRecordsPage("الأعمال المتأخرة","الكل",true,"__LATE__",""));b.addView(late,Ui.cardParams(this));

        scroll.addView(b);content.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
    }

    private void addMetricGrid(LinearLayout parent,String[] labels,String[] wheres,String[] pages,String[] statuses){
        for(int i=0;i<labels.length;i+=2){
            LinearLayout row=Ui.row(this);row.setGravity(Gravity.TOP);
            for(int j=i;j<Math.min(i+2,labels.length);j++){
                final int k=j;LinearLayout card=Ui.metricCard(this,labels[j],count("records",wheres[j]),"اضغط لفتح التفاصيل");
                card.setOnClickListener(v->{
                    if(statuses!=null)showRecordsPage(statuses[k],"الكل",true,statuses[k],"");
                    else navigate(pages[k]);
                });
                row.addView(card,new LinearLayout.LayoutParams(0,-2,1));
            }
            if(i+1>=labels.length){Space sp=new Space(this);row.addView(sp,new LinearLayout.LayoutParams(0,1,1));}
            parent.addView(row,Ui.match());
        }
    }

    private void addBreakdown(LinearLayout parent,String field){
        String safe="agency".equals(field)?"agency":"assignee";
        String sql="SELECT COALESCE(NULLIF(TRIM("+safe+"),''),'غير محدد') AS name, COUNT(*) AS total, SUM(CASE WHEN status NOT IN ('منجزة','ملغية') THEN 1 ELSE 0 END) AS active FROM records WHERE deleted=0 GROUP BY COALESCE(NULLIF(TRIM("+safe+"),''),'غير محدد') ORDER BY total DESC LIMIT 30";
        try(Cursor c=db.getReadableDatabase().rawQuery(sql,null)){
            if(!c.moveToFirst()){parent.addView(Ui.label(this,"لا توجد بيانات بعد."),Ui.match());return;}
            do{String name=c.getString(0);long total=c.getLong(1),active=c.getLong(2);LinearLayout r=Ui.breakdownRow(this,name,"نشط: "+active,String.valueOf(total));r.setOnClickListener(v->showRecordsPage("نتائج: "+name,"الكل",true,null,name));parent.addView(r,Ui.cardParams(this));}while(c.moveToNext());
        }
    }


    private long count(String table,String where){try(Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE "+where,null)){c.moveToFirst();return c.getLong(0);}}

    private void showRecordsPage(String title,String fixedType,boolean allowType,String initialStatus,String initialSearch){
        LinearLayout top=Ui.column(this);top.addView(Ui.title(this,title),Ui.match());

        LinearLayout kpis=Ui.row(this);kpis.setGravity(Gravity.TOP);
        String base="deleted=0"+("الكل".equals(fixedType)?"":" AND type='"+fixedType.replace("'","''")+"'");
        String[] kl={"إجمالي","نشطة","قريبة الموعد","متأخرة","منجزة"};
        String[] kw={base,base+" AND status NOT IN ('منجزة','ملغية')",base+" AND status NOT IN ('منجزة','ملغية') AND expected_date IS NOT NULL AND date(expected_date)>=date('now','localtime') AND date(expected_date)<=date('now','localtime','+"+db.setting("alert_lead_days","2")+" day')",base+" AND (status='متأخرة' OR (status NOT IN ('منجزة','ملغية') AND expected_date IS NOT NULL AND date(expected_date)<date('now','localtime')))",base+" AND status='منجزة'"};
        for(int i=0;i<kl.length;i++){final int k=i;LinearLayout card=Ui.smallMetricCard(this,kl[i],count("records",kw[i]));card.setOnClickListener(v->{String st=k==1?"__ACTIVE__":k==2?"__DUE__":k==3?"__LATE__":k==4?"منجزة":null;showRecordsPage(title,fixedType,allowType,st,"");});kpis.addView(card,new LinearLayout.LayoutParams(0,-2,1));}
        HorizontalScrollView kh=new HorizontalScrollView(this);kh.setHorizontalScrollBarEnabled(false);kh.addView(kpis,new LinearLayout.LayoutParams(Ui.dp(this,620),-2));top.addView(kh,Ui.match());

        LinearLayout bar=Ui.row(this);
        final Spinner type=new Spinner(this);
        if(allowType){type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"الكل","مهمة","تقرير","خطة","مذكرة"}));bar.addView(type,new LinearLayout.LayoutParams(Ui.dp(this,120),-2));}
        final Spinner status=new Spinner(this);String[] statusValues={"الكل","قيد المتابعة","قيد الانجاز","متأخرة","منجزة","ملغية"};status.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,statusValues));
        if(initialStatus!=null&&!initialStatus.startsWith("__")){for(int z=0;z<statusValues.length;z++)if(statusValues[z].equals(initialStatus))status.setSelection(z);}
        bar.addView(status,new LinearLayout.LayoutParams(Ui.dp(this,135),-2));
        EditText search=Ui.edit(this,"بحث بالموضوع أو الرقم أو المعني أو الجهة");search.setText(initialSearch==null?"":initialSearch);bar.addView(search,Ui.weight());
        Button go=Ui.button(this,"بحث");bar.addView(go);top.addView(bar,Ui.match());
        Button add=Ui.button(this,"إضافة "+("الكل".equals(fixedType)?"عمل":fixedType));
        if(!AccessPolicy.canCreate(db)){add.setText("صلاحية العرض فقط");add.setEnabled(false);}
        top.addView(add,Ui.match());content.addView(top,Ui.match());

        ListView list=new ListView(this);list.setDividerHeight(0);
        Button more=Ui.button(this,"تحميل المزيد");list.addFooterView(more,null,false);
        PagedRecordAdapter adapter=new PagedRecordAdapter(this);list.setAdapter(adapter);
        content.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        final int pageSize=300;final int[] offset={0};final String special=initialStatus;
        final Runnable[] append={null};final Runnable[] reset={null};
        append[0]=()->{
            String selected=allowType?String.valueOf(type.getSelectedItem()):fixedType;String st=String.valueOf(status.getSelectedItem());
            int added=0;try(Cursor c=repo.recordsCursorAdvancedPage(selected,st,search.getText().toString(),special,pageSize,offset[0])){while(c.moveToNext()){adapter.add(RecordRow.from(c));added++;}}
            offset[0]+=added;adapter.notifyDataSetChanged();more.setVisibility(added<pageSize?View.GONE:View.VISIBLE);
        };
        reset[0]=()->{adapter.clear();offset[0]=0;append[0].run();};
        more.setOnClickListener(v->append[0].run());go.setOnClickListener(v->reset[0].run());
        status.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?>p,View v,int pos,long id){reset[0].run();}public void onNothingSelected(AdapterView<?>p){}});
        if(allowType)type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?>p,View v,int pos,long id){reset[0].run();}public void onNothingSelected(AdapterView<?>p){}});
        add.setOnClickListener(v->{if(!AccessPolicy.canCreate(db)){Ui.toast(this,"صلاحيتك لا تسمح بالإضافة");return;}Intent i=new Intent(this,RecordEditActivity.class);if(!"الكل".equals(fixedType))i.putExtra("type_default",fixedType);startActivity(i);});
        list.setOnItemClickListener((p,v,pos,id)->{RecordRow row=(RecordRow)adapter.getItem(pos);if(row==null)return;Intent in=new Intent(this,RecordEditActivity.class);in.putExtra("record_uid",row.uid);startActivity(in);});
        reset[0].run();
    }


    @Override protected void onResume(){super.onResume();if(unlocked&&content!=null&&root!=null){/* no global dataset load; current page is refreshed when explicitly reopened */}}

    private void showAudit(){
        LinearLayout b=Ui.column(this);b.addView(Ui.title(this,"سجل التغييرات"));
        b.addView(Ui.label(this,"يعرض من أضاف أو عدّل أو حذف، ومصدر العملية، مع الاحتفاظ بفروق الحقول القديمة والجديدة."),Ui.match());
        ListView l=new ListView(this);b.addView(l,new LinearLayout.LayoutParams(-1,0,1));content.addView(b,new LinearLayout.LayoutParams(-1,-1));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT _id,occurred_at,actor_name,actor_role,entity_type,operation,source,record_uid,uid FROM audit_events ORDER BY _id DESC LIMIT 1000",null);
        l.setAdapter(new AuditCursorAdapter(this,c));
        l.setOnItemClickListener((p,v,pos,id)->showAuditDetails((Cursor)p.getItemAtPosition(pos)));
    }

    private void showAuditDetails(Cursor c){
        String eventUid=c.getString(c.getColumnIndexOrThrow("uid"));StringBuilder m=new StringBuilder();
        m.append("الوقت: ").append(c.getString(c.getColumnIndexOrThrow("occurred_at"))).append("\nالمستخدم: ").append(c.getString(c.getColumnIndexOrThrow("actor_name"))).append(" — ").append(c.isNull(c.getColumnIndexOrThrow("actor_role"))?"—":c.getString(c.getColumnIndexOrThrow("actor_role"))).append("\nالعملية: ").append(c.getString(c.getColumnIndexOrThrow("operation"))).append("\nالمصدر: ").append(c.getString(c.getColumnIndexOrThrow("source"))).append("\n\n");
        try(Cursor x=db.getReadableDatabase().rawQuery("SELECT field_name,old_value,new_value FROM audit_field_changes WHERE event_uid=? ORDER BY _id",new String[]{eventUid})){
            while(x.moveToNext())m.append(x.getString(0)).append("\nالسابق: ").append(x.isNull(1)?"—":x.getString(1)).append("\nالجديد: ").append(x.isNull(2)?"—":x.getString(2)).append("\n\n");
        }
        new AlertDialog.Builder(this).setTitle("تفاصيل التغيير").setMessage(m.toString()).setPositiveButton("إغلاق",null).show();
    }

    private void showVersions(){
        LinearLayout b=Ui.column(this);b.addView(Ui.title(this,"سجل الإصدارات"));
        b.addView(Ui.label(this,"كل تعديل لبيانات السجل أو لمجرى متابعة يحتفظ بإصدار مستقل، ولا يؤدي تعديل مجرى متابعة إلى نسخ تاريخ السجل كاملًا."),Ui.match());
        ListView l=new ListView(this);b.addView(l,new LinearLayout.LayoutParams(-1,0,1));content.addView(b,new LinearLayout.LayoutParams(-1,-1));
        String sql="SELECT (_id*2) AS _id,'سجل' AS entity,record_uid AS record_uid,operation,actor_name,actor_role,device_id,source,created_at,snapshot_json AS body FROM record_revisions " +
                "UNION ALL SELECT (_id*2+1) AS _id,'مجرى متابعة' AS entity,record_uid,operation,actor_name,actor_role,device_id,source,created_at,text AS body FROM followup_revisions ORDER BY created_at DESC LIMIT 1000";
        Cursor c=db.getReadableDatabase().rawQuery(sql,null);l.setAdapter(new VersionCursorAdapter(this,c));
        l.setOnItemClickListener((p,v,pos,id)->{Cursor x=(Cursor)p.getItemAtPosition(pos);String msg="النوع: "+x.getString(x.getColumnIndexOrThrow("entity"))+"\nالعملية: "+x.getString(x.getColumnIndexOrThrow("operation"))+"\nالمستخدم: "+x.getString(x.getColumnIndexOrThrow("actor_name"))+" — "+(x.isNull(x.getColumnIndexOrThrow("actor_role"))?"—":x.getString(x.getColumnIndexOrThrow("actor_role")))+"\nالجهاز: "+x.getString(x.getColumnIndexOrThrow("device_id"))+"\nالمصدر: "+x.getString(x.getColumnIndexOrThrow("source"))+"\nالوقت: "+x.getString(x.getColumnIndexOrThrow("created_at"))+"\n\n"+x.getString(x.getColumnIndexOrThrow("body"));new AlertDialog.Builder(this).setTitle("تفاصيل الإصدار").setMessage(msg).setPositiveButton("إغلاق",null).show();});
    }

    private void showAlerts(){
        LinearLayout b=Ui.column(this);b.addView(Ui.title(this,"تنبيهات"));
        TextView state=Ui.label(this,notificationPermissionGranted()?"إشعارات Android مسموحة على هذا الجهاز.":"يلزم السماح بإشعارات Android حتى تظهر التنبيهات في شريط الإشعارات وشاشة القفل.");state.setTextSize(Ui.sp(this,14));b.addView(state,Ui.match());
        if(!notificationPermissionGranted()&&Build.VERSION.SDK_INT>=33){Button allow=Ui.button(this,"السماح بإشعارات Android");b.addView(allow,Ui.match());allow.setOnClickListener(v->requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},700));}
        LinearLayout actions=Ui.row(this);Button refresh=Ui.button(this,"تحديث الآن");actions.addView(refresh,Ui.weight());Button reschedule=Ui.button(this,"إعادة جدولة");actions.addView(reschedule,Ui.weight());b.addView(actions,Ui.match());
        refresh.setOnClickListener(v->{new NotificationReceiver().onReceive(this,new Intent(this,NotificationReceiver.class).setAction(NotificationScheduler.ACTION_DAILY));navigate("تنبيهات");});
        reschedule.setOnClickListener(v->{RecordAlertManager.scheduleAll(this,db);Ui.toast(this,"تمت إعادة جدولة التنبيهات القادمة");});
        b.addView(Ui.sectionTitle(this,"التنبيهات المرتبطة بالسجلات"),Ui.match());
        ListView l=new ListView(this);b.addView(l,new LinearLayout.LayoutParams(-1,0,1));content.addView(b,new LinearLayout.LayoutParams(-1,-1));
        String sql="SELECT a._id,a.uid AS alert_uid,r.uid AS record_uid,r.display_id,r.subject,a.kind,a.target_at,a.message,a.enabled,a.fired_at FROM record_alerts a JOIN records r ON r.uid=a.record_uid WHERE a.deleted=0 AND r.deleted=0 ORDER BY CASE WHEN a.fired_at IS NULL THEN 0 ELSE 1 END,datetime(a.target_at),a._id DESC LIMIT 1000";
        Cursor c=db.getReadableDatabase().rawQuery(sql,null);l.setAdapter(new ScheduledAlertCursorAdapter(this,c));
        l.setOnItemClickListener((p,v,pos,id)->{Cursor x=(Cursor)p.getItemAtPosition(pos);Intent in=new Intent(this,RecordEditActivity.class);in.putExtra("record_uid",x.getString(x.getColumnIndexOrThrow("record_uid")));startActivity(in);});
    }

    private void showSettings(){
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        LinearLayout tabs=Ui.row(this);tabs.setPadding(0,0,0,Ui.dp(this,4));
        String[][] items={{"appearance","المظهر"},{"notifications","التنبيهات"},{"lists","القوائم"},{"identity","هوية الجهاز"},{"print","الطباعة"},{"data","البيانات"}};
        FrameLayout holder=new FrameLayout(this);
        for(String[] it:items){Button tab=Ui.button(this,it[1]);tab.setTextSize(10);tab.setMinWidth(0);tab.setPadding(Ui.dp(this,2),0,Ui.dp(this,2),0);if(settingsTab.equals(it[0]))tab.setBackground(Ui.rounded(this,ThemeManager.palette(this).primary,10));if(settingsTab.equals(it[0]))tab.setTextColor(Color.WHITE);tabs.addView(tab,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));tab.setOnClickListener(v->{settingsTab=it[0];showSettings();});}
        shell.addView(tabs,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));
        shell.addView(holder,new LinearLayout.LayoutParams(-1,0,1));content.addView(shell,new LinearLayout.LayoutParams(-1,-1));renderSettingsTab(holder);
    }

    private void renderSettingsTab(FrameLayout holder){
        holder.removeAllViews();ScrollView scroll=new ScrollView(this);LinearLayout b=Ui.column(this);scroll.addView(b);holder.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        if("appearance".equals(settingsTab)){
            b.addView(Ui.title(this,"المظهر والثيم"),Ui.match());
            b.addView(Ui.label(this,"الثيم يغيّر الواجهة كاملة: الخلفية والبطاقات والترويسة والقائمة الجانبية والنصوص، مع تحكم مستقل في الوضع وحجم الخط وكثافة العرض."),Ui.match());
            String[] themeLabels={"مرصاد الأخضر — الافتراضي","كحلي مهني","فيروزي","جرافيت","رملي"};String[] themeCodes={"MERSAD","NAVY","TEAL","GRAPHITE","SAND"};
            Spinner theme=new Spinner(this);theme.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,themeLabels));theme.setSelection(indexOf(themeCodes,ThemeManager.theme(this)));b.addView(Ui.label(this,"الثيم"));b.addView(theme,Ui.match());
            String[] modeLabels={"حسب نظام الهاتف","فاتح","داكن"};String[] modeCodes={"SYSTEM","LIGHT","DARK"};Spinner mode=new Spinner(this);mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modeLabels));mode.setSelection(indexOf(modeCodes,ThemeManager.mode(this)));b.addView(Ui.label(this,"الوضع"));b.addView(mode,Ui.match());
            String[] densityLabels={"مضغوط — يعرض بيانات أكثر","قياسي","مريح — مسافات أكبر"};String[] densityCodes={"COMPACT","STANDARD","COMFORTABLE"};Spinner density=new Spinner(this);density.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,densityLabels));density.setSelection(indexOf(densityCodes,ThemeManager.density(this)));b.addView(Ui.label(this,"كثافة العرض"));b.addView(density,Ui.match());
            SeekBar textSize=new SeekBar(this);textSize.setMax(50);textSize.setProgress(Math.round((ThemeManager.textScale(this)-0.85f)*100f));b.addView(Ui.label(this,"حجم النص — من 85% إلى 135%"));b.addView(textSize,Ui.match());
            LinearLayout preview=Ui.card(this);TextView pp=Ui.title(this,"معاينة الواجهة");pp.setTextSize(Ui.sp(this,16));preview.addView(pp,new LinearLayout.LayoutParams(0,-2,1));TextView accent=Ui.metricNumber(this,"●");preview.addView(accent);b.addView(preview,Ui.cardParams(this));
            Button apply=Ui.button(this,"تطبيق المظهر");b.addView(apply,Ui.match());apply.setOnClickListener(v->{ThemeManager.setTheme(this,themeCodes[theme.getSelectedItemPosition()]);ThemeManager.setMode(this,modeCodes[mode.getSelectedItemPosition()]);ThemeManager.setDensity(this,densityCodes[density.getSelectedItemPosition()]);ThemeManager.setTextScale(this,0.85f+textSize.getProgress()/100f);currentPage="الإعدادات";settingsTab="appearance";buildApp();});
        }else if("notifications".equals(settingsTab)){
            b.addView(Ui.title(this,"إعدادات التنبيهات"),Ui.match());
            LinearLayout row=Ui.card(this);TextView lab=Ui.label(this,"إظهار تنبيهات Android");lab.setTextSize(Ui.sp(this,15));row.addView(lab,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setChecked("1".equals(db.setting("alerts_enabled","1")));row.addView(sw);b.addView(row,Ui.cardParams(this));sw.setOnCheckedChangeListener((x,on)->db.setSetting("alerts_enabled",on?"1":"0"));
            b.addView(Ui.label(this,"القالب التالي يُستخدم افتراضيًا عند إنشاء عمل جديد، ويمكن تغييره داخل كل سجل وإضافة أي عدد من التنبيهات المخصصة."),Ui.match());
            Spinner preset=new Spinner(this);preset.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,RecordAlertManager.presetLabels()));preset.setSelection(RecordAlertManager.presetPosition(db.setting("default_alert_preset",RecordAlertManager.PRESET_DAY)));b.addView(preset,Ui.match());
            EditText alertTime=Ui.edit(this,"وقت التنبيه HH:mm");alertTime.setText(db.setting("default_alert_time","09:00"));b.addView(alertTime,Ui.match());
            EditText lead=Ui.edit(this,"عدد أيام الأعمال القريبة في لوحة المؤشرات");lead.setInputType(InputType.TYPE_CLASS_NUMBER);lead.setText(db.setting("alert_lead_days","2"));b.addView(lead,Ui.match());
            Button saveAlerts=Ui.button(this,"حفظ إعدادات التنبيهات");b.addView(saveAlerts,Ui.match());saveAlerts.setOnClickListener(v->{db.setSetting("default_alert_preset",RecordAlertManager.presetCodeAt(preset.getSelectedItemPosition()));String tm=alertTime.getText().toString().trim();db.setSetting("default_alert_time",tm.matches("(?:[01]\\d|2[0-3]):[0-5]\\d")?tm:"09:00");String ld=lead.getText().toString().trim();db.setSetting("alert_lead_days",ld.matches("\\d+")?ld:"2");NotificationScheduler.scheduleDaily(this);RecordAlertManager.scheduleAll(this,db);Ui.toast(this,"تم حفظ إعدادات التنبيهات");});
            Button test=Ui.button(this,"اختبار/تحديث التنبيهات الآن");b.addView(test,Ui.match());test.setOnClickListener(v->new NotificationReceiver().onReceive(this,new Intent(this,NotificationReceiver.class).setAction(NotificationScheduler.ACTION_DAILY)));
        }else if("lists".equals(settingsTab)){
            b.addView(Ui.title(this,"القوائم"),Ui.match());
            b.addView(Ui.label(this,"إدارة القيم التي تظهر في الإدخال مثل الحالات والجهات وأنواع العمل. التعديل هنا لا يغيّر القيم التاريخية للسجلات السابقة."),Ui.match());
            addListManager(b,"work_type","أنواع العمل");addListManager(b,"status","حالات المهمة");addListManager(b,"agency","الجهات المعنية");
        }else if("identity".equals(settingsTab)){
            b.addView(Ui.title(this,"هوية الجهاز والحسابات"),Ui.match());
            String identityText="كل تثبيت يحتوي حساب مسؤول النظام وحساب مستخدم واحد لهذا الهاتف.\n"+
                    "اسم دخول المستخدم: "+db.userUsername()+"\n"+
                    "الاسم الظاهر: "+db.phoneUserName()+"\n"+
                    "الصفة: "+db.phoneUserRole()+"\n"+
                    "العمل/المسمى: "+db.setting("user_job","—")+"\n"+
                    "اسم الجهاز: "+db.deviceName()+"\n"+
                    "اسم دخول المسؤول: "+db.adminUsername()+"\n"+
                    "مسؤول النظام: "+db.adminName()+"\n"+
                    "معرف الجهاز: "+db.deviceId();
            b.addView(Ui.label(this,identityText),Ui.match());
            Button identity=Ui.button(this,"تعديل هوية المستخدم والجهاز");b.addView(identity,Ui.match());identity.setEnabled(AccessPolicy.isAdmin(db));identity.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))adminIdentityDialog();});
            Button bio=Ui.button(this,"تشغيل/إيقاف فتح التطبيق بالبصمة");b.addView(bio,Ui.match());bio.setOnClickListener(v->{String x=db.setting("biometric_enabled","1");db.setSetting("biometric_enabled","1".equals(x)?"0":"1");Ui.toast(this,"تم حفظ إعداد البصمة");});
            Button userPassword=Ui.button(this,"تغيير كلمة مرور مستخدم الهاتف");b.addView(userPassword,Ui.match());userPassword.setEnabled(AccessPolicy.isAdmin(db));userPassword.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))changePasswordDialog("user_password","كلمة مرور مستخدم الهاتف");});
            Button adminPassword=Ui.button(this,"تغيير كلمة مرور مسؤول النظام");b.addView(adminPassword,Ui.match());adminPassword.setEnabled(AccessPolicy.isAdmin(db));adminPassword.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))changePasswordDialog("admin_password","كلمة مرور مسؤول النظام");});
        }else if("print".equals(settingsTab)){
            b.addView(Ui.title(this,"الطباعة والتقارير"),Ui.match());
            b.addView(Ui.label(this,"التصدير يتم Native مباشرة من قاعدة البيانات، دون HTML أو WebView. PDF للطباعة والمشاركة، وExcel للتحليل والأرشفة."),Ui.match());
            Button pdf=Ui.button(this,"تصدير سجل المتابعة PDF");b.addView(pdf,Ui.match());pdf.setEnabled(AccessPolicy.canExport(db));pdf.setOnClickListener(v->{if(AccessPolicy.canExport(db))createExportDocument("application/pdf","سجل_المتابعة.pdf",601);});
            Button xlsx=Ui.button(this,"تصدير سجل المتابعة Excel");b.addView(xlsx,Ui.match());xlsx.setEnabled(AccessPolicy.canExport(db));xlsx.setOnClickListener(v->{if(AccessPolicy.canExport(db))createExportDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","سجل_المتابعة.xlsx",602);});
        }else{
            b.addView(Ui.title(this,"قاعدة البيانات والنسخ الاحتياطي"),Ui.match());
            b.addView(Ui.label(this,"النسخة الاحتياطية الكاملة تحتوي قاعدة SQLite والمرفقات. كما سيبقى تبادل البيانات بين الأجهزة منفصلًا حتى يمكن مراجعة التغييرات والتعارضات سجلًا بسجل."),Ui.match());
            Button full=Ui.button(this,"تصدير نسخة احتياطية كاملة");b.addView(full,Ui.match());full.setEnabled(AccessPolicy.isAdmin(db));full.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))createExportDocument("application/zip","نسخة_متابعة_كاملة.trackbackup",603);});
            Button raw=Ui.button(this,"تصدير قاعدة البيانات فقط");b.addView(raw,Ui.match());raw.setEnabled(AccessPolicy.isAdmin(db));raw.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))createExportDocument("application/octet-stream","tracker_native.db",604);});
            Button restoreFull=Ui.button(this,"استعادة نسخة احتياطية كاملة");b.addView(restoreFull,Ui.match());restoreFull.setEnabled(AccessPolicy.isAdmin(db));restoreFull.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))confirmRestore(true);});
            Button restoreDb=Ui.button(this,"استيراد/استعادة قاعدة بيانات");b.addView(restoreDb,Ui.match());restoreDb.setEnabled(AccessPolicy.isAdmin(db));restoreDb.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))confirmRestore(false);});
        }
    }

    private void addListManager(LinearLayout parent,String category,String title){
        LinearLayout card=Ui.card(this);LinearLayout copy=Ui.columnCompact(this);TextView t=Ui.title(this,title);t.setTextSize(15);t.setPadding(0,0,0,0);copy.addView(t);StringBuilder vals=new StringBuilder();try(Cursor c=db.getReadableDatabase().rawQuery("SELECT value FROM list_values WHERE category=? AND active=1 ORDER BY sort_order,_id",new String[]{category})){while(c.moveToNext()){if(vals.length()>0)vals.append("، ");vals.append(c.getString(0));}}TextView s=Ui.label(this,vals.length()==0?"لا توجد قيم":vals.toString());copy.addView(s);card.addView(copy,new LinearLayout.LayoutParams(0,-2,1));Button add=Ui.button(this,"إضافة");add.setEnabled(AccessPolicy.isAdmin(db));card.addView(add,new LinearLayout.LayoutParams(Ui.dp(this,72),-2));add.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))addListValueDialog(category,title);});parent.addView(card,Ui.cardParams(this));
    }

    private void addListValueDialog(String category,String title){EditText e=Ui.edit(this,"القيمة الجديدة");new AlertDialog.Builder(this).setTitle("إضافة إلى "+title).setView(e).setPositiveButton("حفظ",(d,w)->{String value=e.getText().toString().trim();if(value.isEmpty())return;db.getWritableDatabase().execSQL("INSERT OR IGNORE INTO list_values(category,value,sort_order,active) VALUES(?,?,(SELECT COALESCE(MAX(sort_order),0)+1 FROM list_values WHERE category=?),1)",new Object[]{category,value,category});showSettings();}).setNegativeButton("إلغاء",null).show();}

    private void createExportDocument(String mime,String name,int requestCode){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,requestCode);}
    private void openImportDocument(int requestCode){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,requestCode);}
    private void confirmRestore(boolean full){
        String what=full?"النسخة الاحتياطية الكاملة ستستبدل قاعدة البيانات والمرفقات الحالية.":"قاعدة البيانات المختارة ستستبدل قاعدة البيانات الحالية، ولن تغير ملفات المرفقات الموجودة إلا بقدر ما تشير إليه القاعدة.";
        new AlertDialog.Builder(this).setTitle("تأكيد الاستعادة").setMessage(what+"\n\nسيتم فحص سلامة الملف أولًا وإنشاء نسخة رجوع من قاعدة البيانات الحالية قبل الاستبدال.").setPositiveButton("اختيار الملف",(d,w)->openImportDocument(full?607:608)).setNegativeButton("إلغاء",null).show();
    }


    private void showExchange(){
        ScrollView s=new ScrollView(this);LinearLayout b=Ui.column(this);b.addView(Ui.title(this,"الاستيراد والتصدير"));
        TextView t=Ui.label(this,"يدعم التصميم تصدير PDF وExcel ونسخة قاعدة البيانات والنسخة الاحتياطية بالمرفقات، إضافة إلى حزم التبادل بين الأجهزة ومراجعة التعارضات على مستوى كل سجل.");t.setTextSize(15);b.addView(t,Ui.match());
        Button backup=Ui.button(this,"تصدير نسخة قاعدة البيانات والمرفقات");b.addView(backup,Ui.match());backup.setEnabled(AccessPolicy.isAdmin(db));backup.setOnClickListener(v->{if(AccessPolicy.isAdmin(db))createExportDocument("application/zip","نسخة_متابعة_كاملة.trackbackup",603);});
        Button sync=Ui.button(this,"تصدير حزمة للمزامنة بين الأجهزة");b.addView(sync,Ui.match());sync.setEnabled(AccessPolicy.canExport(db));sync.setOnClickListener(v->{if(AccessPolicy.canExport(db))createExportDocument("application/zip","حزمة_تبادل_"+db.deviceName()+".tracksync",605);});
        Button importSync=Ui.button(this,"استيراد حزمة من مستخدم آخر");b.addView(importSync,Ui.match());importSync.setEnabled(AccessPolicy.canImport(db));importSync.setOnClickListener(v->{if(AccessPolicy.canImport(db))openImportDocument(606);else Ui.toast(this,"الاستيراد متاح لمسؤول النظام فقط");});
        Button importExcel=Ui.button(this,"استيراد بيانات من Excel");b.addView(importExcel,Ui.match());importExcel.setEnabled(AccessPolicy.canImport(db));importExcel.setOnClickListener(v->{if(AccessPolicy.canImport(db))openImportDocument(609);else Ui.toast(this,"استيراد Excel متاح لمسؤول النظام فقط");});
        Button pending=Ui.button(this,"مراجعة آخر استيراد معلّق");b.addView(pending,Ui.match());pending.setEnabled(AccessPolicy.canImport(db));pending.setOnClickListener(v->{String id=latestPendingImport();if(id==null)Ui.toast(this,"لا توجد تغييرات معلقة");else startActivity(new Intent(this,ImportReviewActivity.class).putExtra("import_id",id));});
        b.addView(Ui.sectionTitle(this,"سجل التبادل بين الأجهزة"),Ui.match());
        try(Cursor x=db.getReadableDatabase().rawQuery("SELECT kind,package_id,peer_name,created_at,new_count,changed_count,conflict_count,unchanged_count FROM exchange_log ORDER BY _id DESC LIMIT 100",null)){
            if(!x.moveToFirst())b.addView(Ui.label(this,"لا توجد عمليات تبادل حتى الآن."),Ui.match());
            else do{String kind=x.getString(0),peer=x.isNull(2)?"—":x.getString(2);String line=("IMPORT".equals(kind)?"استيراد":"تصدير")+" | "+x.getString(3)+" | الطرف: "+peer+"\nجديد: "+x.getInt(4)+" | تعديلات: "+x.getInt(5)+" | تعارضات: "+x.getInt(6)+" | مطابق/أقدم: "+x.getInt(7);LinearLayout card=Ui.card(this);card.addView(Ui.label(this,line),Ui.match());b.addView(card,Ui.cardParams(this));}while(x.moveToNext());
        }
        s.addView(b);content.addView(s,new LinearLayout.LayoutParams(-1,-1));
    }

    private String latestPendingImport(){try(Cursor c=db.getReadableDatabase().rawQuery("SELECT import_id FROM import_items WHERE decision='PENDING' ORDER BY _id DESC LIMIT 1",null)){return c.moveToFirst()?c.getString(0):null;}}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        android.net.Uri uri=data.getData();
        if(requestCode>=601&&requestCode<=605){((TrackerApp)getApplication()).io().execute(()->{try(java.io.OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new java.io.IOException("تعذر فتح الملف");if(requestCode==601)ExportManager.exportPdf(db,out);else if(requestCode==602)ExportManager.exportXlsx(db,out);else if(requestCode==603)BackupManager.exportFull(this,db,out);else if(requestCode==604)BackupManager.exportDatabaseOnly(this,db,out);else SyncPackageManager.exportPackage(this,db,out);runOnUiThread(()->Ui.toast(this,"تم التصدير بنجاح"));}catch(Exception e){runOnUiThread(()->Ui.toast(this,"فشل التصدير: "+e.getMessage()));}});}
        else if(requestCode==606){((TrackerApp)getApplication()).io().execute(()->{try(java.io.InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new java.io.IOException("تعذر فتح الحزمة");String importId=SyncPackageManager.stageImport(this,db,in);int n=SyncPackageManager.pendingCount(db,importId);runOnUiThread(()->{if(n>0)startActivity(new Intent(this,ImportReviewActivity.class).putExtra("import_id",importId));else{SyncPackageManager.cleanupIfResolved(this,db,importId);Ui.toast(this,"تم الاستيراد؛ لا توجد تعارضات أو تعديلات تحتاج مراجعة");}});}catch(Exception e){runOnUiThread(()->Ui.toast(this,"فشل الاستيراد: "+e.getMessage()));}});}
        else if(requestCode==607||requestCode==608){((TrackerApp)getApplication()).io().execute(()->{try(java.io.InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new java.io.IOException("تعذر فتح ملف الاستعادة");if(requestCode==607)BackupManager.restoreFull(this,db,in);else BackupManager.restoreDatabaseOnly(this,db,in);runOnUiThread(()->{db=((TrackerApp)getApplication()).reopenDatabase();repo=new TrackerRepository(db);unlocked=false;Ui.toast(this,"تمت الاستعادة بنجاح. سجّل الدخول إلى البيانات المستعادة.");showLogin();});}catch(Exception e){runOnUiThread(()->{try{db=((TrackerApp)getApplication()).reopenDatabase();repo=new TrackerRepository(db);}catch(Exception ignored){}Ui.toast(this,"فشلت الاستعادة ولم يتم اعتماد الملف: "+e.getMessage());});}});}
        else if(requestCode==609){((TrackerApp)getApplication()).io().execute(()->{try(java.io.InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new java.io.IOException("تعذر فتح ملف Excel");String importId=ExcelImportManager.stageImport(this,db,in);int n=SyncPackageManager.pendingCount(db,importId);runOnUiThread(()->{if(n>0)startActivity(new Intent(this,ImportReviewActivity.class).putExtra("import_id",importId));else Ui.toast(this,"تم استيراد Excel ولا توجد تعديلات معلقة للمراجعة");});}catch(Exception e){runOnUiThread(()->Ui.toast(this,"فشل استيراد Excel: "+e.getMessage()));}});}
    }

    private void requestNotificationPermissionIfNeeded(){if(Build.VERSION.SDK_INT>=33&&!notificationPermissionGranted())requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},700);}
    private boolean notificationPermissionGranted(){return Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}

    private void adminIdentityDialog(){
        if(!AccessPolicy.isAdmin(db)){Ui.toast(this,"يلزم تسجيل الدخول بحساب مسؤول النظام");return;}
        LinearLayout box=Ui.column(this);
        EditText userLogin=Ui.edit(this,"اسم دخول مستخدم الهاتف");userLogin.setText(db.userUsername());
        EditText display=Ui.edit(this,"الاسم الظاهر في السجلات");display.setText(db.phoneUserName());
        EditText job=Ui.edit(this,"المسمى أو العمل");job.setText(db.setting("user_job",""));
        Spinner role=new Spinner(this);String[] roles={"مشرف","متابع","مطلع فقط"};role.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,roles));
        int rp=0;for(int i=0;i<roles.length;i++)if(roles[i].equals(db.phoneUserRole()))rp=i;role.setSelection(rp);
        EditText device=Ui.edit(this,"اسم الجهاز داخل النظام");device.setText(db.deviceName());
        EditText adminLogin=Ui.edit(this,"اسم دخول مسؤول النظام");adminLogin.setText(db.adminUsername());
        EditText admin=Ui.edit(this,"اسم مسؤول النظام الظاهر");admin.setText(db.adminName());
        box.addView(userLogin,Ui.match());box.addView(display,Ui.match());box.addView(job,Ui.match());box.addView(role,Ui.match());box.addView(device,Ui.match());box.addView(adminLogin,Ui.match());box.addView(admin,Ui.match());
        new AlertDialog.Builder(this).setTitle("تعديل هوية المستخدم والجهاز").setView(box).setPositiveButton("حفظ",(d,w)->{
            String ul=userLogin.getText().toString().trim(), dl=display.getText().toString().trim(), al=adminLogin.getText().toString().trim();
            if(ul.isEmpty()||dl.isEmpty()||al.isEmpty()){Ui.toast(this,"أكمل أسماء الدخول والاسم الظاهر");return;}
            if(ul.equalsIgnoreCase(al)){Ui.toast(this,"يجب أن يختلف اسم مستخدم الهاتف عن اسم مسؤول النظام");return;}
            db.configureDevice(dl,String.valueOf(role.getSelectedItem()),device.getText().toString(),admin.getText().toString());
            db.configureCredentials(al,admin.getText().toString(),ul);db.setSetting("user_job",job.getText().toString().trim());
            Ui.toast(this,"تم تحديث الهوية");buildApp();
        }).setNegativeButton("إلغاء",null).show();
    }

    private void requireAdmin(Runnable ok){
        if(db.isAdminSession()){ok.run();return;}
        LinearLayout box=Ui.column(this);EditText u=Ui.edit(this,"اسم مستخدم مسؤول النظام");u.setText(db.adminUsername());EditText p=Ui.edit(this,"كلمة مرور مسؤول النظام");p.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(u,Ui.match());box.addView(p,Ui.match());
        new AlertDialog.Builder(this).setTitle("صلاحية مسؤول النظام").setView(box).setPositiveButton("دخول",(d,w)->{
            if(u.getText().toString().trim().equalsIgnoreCase(db.adminUsername())&&SecurityManager.verifyPassword(db,"admin_password",p.getText().toString())){db.beginAdminSession();ok.run();}
            else Ui.toast(this,"بيانات مسؤول النظام غير صحيحة");
        }).setNegativeButton("إلغاء",null).show();
    }

    private void changePasswordDialog(String prefix,String title){
        if(!AccessPolicy.isAdmin(db)){Ui.toast(this,"يلزم حساب مسؤول النظام");return;}
        LinearLayout box=Ui.column(this);EditText p1=Ui.edit(this,"كلمة المرور الجديدة");p1.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);EditText p2=Ui.edit(this,"تأكيد كلمة المرور");p2.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(p1,Ui.match());box.addView(p2,Ui.match());
        new AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("حفظ",(d,w)->{String a=p1.getText().toString();if(a.length()<4){Ui.toast(this,"الحد الأدنى 4 أحرف أو أرقام");return;}if(!a.equals(p2.getText().toString())){Ui.toast(this,"كلمتا المرور غير متطابقتين");return;}SecurityManager.setPassword(db,prefix,a);Ui.toast(this,"تم تغيير كلمة المرور");}).setNegativeButton("إلغاء",null).show();
    }

    private int indexOf(String[] values,String target){for(int i=0;i<values.length;i++)if(values[i].equals(target))return i;return 0;}
    private String shortId(String s){return s.length()>12?s.substring(0,12):s;}

    @Override public void onBackPressed(){if(sidebarOpen&&!persistentSidebar){toggleSidebar();return;}super.onBackPressed();}

    private static final class RecordRow{
        String uid,id,recordNo,subject,type,status,agency,assignee,expected,updated;long attachments;
        static RecordRow from(Cursor c){RecordRow r=new RecordRow();r.uid=c.getString(c.getColumnIndexOrThrow("uid"));r.id=c.getString(c.getColumnIndexOrThrow("display_id"));r.recordNo=value(c,"record_no");r.subject=value(c,"subject");r.type=value(c,"type");r.status=value(c,"status");r.agency=value(c,"agency");r.assignee=value(c,"assignee");r.expected=value(c,"expected_date");r.updated=value(c,"updated_at");int ai=c.getColumnIndex("attachment_count");r.attachments=ai>=0?c.getLong(ai):0;return r;}
        static String value(Cursor c,String k){int i=c.getColumnIndex(k);return i<0||c.isNull(i)?"":c.getString(i);}
    }
    private static final class PagedRecordAdapter extends BaseAdapter{
        private final Context c;private final java.util.ArrayList<RecordRow> rows=new java.util.ArrayList<>();PagedRecordAdapter(Context c){this.c=c;}void add(RecordRow r){rows.add(r);}void clear(){rows.clear();notifyDataSetChanged();}public int getCount(){return rows.size();}public Object getItem(int p){return p>=0&&p<rows.size()?rows.get(p):null;}public long getItemId(int p){return p;}public View getView(int p,View convert,ViewGroup parent){LinearLayout card=convert instanceof LinearLayout?(LinearLayout)convert:Ui.card(c);card.removeAllViews();card.setOrientation(LinearLayout.VERTICAL);RecordRow r=rows.get(p);TextView subject=Ui.title(c,r.subject);subject.setTextSize(16);subject.setPadding(0,0,0,0);card.addView(subject);TextView line=Ui.label(c,r.id+(r.recordNo.isEmpty()?"":" · "+r.recordNo)+" | "+r.type+" | "+r.status);line.setTextColor(ThemeManager.palette(c).primary);card.addView(line,Ui.match());card.addView(Ui.label(c,"المعني: "+r.assignee+" | الجهة: "+r.agency+" | الاستحقاق: "+(r.expected.isEmpty()?"—":r.expected)),Ui.match());card.addView(Ui.label(c,"المرفقات: "+r.attachments+" | آخر تحديث: "+r.updated),Ui.match());card.setBackground(Ui.rounded(c,ThemeManager.palette(c).surface,14));card.setPadding(Ui.dp(c,14),Ui.dp(c,10),Ui.dp(c,14),Ui.dp(c,10));return card;}}
    private static final class AuditCursorAdapter extends CursorAdapter{
        AuditCursorAdapter(Context c,Cursor x){super(c,x,0);}public View newView(Context c,Cursor x,ViewGroup p){return Ui.column(c);}public void bindView(View v,Context c,Cursor x){LinearLayout b=(LinearLayout)v;b.removeAllViews();String role=x.isNull(x.getColumnIndexOrThrow("actor_role"))?"—":x.getString(x.getColumnIndexOrThrow("actor_role"));String s=x.getString(x.getColumnIndexOrThrow("occurred_at"))+" | "+x.getString(x.getColumnIndexOrThrow("actor_name"))+" — "+role+" | "+x.getString(x.getColumnIndexOrThrow("operation"))+" | "+x.getString(x.getColumnIndexOrThrow("source"));b.addView(Ui.label(c,s),Ui.match());}}
    private static final class VersionCursorAdapter extends CursorAdapter{
        VersionCursorAdapter(Context c,Cursor x){super(c,x,0);}public View newView(Context c,Cursor x,ViewGroup p){return Ui.column(c);}public void bindView(View v,Context c,Cursor x){LinearLayout b=(LinearLayout)v;b.removeAllViews();TextView t=Ui.title(c,x.getString(x.getColumnIndexOrThrow("entity"))+" — "+x.getString(x.getColumnIndexOrThrow("operation")));t.setTextSize(15);b.addView(t);b.addView(Ui.label(c,x.getString(x.getColumnIndexOrThrow("created_at"))+" | "+x.getString(x.getColumnIndexOrThrow("actor_name"))+" — "+(x.isNull(x.getColumnIndexOrThrow("actor_role"))?"—":x.getString(x.getColumnIndexOrThrow("actor_role")))+" | "+x.getString(x.getColumnIndexOrThrow("source"))),Ui.match());}}
    private static final class ScheduledAlertCursorAdapter extends CursorAdapter{
        ScheduledAlertCursorAdapter(Context c,Cursor x){super(c,x,0);}
        public View newView(Context c,Cursor x,ViewGroup p){return Ui.column(c);}
        public void bindView(View v,Context c,Cursor x){
            LinearLayout b=(LinearLayout)v;b.removeAllViews();String kind=x.getString(x.getColumnIndexOrThrow("kind"));
            String fired=x.isNull(x.getColumnIndexOrThrow("fired_at"))?"":x.getString(x.getColumnIndexOrThrow("fired_at"));int enabled=x.getInt(x.getColumnIndexOrThrow("enabled"));
            String state=enabled==0?"معطل":(fired.isEmpty()?"قادم":"تم الإرسال");TextView t=Ui.title(c,x.getString(x.getColumnIndexOrThrow("subject")));t.setTextSize(Ui.sp(c,15));b.addView(t);
            String label="CUSTOM".equals(kind)?"مخصص":"افتراضي";b.addView(Ui.label(c,x.getString(x.getColumnIndexOrThrow("display_id"))+" | "+label+" | "+state+" | "+x.getString(x.getColumnIndexOrThrow("target_at"))),Ui.match());
            String msg=x.isNull(x.getColumnIndexOrThrow("message"))?"":x.getString(x.getColumnIndexOrThrow("message"));if(!msg.isEmpty())b.addView(Ui.label(c,msg),Ui.match());
        }
    }

}
