package ye.tracker.nativeapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Transactional CRUD with compact delta audit and independent follow-up versioning. */
public final class TrackerRepository {
    private final DatabaseHelper helper;
    public TrackerRepository(DatabaseHelper helper) { this.helper = helper; }

    public Cursor recordsCursor(String type, String query) {
        StringBuilder sql = new StringBuilder("SELECT _id,uid,display_id,record_no,subject,type,start_date,expected_date,assignee,agency,status,completion_date,updated_at FROM records WHERE deleted=0");
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        if (type != null && !type.isEmpty() && !"الكل".equals(type)) { sql.append(" AND type=?"); args.add(type); }
        if (query != null && !query.trim().isEmpty()) {
            sql.append(" AND (subject LIKE ? OR record_no LIKE ? OR assignee LIKE ? OR agency LIKE ?)");
            String q = "%" + query.trim() + "%";
            args.add(q); args.add(q); args.add(q); args.add(q);
        }
        sql.append(" ORDER BY updated_at DESC, _id DESC LIMIT 500");
        return helper.getReadableDatabase().rawQuery(sql.toString(), args.toArray(new String[0]));
    }

    public String createRecord(Map<String,String> f) {
        require(AccessPolicy.canCreate(helper),"لا توجد صلاحية لإضافة سجل");
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            String uid = UUID.randomUUID().toString();
            String rev = UUID.randomUUID().toString();
            String now = TimeUtil.nowIso();
            long seq = nextSeq(db);
            String display = "W-" + String.format(java.util.Locale.US, "%06d", seq);
            ContentValues v = recordValues(f);
            v.put("uid", uid); v.put("seq", seq); v.put("display_id", display);
            v.put("origin_device_id", helper.deviceId()); v.put("updated_device_id", helper.deviceId());
            v.put("created_at", now); v.put("updated_at", now); v.put("current_revision_uid", rev); v.put("deleted", 0);
            db.insertOrThrow("records", null, v);
            JSONObject snap = recordSnapshot(db, uid);
            insertRecordRevision(db, uid, rev, null, snap, "يدوي", "إضافة");
            audit(db, "RECORD", uid, uid, "ADD", "يدوي", null, f, null);
            db.setTransactionSuccessful();
            return uid;
        } finally { db.endTransaction(); }
    }

    public void updateRecord(String uid, Map<String,String> f) {
        require(AccessPolicy.canEdit(helper),"لا توجد صلاحية لتعديل السجل");
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            Map<String,String> old = recordMap(db, uid);
            String parent = old.remove("current_revision_uid");
            String rev = UUID.randomUUID().toString();
            ContentValues v = recordValues(f);
            v.put("updated_device_id", helper.deviceId()); v.put("updated_at", TimeUtil.nowIso()); v.put("current_revision_uid", rev);
            db.update("records", v, "uid=? AND deleted=0", new String[]{uid});
            JSONObject snap = recordSnapshot(db, uid);
            insertRecordRevision(db, uid, rev, parent, snap, "يدوي", "تعديل");
            Map<String,String> now = recordMap(db, uid); now.remove("current_revision_uid");
            audit(db, "RECORD", uid, uid, "EDIT", "يدوي", old, now, null);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public void deleteRecord(String uid) {
        require(AccessPolicy.canDelete(helper),"الحذف متاح لمسؤول النظام أو المشرف فقط");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try {
            Map<String,String> old=recordMap(db,uid);String parent=old.remove("current_revision_uid");String rev=UUID.randomUUID().toString(),now=TimeUtil.nowIso();
            db.execSQL("UPDATE records SET deleted=1,updated_device_id=?,updated_at=?,current_revision_uid=? WHERE uid=? AND deleted=0",new Object[]{helper.deviceId(),now,rev,uid});
            JSONObject snap=new JSONObject(old);snap.put("deleted",1);insertRecordRevision(db,uid,rev,parent,snap,"يدوي","حذف");
            db.execSQL("INSERT INTO deletion_tombstones(uid,entity_type,entity_uid,record_uid,deleted_at,deleted_by_device,revision_uid) VALUES(?,?,?,?,?,?,?)",new Object[]{UUID.randomUUID().toString(),"RECORD",uid,uid,now,helper.deviceId(),rev});
            audit(db,"RECORD",uid,uid,"DELETE","يدوي",old,null,null);db.setTransactionSuccessful();
        } catch(Exception e){throw new IllegalStateException(e);} finally {db.endTransaction();}
    }

    public Cursor followupsCursor(String recordUid) {
        return helper.getReadableDatabase().rawQuery(
                "SELECT _id,uid,event_at,text,created_at,updated_at,current_revision_uid FROM followups WHERE record_uid=? AND deleted=0 ORDER BY event_at DESC,_id DESC",
                new String[]{recordUid});
    }

    public String addFollowup(String recordUid, String eventAt, String text) {
        require(AccessPolicy.canManageFollowups(helper),"لا توجد صلاحية لإضافة مجريات متابعة");
        SQLiteDatabase db = helper.getWritableDatabase(); db.beginTransaction();
        try {
            String uid=UUID.randomUUID().toString(), rev=UUID.randomUUID().toString(), now=TimeUtil.nowIso();
            ContentValues v=new ContentValues();
            v.put("uid",uid);v.put("record_uid",recordUid);v.put("event_at",eventAt);v.put("text",text.trim());
            v.put("origin_device_id",helper.deviceId());v.put("updated_device_id",helper.deviceId());
            v.put("created_at",now);v.put("updated_at",now);v.put("current_revision_uid",rev);v.put("deleted",0);
            db.insertOrThrow("followups",null,v);
            insertFollowupRevision(db,uid,recordUid,rev,null,eventAt,text.trim(),0,"يدوي","إضافة");
            Map<String,String> n=new LinkedHashMap<>();n.put("event_at",eventAt);n.put("text",text.trim());
            audit(db,"FOLLOWUP",uid,recordUid,"ADD","يدوي",null,n,null);
            touchRecord(db,recordUid);
            db.setTransactionSuccessful(); return uid;
        } finally {db.endTransaction();}
    }

    /** Edits only the selected follow-up. No full record snapshot is generated. */
    public void updateFollowup(String uid, String eventAt, String text) {
        require(AccessPolicy.canManageFollowups(helper),"لا توجد صلاحية لتعديل مجريات المتابعة");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try {
            Map<String,String> old=followupMap(db,uid);
            String recordUid=old.get("record_uid"), parent=old.get("current_revision_uid"), rev=UUID.randomUUID().toString();
            ContentValues v=new ContentValues();v.put("event_at",eventAt);v.put("text",text.trim());
            v.put("updated_device_id",helper.deviceId());v.put("updated_at",TimeUtil.nowIso());v.put("current_revision_uid",rev);
            db.update("followups",v,"uid=? AND deleted=0",new String[]{uid});
            insertFollowupRevision(db,uid,recordUid,rev,parent,eventAt,text.trim(),0,"يدوي","تعديل");
            Map<String,String> n=followupMap(db,uid);
            audit(db,"FOLLOWUP",uid,recordUid,"EDIT","يدوي",old,n,null);
            touchRecord(db,recordUid);
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }

    public void deleteFollowup(String uid) {
        require(AccessPolicy.canDelete(helper),"الحذف متاح لمسؤول النظام أو المشرف فقط");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try {
            Map<String,String> old=followupMap(db,uid); String recordUid=old.get("record_uid");
            String parent=old.get("current_revision_uid"), rev=UUID.randomUUID().toString(), now=TimeUtil.nowIso();
            db.execSQL("UPDATE followups SET deleted=1,updated_device_id=?,updated_at=?,current_revision_uid=? WHERE uid=?",
                    new Object[]{helper.deviceId(),now,rev,uid});
            insertFollowupRevision(db,uid,recordUid,rev,parent,old.get("event_at"),old.get("text"),1,"يدوي","حذف");
            db.execSQL("INSERT INTO deletion_tombstones(uid,entity_type,entity_uid,record_uid,deleted_at,deleted_by_device,revision_uid) VALUES(?,?,?,?,?,?,?)",
                    new Object[]{UUID.randomUUID().toString(),"FOLLOWUP",uid,recordUid,now,helper.deviceId(),rev});
            audit(db,"FOLLOWUP",uid,recordUid,"DELETE","يدوي",old,null,null); touchRecord(db,recordUid);
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }

    public Cursor followupHistory(String followupUid) {
        return helper.getReadableDatabase().rawQuery(
                "SELECT _id,revision_uid,parent_revision_uid,event_at,text,deleted,actor_name,device_id,source,operation,created_at FROM followup_revisions WHERE followup_uid=? ORDER BY _id DESC",
                new String[]{followupUid});
    }

    public JSONObject recordSnapshot(String uid) { return recordSnapshot(helper.getReadableDatabase(),uid); }

    private long nextSeq(SQLiteDatabase db) {
        try(Cursor c=db.rawQuery("SELECT COALESCE(MAX(seq),0)+1 FROM records",null)){c.moveToFirst();return c.getLong(0);}
    }

    private ContentValues recordValues(Map<String,String> f) {
        ContentValues v=new ContentValues();
        put(v,"record_no",f.get("record_no")); put(v,"subject",f.get("subject"));put(v,"type",f.get("type"));
        put(v,"start_date",f.get("start_date"));put(v,"expected_date",f.get("expected_date"));
        put(v,"assignee",f.get("assignee"));put(v,"agency",f.get("agency"));put(v,"status",f.get("status"));
        put(v,"completion_date",f.get("completion_date"));put(v,"notes",f.get("notes"));return v;
    }
    private void put(ContentValues v,String k,String s){ if(s==null||s.trim().isEmpty())v.putNull(k);else v.put(k,s.trim()); }

    private Map<String,String> recordMap(SQLiteDatabase db,String uid){
        String[] cols={"record_no","subject","type","start_date","expected_date","assignee","agency","status","completion_date","notes","current_revision_uid"};
        try(Cursor c=db.query("records",cols,"uid=?",new String[]{uid},null,null,null)){
            if(!c.moveToFirst())throw new IllegalArgumentException("Record not found");
            Map<String,String> m=new LinkedHashMap<>();for(int i=0;i<cols.length;i++)m.put(cols[i],c.isNull(i)?null:c.getString(i));return m;
        }
    }
    private Map<String,String> followupMap(SQLiteDatabase db,String uid){
        String[] cols={"record_uid","event_at","text","current_revision_uid","updated_at"};
        try(Cursor c=db.query("followups",cols,"uid=?",new String[]{uid},null,null,null)){
            if(!c.moveToFirst())throw new IllegalArgumentException("Follow-up not found");
            Map<String,String> m=new LinkedHashMap<>();for(int i=0;i<cols.length;i++)m.put(cols[i],c.isNull(i)?null:c.getString(i));return m;
        }
    }
    private JSONObject recordSnapshot(SQLiteDatabase db,String uid){
        try { return new JSONObject(recordMap(db,uid)); } catch(Exception e){throw new IllegalStateException(e);} }

    private void insertRecordRevision(SQLiteDatabase db,String recordUid,String rev,String parent,JSONObject snap,String source,String operation){
        db.execSQL("INSERT INTO record_revisions(revision_uid,record_uid,parent_revision_uid,snapshot_json,device_id,actor_name,actor_role,source,operation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                new Object[]{rev,recordUid,parent,snap.toString(),helper.deviceId(),helper.actorName(),helper.deviceRole(),source,operation,TimeUtil.nowIso()});
    }
    private void insertFollowupRevision(SQLiteDatabase db,String uid,String recordUid,String rev,String parent,String eventAt,String text,int deleted,String source,String operation){
        db.execSQL("INSERT INTO followup_revisions(revision_uid,followup_uid,record_uid,parent_revision_uid,event_at,text,deleted,device_id,actor_name,actor_role,source,operation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                new Object[]{rev,uid,recordUid,parent,eventAt,text,deleted,helper.deviceId(),helper.actorName(),helper.deviceRole(),source,operation,TimeUtil.nowIso()});
    }
    private void touchRecord(SQLiteDatabase db,String recordUid){
        // Follow-up changes affect ordering/sync freshness but not the core record revision chain.
        db.execSQL("UPDATE records SET updated_at=?,updated_device_id=? WHERE uid=?",new Object[]{TimeUtil.nowIso(),helper.deviceId(),recordUid});
    }

    private void audit(SQLiteDatabase db,String entityType,String entityUid,String recordUid,String operation,String source,Map<String,String> oldV,Map<String,String> newV,String importId){
        String event=UUID.randomUUID().toString();
        db.execSQL("INSERT INTO audit_events(uid,entity_type,entity_uid,record_uid,device_id,actor_name,actor_role,operation,source,occurred_at,import_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                new Object[]{event,entityType,entityUid,recordUid,helper.deviceId(),helper.actorName(),helper.deviceRole(),operation,source,TimeUtil.nowIso(),importId});
        java.util.LinkedHashSet<String> keys=new java.util.LinkedHashSet<>();if(oldV!=null)keys.addAll(oldV.keySet());if(newV!=null)keys.addAll(newV.keySet());
        for(String k:keys){String a=oldV==null?null:oldV.get(k),b=newV==null?null:newV.get(k);if(eq(a,b))continue;
            db.execSQL("INSERT INTO audit_field_changes(event_uid,field_name,old_value,new_value) VALUES(?,?,?,?)",new Object[]{event,k,a,b});}
    }
    private boolean eq(String a,String b){return a==null?b==null:a.equals(b);}

    Cursor recordsCursorAdvancedPage(String type, String status, String search, String special, int limit, int offset) {
        StringBuilder where=new StringBuilder("r.deleted=0");
        java.util.ArrayList<String> args=new java.util.ArrayList<>();
        if(type!=null&&!type.equals("الكل")){where.append(" AND r.type=?");args.add(type);}
        if(status!=null&&!status.equals("الكل")){where.append(" AND r.status=?");args.add(status);}
        if("__ACTIVE__".equals(special)){where.append(" AND r.status NOT IN ('منجزة','ملغية')");}
        else if("__LATE__".equals(special)){where.append(" AND (r.status='متأخرة' OR (r.status NOT IN ('منجزة','ملغية') AND r.expected_date IS NOT NULL AND date(r.expected_date)<date('now','localtime')))");}
        else if("__DUE__".equals(special)){int lead=2;try{lead=Math.max(0,Integer.parseInt(helper.setting("alert_lead_days","2")));}catch(Exception ignored){}where.append(" AND r.status NOT IN ('منجزة','ملغية') AND r.expected_date IS NOT NULL AND date(r.expected_date)>=date('now','localtime') AND date(r.expected_date)<=date('now','localtime','+").append(lead).append(" day')");}
        String q=search==null?"":search.trim();
        if(!q.isEmpty()){where.append(" AND (r.subject LIKE ? OR r.record_no LIKE ? OR r.display_id LIKE ? OR r.assignee LIKE ? OR r.agency LIKE ? OR r.notes LIKE ?)");String x="%"+q+"%";for(int i=0;i<6;i++)args.add(x);}
        args.add(String.valueOf(Math.max(1,Math.min(limit,1000))));
        args.add(String.valueOf(Math.max(0,offset)));
        return helper.getReadableDatabase().rawQuery("SELECT r._id,r.uid,r.display_id,r.record_no,r.subject,r.type,r.start_date,r.expected_date,r.assignee,r.agency,r.status,r.completion_date,r.notes,r.updated_at,(SELECT COUNT(*) FROM attachments a WHERE a.record_uid=r.uid AND a.deleted=0) AS attachment_count FROM records r WHERE "+where+" ORDER BY r._id DESC LIMIT ? OFFSET ?",args.toArray(new String[0]));
    }
    private void require(boolean allowed,String message){if(!allowed)throw new SecurityException(message);}

}
