package ye.tracker.nativeapp;

import android.app.Application;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class TrackerApp extends Application {
    private static TrackerApp instance;
    private DatabaseHelper db;
    private ExecutorService io;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        io = Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors() / 2));
        db = new DatabaseHelper(this);
        db.getWritableDatabase();
        NotificationScheduler.ensureChannel(this);
        NotificationScheduler.scheduleDaily(this);
        RecordAlertManager.scheduleAll(this, db);
    }

    public static TrackerApp app() { return instance; }
    public synchronized DatabaseHelper db() { return db; }
    public synchronized DatabaseHelper reopenDatabase() {
        try { if (db != null) db.close(); } catch (Exception ignored) {}
        db = new DatabaseHelper(this);
        db.getWritableDatabase();
        NotificationScheduler.ensureChannel(this);
        NotificationScheduler.scheduleDaily(this);
        RecordAlertManager.scheduleAll(this, db);
        return db;
    }
    public ExecutorService io() { return io; }
}
