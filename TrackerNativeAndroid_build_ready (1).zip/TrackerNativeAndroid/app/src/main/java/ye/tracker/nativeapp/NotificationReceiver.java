package ye.tracker.nativeapp;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import java.util.*;

public final class NotificationReceiver extends BroadcastReceiver {
    private static final String GROUP="tracker_due_group";

    @Override public void onReceive(Context c,Intent i){
        DatabaseHelper db=new DatabaseHelper(c);
        if(!"1".equals(db.setting("alerts_enabled","1")))return;
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationScheduler.ensureChannel(c);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;

        String alertUid=i==null?null:i.getStringExtra(NotificationScheduler.EXTRA_ALERT_UID);
        if(alertUid!=null&&!alertUid.trim().isEmpty()){
            postStoredAlert(c,db,nm,alertUid);
            return;
        }
        int count=postMissedStoredAlerts(c,db,nm);
        count+=postLegacyDueAlerts(c,db,nm);
        if(count>1)postSummary(c,nm,count);
    }

    private int postMissedStoredAlerts(Context c,DatabaseHelper db,NotificationManager nm){
        int count=0;
        String sql="SELECT a.uid,a.record_uid,a.kind,a.target_at,a.message,r.display_id,r.subject,r.agency FROM record_alerts a JOIN records r ON r.uid=a.record_uid WHERE a.deleted=0 AND a.enabled=1 AND a.fired_at IS NULL AND r.deleted=0 AND r.status NOT IN ('منجزة','ملغية') AND datetime(a.target_at)<=datetime('now','localtime') AND datetime(a.target_at)>=datetime('now','localtime','-2 day') ORDER BY datetime(a.target_at),a._id";
        try(Cursor x=db.getReadableDatabase().rawQuery(sql,null)){while(x.moveToNext()){if(postAlertRow(c,db,nm,x))count++;}}
        return count;
    }

    private void postStoredAlert(Context c,DatabaseHelper db,NotificationManager nm,String alertUid){
        String sql="SELECT a.uid,a.record_uid,a.kind,a.target_at,a.message,r.display_id,r.subject,r.agency FROM record_alerts a JOIN records r ON r.uid=a.record_uid WHERE a.uid=? AND a.deleted=0 AND a.enabled=1 AND a.fired_at IS NULL AND r.deleted=0";
        try(Cursor x=db.getReadableDatabase().rawQuery(sql,new String[]{alertUid})){if(x.moveToFirst())postAlertRow(c,db,nm,x);}
    }

    private boolean postAlertRow(Context c,DatabaseHelper db,NotificationManager nm,Cursor x){
        String uid=x.getString(0),recordUid=x.getString(1),kind=x.getString(2),target=x.getString(3),custom=x.isNull(4)?"":x.getString(4),display=x.getString(5),subject=x.getString(6),agency=x.isNull(7)?"":x.getString(7);
        String title="CUSTOM".equals(kind)?"تنبيه مخصص":"تنبيه متابعة";
        String message=(custom.isEmpty()?subject:custom)+" — "+display+(agency.isEmpty()?"":" — "+agency);
        postRecordNotification(c,nm,recordUid,title,message,stableId(uid));
        String notifUid="record-alert:"+uid;
        db.getWritableDatabase().execSQL("INSERT OR IGNORE INTO notifications(uid,record_uid,kind,target_date,message,is_read,created_at) VALUES(?,?,?,?,?,0,?)",new Object[]{notifUid,recordUid,kind,target,message,TimeUtil.nowIso()});
        db.getWritableDatabase().execSQL("UPDATE record_alerts SET fired_at=?,updated_at=? WHERE uid=?",new Object[]{TimeUtil.nowIso(),TimeUtil.nowIso(),uid});
        return true;
    }

    /** Compatibility for older records that predate per-record alert rows. */
    private int postLegacyDueAlerts(Context c,DatabaseHelper db,NotificationManager nm){
        String sql="SELECT r.uid,r.display_id,r.subject,r.type,r.status,r.expected_date,r.agency FROM records r WHERE r.deleted=0 AND r.status NOT IN ('منجزة','ملغية') AND r.expected_date IS NOT NULL AND NOT EXISTS(SELECT 1 FROM record_alerts a WHERE a.record_uid=r.uid AND a.deleted=0) AND (date(r.expected_date)=date('now','localtime') OR date(r.expected_date)=date('now','localtime','+1 day')) ORDER BY date(r.expected_date),r._id";
        int count=0;try(Cursor x=db.getReadableDatabase().rawQuery(sql,null)){while(x.moveToNext()){
            String recordUid=x.getString(0),display=x.getString(1),subject=x.getString(2),expected=x.getString(5),agency=x.getString(6);
            boolean today=isToday(db,expected);String kind=today?"DUE_TODAY":"DUE_TOMORROW";String title=today?"استحقاق اليوم":"استحقاق غدًا";String message=display+" — "+subject+(agency==null||agency.isEmpty()?"":" — "+agency);
            persistLegacy(db,recordUid,kind,expected,message);postRecordNotification(c,nm,recordUid,title,message,stableId(recordUid+kind));count++;
        }}return count;
    }

    private boolean isToday(DatabaseHelper db,String date){try(Cursor c=db.getReadableDatabase().rawQuery("SELECT CASE WHEN date(?)=date('now','localtime') THEN 1 ELSE 0 END",new String[]{date})){return c.moveToFirst()&&c.getInt(0)==1;}}
    private void persistLegacy(DatabaseHelper db,String recordUid,String kind,String date,String message){String uid="alert:"+recordUid+":"+kind+":"+date;db.getWritableDatabase().execSQL("INSERT OR IGNORE INTO notifications(uid,record_uid,kind,target_date,message,is_read,created_at) VALUES(?,?,?,?,?,0,?)",new Object[]{uid,recordUid,kind,date,message,TimeUtil.nowIso()});}

    private void postRecordNotification(Context c,NotificationManager nm,String recordUid,String title,String message,int id){
        Intent open=new Intent(c,MainActivity.class);open.putExtra("record_uid",recordUid);open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,NotificationScheduler.CHANNEL):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message).setStyle(new Notification.BigTextStyle().bigText(message)).setContentIntent(pi).setAutoCancel(false).setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_REMINDER).setGroup(GROUP);
        if(Build.VERSION.SDK_INT<26)b.setPriority(Notification.PRIORITY_HIGH);nm.notify(id,b.build());
    }
    private void postSummary(Context c,NotificationManager nm,int count){String text=count+" تنبيهات متابعة";Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,NotificationScheduler.CHANNEL):new Notification.Builder(c);Intent open=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,1002,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("تنبيهات المتابعة").setContentText(text).setContentIntent(pi).setAutoCancel(false).setGroup(GROUP).setGroupSummary(true).setVisibility(Notification.VISIBILITY_PUBLIC);if(Build.VERSION.SDK_INT<26)b.setPriority(Notification.PRIORITY_HIGH);nm.notify(1002,b.build());}
    private int stableId(String s){int x=s.hashCode();return x==Integer.MIN_VALUE?2001:2000+Math.abs(x%1000000);}
}
