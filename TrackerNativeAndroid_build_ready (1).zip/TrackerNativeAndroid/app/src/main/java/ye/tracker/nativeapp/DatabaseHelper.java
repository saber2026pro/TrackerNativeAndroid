package ye.tracker.nativeapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.UUID;

/**
 * Native SQLite store. Large/variable data is normalized: records, follow-ups,
 * attachments, alerts and revisions are separate entities with indexed lookups.
 */
public final class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "tracker_native.db";
    public static final int DB_VERSION = 14;
    private final Context context;
    private volatile String sessionType = "NONE";
    private volatile String sessionActor = null;
    private volatile String sessionRole = null;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context.getApplicationContext();
        setWriteAheadLoggingEnabled(true);
    }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
        db.execSQL("PRAGMA synchronous=NORMAL");
        db.execSQL("PRAGMA temp_store=MEMORY");
        db.execSQL("PRAGMA cache_size=-20000");
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE device_profile (" +
                "singleton_id INTEGER PRIMARY KEY CHECK(singleton_id=1)," +
                "device_id TEXT NOT NULL UNIQUE, person_name TEXT, role TEXT," +
                "configured INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)");

        db.execSQL("CREATE TABLE records (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE," +
                "seq INTEGER NOT NULL, display_id TEXT NOT NULL UNIQUE, record_no TEXT," +
                "subject TEXT NOT NULL, type TEXT NOT NULL, start_date TEXT NOT NULL, expected_date TEXT," +
                "assignee TEXT NOT NULL, agency TEXT NOT NULL, status TEXT NOT NULL," +
                "completion_date TEXT, notes TEXT," +
                "origin_device_id TEXT NOT NULL, updated_device_id TEXT NOT NULL," +
                "created_at TEXT NOT NULL, updated_at TEXT NOT NULL," +
                "current_revision_uid TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)");

        db.execSQL("CREATE TABLE record_revisions (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, revision_uid TEXT NOT NULL UNIQUE," +
                "record_uid TEXT NOT NULL, parent_revision_uid TEXT, snapshot_json TEXT NOT NULL," +
                "device_id TEXT NOT NULL, actor_name TEXT, actor_role TEXT, source TEXT NOT NULL," +
                "operation TEXT NOT NULL, created_at TEXT NOT NULL," +
                "FOREIGN KEY(record_uid) REFERENCES records(uid) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE followups (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE, record_uid TEXT NOT NULL," +
                "event_at TEXT NOT NULL, text TEXT NOT NULL," +
                "origin_device_id TEXT NOT NULL, updated_device_id TEXT NOT NULL," +
                "created_at TEXT NOT NULL, updated_at TEXT NOT NULL," +
                "current_revision_uid TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0," +
                "FOREIGN KEY(record_uid) REFERENCES records(uid) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE followup_revisions (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, revision_uid TEXT NOT NULL UNIQUE," +
                "followup_uid TEXT NOT NULL, record_uid TEXT NOT NULL, parent_revision_uid TEXT," +
                "event_at TEXT NOT NULL, text TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0," +
                "device_id TEXT NOT NULL, actor_name TEXT, actor_role TEXT, source TEXT NOT NULL," +
                "operation TEXT NOT NULL, created_at TEXT NOT NULL," +
                "FOREIGN KEY(followup_uid) REFERENCES followups(uid) ON DELETE CASCADE," +
                "FOREIGN KEY(record_uid) REFERENCES records(uid) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE attachments (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE, record_uid TEXT NOT NULL," +
                "followup_uid TEXT, file_name TEXT NOT NULL, mime_type TEXT, stored_name TEXT NOT NULL," +
                "relative_path TEXT NOT NULL, size_bytes INTEGER NOT NULL DEFAULT 0, sha256 TEXT NOT NULL," +
                "origin_device_id TEXT NOT NULL, created_at TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0," +
                "FOREIGN KEY(record_uid) REFERENCES records(uid) ON DELETE CASCADE," +
                "FOREIGN KEY(followup_uid) REFERENCES followups(uid) ON DELETE SET NULL)");

        db.execSQL("CREATE TABLE audit_events (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE, entity_type TEXT NOT NULL," +
                "entity_uid TEXT, record_uid TEXT, device_id TEXT NOT NULL, actor_name TEXT, actor_role TEXT," +
                "operation TEXT NOT NULL, source TEXT NOT NULL, occurred_at TEXT NOT NULL, import_id TEXT, details TEXT)");
        db.execSQL("CREATE TABLE audit_field_changes (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, event_uid TEXT NOT NULL," +
                "field_name TEXT NOT NULL, old_value TEXT, new_value TEXT," +
                "FOREIGN KEY(event_uid) REFERENCES audit_events(uid) ON DELETE CASCADE)");

        // History of notifications that have been materialized/shown.
        db.execSQL("CREATE TABLE notifications (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE, record_uid TEXT NOT NULL," +
                "kind TEXT NOT NULL, target_date TEXT, message TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0," +
                "created_at TEXT NOT NULL, FOREIGN KEY(record_uid) REFERENCES records(uid) ON DELETE CASCADE)");

        createRecordAlertsTable(db);

        db.execSQL("CREATE TABLE list_values (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, value TEXT NOT NULL," +
                "sort_order INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, UNIQUE(category,value))");
        db.execSQL("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)");

        db.execSQL("CREATE TABLE exchange_log (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE, kind TEXT NOT NULL," +
                "package_id TEXT NOT NULL, peer_device_id TEXT, peer_name TEXT, created_at TEXT NOT NULL," +
                "new_count INTEGER NOT NULL DEFAULT 0, changed_count INTEGER NOT NULL DEFAULT 0," +
                "conflict_count INTEGER NOT NULL DEFAULT 0, unchanged_count INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE import_items (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, import_id TEXT NOT NULL, entity_type TEXT NOT NULL," +
                "entity_uid TEXT NOT NULL, record_uid TEXT, kind TEXT NOT NULL," +
                "local_revision_uid TEXT, incoming_revision_uid TEXT, incoming_parent_revision_uid TEXT," +
                "local_json TEXT, incoming_json TEXT, diff_json TEXT," +
                "decision TEXT NOT NULL DEFAULT 'PENDING', resolved_at TEXT)");
        db.execSQL("CREATE TABLE deletion_tombstones (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE," +
                "entity_type TEXT NOT NULL, entity_uid TEXT NOT NULL, record_uid TEXT," +
                "deleted_at TEXT NOT NULL, deleted_by_device TEXT NOT NULL, revision_uid TEXT NOT NULL)");
        createImportRevisionTable(db);

        createIndexes(db);
        seedDefaults(db);
    }

    private void createRecordAlertsTable(SQLiteDatabase db){
        db.execSQL("CREATE TABLE record_alerts (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT NOT NULL UNIQUE, record_uid TEXT NOT NULL," +
                "kind TEXT NOT NULL, offset_days INTEGER, target_at TEXT NOT NULL, message TEXT," +
                "enabled INTEGER NOT NULL DEFAULT 1, fired_at TEXT, origin_device_id TEXT NOT NULL," +
                "created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0," +
                "FOREIGN KEY(record_uid) REFERENCES records(uid) ON DELETE CASCADE)");
    }

    private void createImportRevisionTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE import_revisions (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, import_id TEXT NOT NULL, entity_type TEXT NOT NULL," +
                "entity_uid TEXT NOT NULL, record_uid TEXT, revision_uid TEXT NOT NULL, parent_revision_uid TEXT," +
                "payload_json TEXT NOT NULL, UNIQUE(import_id,entity_type,revision_uid))");
    }

    private void createIndexes(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX idx_records_type ON records(type, deleted, updated_at DESC)");
        db.execSQL("CREATE INDEX idx_records_status ON records(status, deleted, updated_at DESC)");
        db.execSQL("CREATE INDEX idx_records_expected ON records(expected_date, status, deleted)");
        db.execSQL("CREATE INDEX idx_records_recordno ON records(record_no)");
        db.execSQL("CREATE INDEX idx_records_agency ON records(agency, deleted)");
        db.execSQL("CREATE INDEX idx_records_assignee ON records(assignee, deleted)");
        db.execSQL("CREATE INDEX idx_record_revisions_record ON record_revisions(record_uid, _id DESC)");
        db.execSQL("CREATE INDEX idx_followups_record ON followups(record_uid, deleted, event_at DESC)");
        db.execSQL("CREATE INDEX idx_followup_revisions_item ON followup_revisions(followup_uid, _id DESC)");
        db.execSQL("CREATE INDEX idx_attach_record ON attachments(record_uid, deleted, _id DESC)");
        db.execSQL("CREATE INDEX idx_attach_hash ON attachments(sha256, size_bytes)");
        db.execSQL("CREATE INDEX idx_audit_record ON audit_events(record_uid, occurred_at DESC)");
        db.execSQL("CREATE INDEX idx_audit_entity ON audit_events(entity_type, entity_uid, occurred_at DESC)");
        db.execSQL("CREATE INDEX idx_import_pending ON import_items(import_id, decision, kind)");
        db.execSQL("CREATE INDEX idx_import_revisions_entity ON import_revisions(import_id,entity_type,entity_uid,revision_uid)");
        db.execSQL("CREATE INDEX idx_record_alerts_due ON record_alerts(enabled,deleted,target_at)");
        db.execSQL("CREATE INDEX idx_record_alerts_record ON record_alerts(record_uid,deleted,target_at)");
    }

    private void seedDefaults(SQLiteDatabase db) {
        String now = TimeUtil.nowIso();
        String deviceId = UUID.randomUUID().toString();
        db.execSQL("INSERT INTO device_profile(singleton_id,device_id,configured,created_at,updated_at) VALUES(1,?,0,?,?)",
                new Object[]{deviceId, now, now});
        insertList(db, "work_type", 1, "مهمة");
        insertList(db, "work_type", 2, "تقرير");
        insertList(db, "work_type", 3, "خطة");
        insertList(db, "work_type", 4, "مذكرة");
        insertList(db, "status", 1, "قيد المتابعة");
        insertList(db, "status", 2, "قيد الانجاز");
        insertList(db, "status", 3, "متأخرة");
        insertList(db, "status", 4, "منجزة");
        insertList(db, "status", 5, "ملغية");
        insertList(db, "agency", 1, "التخطيط");
        insertList(db, "agency", 2, "الإدارة");
        insertList(db, "agency", 3, "الموارد البشرية");
        insertList(db, "agency", 4, "المالية");
        putSetting(db, "alerts_enabled", "1");
        putSetting(db, "alert_lead_days", "2");
        putSetting(db, "default_alert_preset", "DAY_BEFORE_AND_DUE");
        putSetting(db, "default_alert_time", "09:00");
        putSetting(db, "biometric_enabled", "1");
        putSetting(db, "app_pin_salt", "");
        putSetting(db, "app_pin_hash", "");
        putSetting(db, "admin_pin_salt", "");
        putSetting(db, "admin_pin_hash", "");
        putSetting(db, "admin_name", "مسؤول النظام");
        putSetting(db, "admin_username", "");
        putSetting(db, "admin_password_salt", "");
        putSetting(db, "admin_password_hash", "");
        putSetting(db, "user_username", "");
        putSetting(db, "user_password_salt", "");
        putSetting(db, "user_password_hash", "");
        putSetting(db, "device_name", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
    }

    private void insertList(SQLiteDatabase db, String cat, int order, String value) {
        db.execSQL("INSERT INTO list_values(category,value,sort_order,active) VALUES(?,?,?,1)", new Object[]{cat,value,order});
    }
    private void putSetting(SQLiteDatabase db, String k, String v) {
        db.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", new Object[]{k,v});
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 10) throw new IllegalStateException("Pre-release schema mismatch. Reinstall the unreleased native build.");
        if(oldVersion < 11){
            createRecordAlertsTable(db);
            db.execSQL("CREATE INDEX idx_record_alerts_due ON record_alerts(enabled,deleted,target_at)");
            db.execSQL("CREATE INDEX idx_record_alerts_record ON record_alerts(record_uid,deleted,target_at)");
            putSetting(db,"default_alert_preset","DAY_BEFORE_AND_DUE");
            putSetting(db,"default_alert_time","09:00");
            putSetting(db,"admin_name","مسؤول النظام");
        }
        if(oldVersion < 12){
            putSetting(db,"admin_username","");
            putSetting(db,"admin_password_salt","");
            putSetting(db,"admin_password_hash","");
            putSetting(db,"user_username","");
            putSetting(db,"user_password_salt","");
            putSetting(db,"user_password_hash","");
        }
        if(oldVersion < 13){
            db.execSQL("ALTER TABLE record_revisions ADD COLUMN actor_role TEXT");
            db.execSQL("ALTER TABLE followup_revisions ADD COLUMN actor_role TEXT");
            db.execSQL("ALTER TABLE audit_events ADD COLUMN actor_role TEXT");
        }
        if(oldVersion < 14){
            createImportRevisionTable(db);
            db.execSQL("CREATE INDEX idx_import_revisions_entity ON import_revisions(import_id,entity_type,entity_uid,revision_uid)");
        }
    }

    public String setting(String key, String fallback) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT value FROM settings WHERE key=?", new String[]{key})) {
            return c.moveToFirst() && !c.isNull(0) ? c.getString(0) : fallback;
        }
    }
    public void setSetting(String key, String value) {
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", new Object[]{key,value});
    }
    public String deviceId() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT device_id FROM device_profile WHERE singleton_id=1", null)) {
            if (!c.moveToFirst()) throw new IllegalStateException("device_profile missing");
            return c.getString(0);
        }
    }
    public String phoneUserName() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT person_name FROM device_profile WHERE singleton_id=1", null)) {
            return c.moveToFirst() && c.getString(0) != null ? c.getString(0) : "غير معرّف";
        }
    }
    public String phoneUserRole() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT role FROM device_profile WHERE singleton_id=1", null)) {
            return c.moveToFirst() && c.getString(0) != null ? c.getString(0) : "غير محدد";
        }
    }
    /** Current authenticated actor. Repositories use this so admin actions are not attributed to the phone user. */
    public String actorName() { return sessionActor != null ? sessionActor : phoneUserName(); }
    public String deviceRole() { return sessionRole != null ? sessionRole : phoneUserRole(); }
    public String activeUsername(){
        if("ADMIN".equals(sessionType)) return adminUsername();
        if("USER".equals(sessionType)) return userUsername();
        return "";
    }
    public boolean isAdminSession(){return "ADMIN".equals(sessionType);}
    public boolean isUserSession(){return "USER".equals(sessionType);}
    public boolean hasSession(){return isAdminSession()||isUserSession();}
    public void beginAdminSession(){sessionType="ADMIN";sessionActor=adminName();sessionRole="مسؤول النظام";}
    public void beginUserSession(){sessionType="USER";sessionActor=phoneUserName();sessionRole=phoneUserRole();}
    public void endSession(){sessionType="NONE";sessionActor=null;sessionRole=null;}
    public String deviceName(){return setting("device_name",android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL);}
    public String adminName(){return setting("admin_name","مسؤول النظام");}
    public String adminUsername(){return setting("admin_username","");}
    public String userUsername(){return setting("user_username","");}
    public boolean isConfigured() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT configured FROM device_profile WHERE singleton_id=1", null)) {
            return c.moveToFirst() && c.getInt(0) == 1;
        }
    }
    public void configureDevice(String personName, String role) {
        String now = TimeUtil.nowIso();
        getWritableDatabase().execSQL("UPDATE device_profile SET person_name=?, role=?, configured=1, updated_at=? WHERE singleton_id=1",
                new Object[]{personName.trim(), role.trim(), now});
    }
    public void configureDevice(String personName,String role,String deviceName,String adminName){
        configureDevice(personName,role);
        setSetting("device_name",deviceName==null||deviceName.trim().isEmpty()?personName.trim():deviceName.trim());
        setSetting("admin_name",adminName==null||adminName.trim().isEmpty()?"مسؤول النظام":adminName.trim());
        if(isUserSession()){sessionActor=phoneUserName();sessionRole=phoneUserRole();}
        if(isAdminSession()){sessionActor=adminName();sessionRole="مسؤول النظام";}
    }
    public void configureCredentials(String adminUsername,String adminName,String userUsername){
        setSetting("admin_username",adminUsername==null?"":adminUsername.trim());
        setSetting("admin_name",adminName==null||adminName.trim().isEmpty()?"مسؤول النظام":adminName.trim());
        setSetting("user_username",userUsername==null?"":userUsername.trim());
    }

    public Context context() { return context; }
}
