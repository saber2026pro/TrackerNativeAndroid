plugins { id("com.android.application") }

android {
    namespace = "ye.tracker.nativeapp"
    compileSdk = 36

    defaultConfig {
        applicationId = "ye.tracker.nativeapp"
        minSdk = 28
        targetSdk = 36
        versionCode = 30000
        versionName = "3.0.0-native"
    }

    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging { resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*") }
}
